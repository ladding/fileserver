//###################################################################################
//############################### 收银操作的JAVASCRIPT ###############################
//###################################################################################
var db,pc,__cust_disp;
//ADD CPQ 不是挂单的才弹钱箱
var isNotPark = true;
var isNw=(typeof(require)!='undefined');
var firstCheckoutFlag = true;
//会员生日提醒用，每次加载页面仅提醒一次; ADD BY CPQ 20161118
var firstReminderFlag = true;
//是否重打小票 AD DBY CPQ 20161214
var rePrintFlag = false;

var cartUpdating = false;
var cartLoading = false;
var __PB_sell_display_timer = -1,
	__PB_sell_display_setting_json;
//20160311:Modify by Dingph
//if (isNw) __cust_disp=require('led');
if(1 == localStorage.getItem('TEST_DIGITAL_SCREEN_AS_CUSTOMER_DISPLAY')) {
	if (isNw) {
		__cust_disp=require('led')({window:window});
		if(typeof(__cust_disp.getPort) === "function") {
			var CD_NAME = "CUSTOMER_DISPLAY";
			var cdNameStr = localStorage.getItem(CD_NAME);
			var cdName = {};
			if(!!cdNameStr)
				cdName = JSON.parse(cdNameStr);
			__PB_sell_display_setting_json = cdName;
			var port = cdName['port'];
			var option = cdName['option'];
			__cust_disp.getPort(port, option, false);
		}
	}
	else if(browser.versions.mobileAndroid) {
	    if(typeof(PBLed) != 'undefined') {
	        __cust_disp = PBLed;
	        var CD_NAME = "CUSTOMER_DISPLAY";
	        var cdNameStr = localStorage.getItem(CD_NAME);
	        var cdName = {};
	        if(!!cdNameStr)
	            cdName = JSON.parse(cdNameStr);
	        __PB_sell_display_setting_json = cdName;
	        var port = cdName['port'];
	        var option = cdName['option'];
	        __cust_disp.getPort(port, JSON.stringify(option));
	    }
	}
}
//20160311:Modify by Dingph
//var localStorage = window.localStorage;
var settings = JSON.parse(localStorage.getItem("settings"));//取得设置
$(function(){
	if (isNw)
		pc = require('PrinterControl');
	//组合付款 ADD BY CPQ
	/*$("#paymentComp_checkbox").bootstrapSwitch({handleWidth: '97',labelText: '组合付款'});*/
	$("#paymentComp_checkbox").on("click",function(){
		setPaymentComp($(this));
	})
	
	//ADD BY CPQ 20161215 START
	$('#taste_remark').tagsinput({
	  tagClass: "label label-info label-lg",
	  maxTags: 10,
	  maxChars: 10
	});
	
	$("#taste_btn_group").delegate(".btn","click",function(){
		$('#taste_remark').tagsinput('add', $(this).data('taste_name'));
	})
	
	$("#taste_btn_group_1").delegate(".btn","click",addTasteToTastesProductInfo)
	
	if(getSetting("Industry") == "1003"
	    && (browser.versions.nw
	    || browser.versions.mobileIos
	    || browser.versions.mobileAndroid)){
			/*$("#park_tag_print").bootstrapSwitch({
				handleWidth: '70',kitchen_print
				labelText: '打印贴标'
			});*/
		
			/*$("#single_tag_print").bootstrapSwitch({handleWidth: '75',labelText: '打印贴标'});*/
	}else{
		$("#tag_print,#park_tag_print").parents(".tag_print").hide();
		$("#select_desk_no").addClass('hidden');
		
		$("#single_tag_print").hide();
		/*$("#select_taste_btn").parent().removeClass("col-sm-4 col-lg-4").addClass('col-sm-8 col-lg-8');*/
	}
	
	if(getSetting("Industry") == "1003" && getSetting("tastes_enabled") == 1){
		initTastesClickEvent();
	}
	//ADD BY CPQ 20161215 END
	
	$("#cart tbody").delegate(".employee_click_td","click",function(){
		var cartId = $(this).data("cart_id");
		var employeeId = $(this).data("employee_id") || 0;
		var employeeName = $(this).data("employee_name");
		
		initEmployees(employeeId,cartId,2);
		
		initRemoveEmployeeBtnEvent(employeeId,cartId);
		
		$('#guideModal').one("shown.bs.modal",function(){
			$(this).find("input[type='text']").val("").focus().select();
			searchEmployee("");
		});
		$('#guideModal').modal('show');	
	})
});
var wishlistsize;
var sync_info = {
		info : {}
	};

//receipt currency 暂时去掉￥符号  MODIFY BY CPQ
var _currency = "";
if((navigator.language).toLowerCase().indexOf("cn")==-1){
	//_currency="$";
	_currency="";
}	

var checkoutEnabled = true;

//付款方式
var PAYMENT_ARRAY = JSON.parse('{"CASH":"现金","CARD":"刷卡","COUPON":"券","BALANCE":"会员卡","ALIPAY":"支付宝","WEIXIN":"微信","ALIPAY_1":"支付宝","WEIXIN_1":"微信","COMP":"组合付款"}');
//alert(PAYMENT_ARRAY["BALANCE"]);

//载入购物车,使用web sql db
function loadCart() {
	cartLoading = true;
	//V2.1:layout改到前台橱窗设置里控制:从QKLS中取,没有,则用默认
	//var cLayout = getSetting("cLayout");
	//将处理逻辑全部放入executeSql的回调中，解决快速点击橱窗商品时购物车会产生重复的问题 ADD BY CPQ 20161115
	db.transaction(function(tx) {
		tx.executeSql('SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? ORDER BY IFNULL(parent_seq,id) DESC,id ASC', [outletId], function(tx, results) {
			
			var industry = getSetting("Industry");
			var defaultLayout = industry=='1004'?'FULL':'QK';
			var cLayout = localStorage.getItem("QUICKKEY")!=undefined?(JSON.parse(localStorage.getItem("QUICKKEY"))).layout:defaultLayout;
			console.log("**************** cLayout->"+cLayout,cLayout == "FULL");

			var priceType = localStorage.getItem("PRICE_TYPE");
			var pricename = priceType==0?'零售价':'批发售价';
			
			// 载入前先清空购物车表格
			$("#cart thead").empty();
			$("#cart tbody").empty();
			$("#cart tfoot").empty();

			// 20170602:Add by dph
			// 通讯秤值
			var isOpenES = false;
			// 商超版 通用版 可用
			if(1004 == industry || 1000 == industry) {
				if("object" === typeof(esName)) {
					isOpenES = esName['isOpen'] || false;
				}
			}
			
			var employee_th = industry != "1003" && getSetting("itemGuideEnabled") == 1 ? "<th>导购</th>" : "";
			//append header title
			var row_header = "<tr>"
				+"<th>#</th>"
				+"<th>品名</th>"
				+"<th>标价</th>"
				+"<th>折扣</th>"
				+"<th class='text-center'>"+pricename+"</th>"
				+"<th class='text-center'>数量</th>"
				+"<th class='text-right'>小计</th>"
				+ employee_th
				+"<th>&nbsp;</th>"
				+"</tr>";
			if (cLayout == "FULL") {// 全屏
				$("#cart").removeAttr("style");
				//$("#cart").closest(".panel").css("margin-top","5px");
				
				row_header = "<tr>"
					+"<th>#</th>"
					+"<th>条码</th>"
					+"<th>品名</th>"
					+"<th>标价</th>"
					+"<th>折扣</th>"
					+"<th class='text-center'>"+pricename+"</th>"
					+"<th class='text-center'>数量</th>"
					+"<th class='text-right'>小计</th>"
					+ employee_th
					+"<th>&nbsp;</th>"
					+"</tr>";
			}
			
			$("#cart thead").append(row_header);
				
			var len = results.rows.length, i;
			if(len>0){
				//console.log("载入开始行");
				
				var totalQty = 0;//总数量
				var totalPoints = 0;//总积分
				var totalCommission = 0;//V2:提成合计
				
				var totalPrice = 0;//整单金额总计(包含退货金额)
				var totalListPrice = 0;//标价总计
				var totalSaleListPrice = 0;//销售标价总计(即不含退货的标价总计)
				var totalRefundPrice = 0;//退货金额总计
				var totalSalePrice = 0;//销售金额总计(即不含退货的售价总计)
				var totalDiscountEnabledListPrice = 0;//参与打折的标价总计(即不含退货与不参与打折的标价总计)
				var totalDiscountEnabledSalePrice = 0;//参与打折的销售金额总计(即不含退货与不参与打折的售价总计)
				var totalSaving = 0 ;//优惠金额总计
				
				var totalCut = 0;//可直减的金额,需要考虑收银员的最低折扣权限,by fandy
				var role = $("#auth_role").val();
				var minDiscount = role.indexOf('ROLE_CASHIER')>-1?getSetting("cMinDiscount"):0;//最低折扣权限,非收银员,可以全折扣(即0)
				console.log("############## minDiscount->",minDiscount);
				
				var orderType = 0;
				var relatedSaleOrderNo = [];
				var index = 0;
				
				for (i = 0; i < len; i++) {
					//console.log("载入第" + (i + 1) + "行");
					// alert(results.rows.item(i).product_name);
					var p = results.rows.item(i);// 此此不是商品,是购物车中的明细项
					// console.log(p.id)
					// 如果是退货,设为只读12-30,by
					// fandy,1-3更新,因为退货可能同码,另外收银如果不合同同条码的,在这儿使用条码无法定位唯一,改为ID
					var updateDiscountStr = "onchange='updateCart(\"" + p.id + "\",this,1)' ";
					var updateSalePriceStr = "onchange='updateCart(\"" + p.id + "\",this,3)' ";
					var updateQtyStr = "onchange='updateCart(\"" + p.id + "\",this,2)' ";
					var readonlyStr = "readonly='readonly'";
					var discoutPart = (p.refund_flag == 1 || p.discount_enabled == 0 || p.parent_seq) ? readonlyStr : updateDiscountStr;//退货与不参与打折的都readonly
					var salePricePart = (p.refund_flag == 1 || p.discount_enabled == 0 || p.parent_seq) ? readonlyStr : updateSalePriceStr;//退货与不参与打折的都readonly
					var qtyPart = (p.refund_flag == 1 || p.parent_seq) ? readonlyStr : updateQtyStr;
					var removePart = !p.parent_seq ? "<span class='btn btn-stroke waves-effect' onclick='removeCart(\"" + p.id + "\", \"" + p.product_id + "\")'><i class='fa fa-remove'></span></i>" : "";
					
					// 2014-2-16,处理附加属性
					var custProps = custPropFormatted(p.cust_props, true);
					//console.log("--------------------- product name/cust_props @ SHOPPINGCART->" +p.product_name + "/"+custProps);
					var proname = p.product_name + custProps;
					//console.log("--------------------- proname/proname.length->" +proname +"/"+proname.length);
					
					//退货商品时，
					if(p.refund_flag == 1){
						//单据类型为退货orderType = 1;
						orderType = 1;
						
						//取得关联单号
						if(p.remark && relatedSaleOrderNo.indexOf(p.remark) == -1){
							relatedSaleOrderNo.push(p.remark);
						}
					}
					/*//品名保留长度12其余省略号
					var oldText =proname;  
					if (oldText.length >12) {  
					    var newText = oldText.substring(0,12)+"...";  
					    proname=newText;  
					}*/
									
					//口味行ADD BY CPQ
					var taste_tr = "<tr class='tastes_tr' data-tastes='"+(p.tastes || "")+"' data-cart_id='"+p.id+"'><td>口味:</td><td colspan='7'>"+(p.tastes || "")+"</td></tr>";
					
					//导购员行ADD BY CPQ
					var employee_td = industry != "1003" && getSetting("itemGuideEnabled") == 1 ? "<td class='employee_click_td'" +
							" data-employee_id='"+ p.employee_id + "'" +
							" data-employee_name='"+ p.employee_name + "'" +
							" data-cart_id='"+ p.id + "'" +
							">" +(p.employee_name ? "<span class='btn btn-stroke'>"+p.employee_name+"</span>" : "<span class='btn btn-stroke'>导购</span>")+"</td>" : "";
					
					//操作按钮(赠品与删除)
					var giftPart = p.gift_enabled!=null && p.gift_enabled == 1?
							"<span class='btn btn-stroke waves-effect' onclick='setGift(" + p.id + "," + (p.gift_flag==0?1:0) + ")'><i class='fa fa-gift'></span></i>" : "<span class='nullGift'></span>";
							
					var row_tr = "<tr data-refund_flag='"+p.refund_flag+"' data-remark='"+(p.remark || "")+"' id='"+p.id+"' class='"+p.product_id+" "+(p.parent_seq ? "tastes_tr" : "cart_tr")+"'"+(p.parent_seq ? "style='font-weight: normal !important;'" : "")+" data-parent_seq='"+(p.parent_seq || 0)+"' data-product_id='"+p.product_id+"'>"
						+ "<td>" + (!p.parent_seq ? "<span class='cart-index'>"+(++index)+"</span>" : "") + (p.discount==0 && p.gift_flag==1?'<br /><i class=\"fa fa-gift text-xs\"></i>':'') + "</td>"
						+ "<td class='clip ellipsis-1' title='"+p.product_name + custProps+"'><p class='product_name ellipsis-1 no-margin no-padding' style='max-width:150px;'>" + proname + "</p><p class='no-margin no-padding text-muted-l barcode' style='max-width:150px;'>" + p.barcode + "</p>" + "</td>"
						+ "<td class='p-v-sm ori_price'>" + doDecimal(p.price) + "</td>"
						+ "<td>" + "<input class='form-control md-input remember cart_item_input' " + discoutPart + "  type='tel' name='discount' value='" + Math.round(p.discount) + "' style='' />" + "</td>"
						+ "<td>" + "<input class='form-control md-input price remember cart_item_input' " + salePricePart + " type='tel' name='sale_price' value='" + doDecimal(p.sale_price) + "' />" + "</td>"
						+ "<td class='form-inline'>" + "<input class='form-control md-input remember cart_item_input' " + qtyPart + " type='tel' step='1'  name='qty' value='" + fmtNumber(p.qty,3,"ROUND",false) + "' />"
						+ (isOpenES && (p.scale_flag !=null && p.scale_flag ==2)? "<a href='#' title='称重'><button class='text-success fa fa-flask es-btn' name='es_btn'>称重</button></a>" : "") + "</td>" 
						+ "<td style='text-align:right' class='bottom subtotal'>" + doDecimal(p.subtotal) + "</td>"
						+ employee_td
						+ "<td style='text-align:center'>" + removePart + giftPart + "</td></tr>";
					if (cLayout == "FULL") {// 全屏
						row_tr = "<tr data-refund_flag='"+p.refund_flag+"' data-remark='"+p.remark+"' id='"+p.id+"' class='"+p.product_id+" "+(p.parent_seq ? "tastes_tr" : "cart_tr")+"' "+(p.parent_seq ? "style='font-weight: normal !important;'" : "")+" data-parent_seq='"+(p.parent_seq || 0)+"' data-product_id='"+p.product_id+"'>"
						+"<td>" + (i + 1) + (p.discount==0 && p.gift_flag==1?'<i class=\"fa fa-gift text-xs\"></i>':'') 
						+ "</td><td class='barcode'>" + p.barcode + "</td><td class='product_name ellipsis-1'>" + p.product_name + custProps 
						+ "</td><td class='ori_price'  style='text-align:center'>" + doDecimal(p.price) + "</td><td>" 
						+ "<input class='form-control md-input remember' " + discoutPart + "  type='tel' name='discount' value='" + Math.round(p.discount) + "'  />" 
						+ "</td><td style='text-align:center'>" + "<input class='form-control md-input price remember' " + salePricePart + " type='tel' name='sale_price' value='" + doDecimal(p.sale_price) + "' style='text-align:center !important' />"
						+ "</td><td class='form-inline'>" + "<input class='form-control md-input remember' " + qtyPart + " type='tel' step='1'  name='qty' value='" + fmtNumber(p.qty,3,"ROUND",false) + "'  />" + (isOpenES && (p.scale_flag !=null && p.scale_flag ==2)? "<a href='#' title='称重'><button class='text-success glyphicon glyphicon-save es-btn' name='es_btn'>称重</button></a>" : "")
						+ "</td><td class='subtotal' style='text-align:right'>" + doDecimal(p.subtotal) + "</td>"
						+ employee_td
						+"<td style='text-align:right'>" + removePart + giftPart + "</td></tr>";
					}
					$("#cart tbody").append(row_tr);
					
					//口味启用条件 ADD BY CPQ
					if(industry == "1003" && getSetting("tastes_enabled") == 1 && p.tastes){
						$("#cart tbody").append(taste_tr);//口味行 ADD BY CPQ 201703
					}
					
					totalQty += parseFloat(p.qty);
					totalPrice += parseFloat(p.subtotal);// 使用转成浮点
					var subTotalPoints = p.refund_flag ==0?p.subtotal_points:0-p.subtotal_points;
					var saleType = $("#customer_sale_type").val();
					totalPoints += Number(subTotalPoints);
					totalCommission += p.subtotal_commission;//V2:退货负数在soi中已处理
					totalListPrice += parseFloat(p.price)*p.qty;// 使用转成浮点
					
					var subtotalSaleListPrice = p.refund_flag ==0?parseFloat(p.price)*p.qty:0;
					var subtotalSalePrice = p.refund_flag ==0?parseFloat(p.subtotal):0;
					var subtotalDiscountEnabledListPrice = p.discount_enabled==1 && p.gift_flag!=1?parseFloat(subtotalSaleListPrice):0;
					var subtotalDiscountEnabledSalePrice = p.discount_enabled==1?parseFloat(p.subtotal):0;
					var subtotalRefundPrice = p.refund_flag ==1?0-parseFloat(p.subtotal):0;//转正数
					
					var subtotalCut = subtotalDiscountEnabledListPrice*(100-minDiscount)/100;//可直减的金额小计
					
					totalSaleListPrice += subtotalSaleListPrice;
					totalSalePrice += subtotalSalePrice;
					totalDiscountEnabledListPrice += subtotalDiscountEnabledListPrice;
					totalDiscountEnabledSalePrice += subtotalDiscountEnabledSalePrice;
					totalRefundPrice += subtotalRefundPrice;
					
					totalCut += subtotalCut;//可直减的金额合计
				}
				
				if(industry == "1003" && getSetting("tastes_enabled") == 1){
					$("#cart tbody tr.cart_tr").each(function(){
						var parentSeq = $(this).attr("id");
						$("#cart tbody tr.tastes_tr[data-parent_seq='"+parentSeq+"']:last").after($(this).next(".tastes_tr"))
					})
				}
				
				setCurrentRowBg();//独立设置当前行背景色
				
				//需要抹零,其它合计都使用原值,用绝对值抹零,再乘以calc
				var calc = totalPrice < 0 ? -1 : 1;
				var calc1 = totalListPrice-totalPrice < 0 ? -1 : 1;
				var calc2 = totalListPrice < 0 ? -1 : 1;
				var calc3 = totalPoints < 0 ? -1 : 1;
				
				totalPrice = doDecimal( doRound( Math.abs(totalPrice) ) * calc );			
				totalSaving = doRound(Math.abs(totalListPrice - totalPrice)) * calc1;
				totalPoints = doDecimal( doRound( Math.abs(totalPoints) ) * calc3 );	
				
				$("#order_type").val(orderType);
				$("#related_sale_order_no").val(relatedSaleOrderNo.length > 0 ? relatedSaleOrderNo.join(',') : "");
				
				// 有内容,才载入合计行
				if ($("#cart tbody").children("tr").length > 0) {
					
					$("#total_qty").val(totalQty);
					$("#total_price").val(totalPrice);
					$("#total_points").val(totalPoints);
					$("#total_commission").val(totalCommission);
					$("#total_list_price").val(totalListPrice);
					$("#total_sale_list_price").val(totalSaleListPrice);
					$("#total_sale_price").val(totalSalePrice);
					$("#total_discount_enabled_list_price").val(totalDiscountEnabledListPrice);
					$("#total_discount_enabled_sale_price").val(totalDiscountEnabledSalePrice);
					$("#total_refund_price").val(totalRefundPrice);
					$("#total_saving").val(totalSaving);

					$("#spn_total_discount_enabled_list_price").text("最多可直减 "+doDecimal(totalCut)+ "元");
					$("#t_sale_price").text(totalPrice);
					$("#t_points").text(doDecimal(totalPoints));
					$("#t_list_price").text(doDecimal(doRound(Math.abs(totalListPrice)) * calc2 ));
					$("#t_saving").text(totalSaving);
					$("#total_cut").val(totalCut);
					$("#t_qty").text("("+totalQty+")");
					
					if(!$("#customer_no").val()){
						$("#spn_t_points").hide();
					}
					else{
						$("#spn_t_points").show();
					}
					
					//原价、直减
					$("#total-desc").show();
				}
				
				//console.log("载入结束行");
				
				//生产单号（流水号）,added by fandy AT 20150918
				var saleOrderNo = ((new Date()).valueOf()).toString()+getRandomNumber(10001,99999);//时间戳+5位随机数
				console.log("-------------------------- 订单号@loadCart()->"+saleOrderNo);
				$("#sale_order_no").val(saleOrderNo);
			}
			
			else{
				$("#t_sale_price").text(0);
				$("#product_employee_id").val($("#employee_id").val());
				$("#product_employee_name").val($("#employee_name").val());
				//清空购物车hidden
				$("#cart_hidden input[type='hidden']").val("");
				$("#order_type").val(0);
			}
			inform("gen_cs");
			//ADD BY CPQ_PAGE 20170324
			$("#btnCheckout").prop("disabled",false);
			cartUpdating = false;
			cartLoading = false;
		}, function(){
			alert("重新载入购物车商品时发生错误.");
			$("#btnCheckout").prop("disabled",false);
			cartUpdating = false;
			cartLoading = false;
		});
	},null,function(){
		cartUpdating = false;
		cartLoading = false;
	});

}

//设置当前购物车当前行背景色，2015-01-19
function setCurrentRowBg() {
	var args = arguments;
	db.transaction(function(tx) {
		tx.executeSql('SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? ORDER BY update_date DESC,id DESC', [outletId], function(tx, results) {

			var len = results.rows.length, i;
			if(len>0){
				var currentRowId = results.rows.item(0).id;
				
				$(".currentRow").removeClass('currentRow highContrast');
				$("#cart tbody tr").each(function(){
					if($(this).attr("id") == currentRowId){
						var lastTasteTr = [];
						if($(this).data("parent_seq")){
							var parentSeq = $(this).data("parent_seq");
							$("#cart tbody tr#"+parentSeq).addClass("currentRow");
							$(".tastes_tr[data-cart_id='"+parentSeq+"']").addClass("currentRow");
							$(".tastes_tr[data-parent_seq='"+parentSeq+"']").addClass("currentRow");
							
							lastTasteTr = $(".tastes_tr[data-parent_seq='"+parentSeq+"']:last");
						}else{
							$(this).addClass("currentRow");
							$(".tastes_tr[data-cart_id='"+currentRowId+"']").addClass("currentRow");
							$(".tastes_tr[data-parent_seq='"+currentRowId+"']").addClass("currentRow");
							
							lastTasteTr = $(".tastes_tr[data-parent_seq='"+currentRowId+"']:last");
						}
						vscroll2viewp(lastTasteTr.length > 0 ? lastTasteTr : $(this),$('#cart_container'),20);
					}
				});
				
				setCartCurrentRowColor();

				//20180516:Add by dph
				if(0 < args.length) {
					// 获取当前选中的购物商品，方便回调使用自动称重
					var callback = args[0];
					if('function' === typeof(callback)) {
						callback.apply(this, args);
					}
				}

			}
		});
	});
}

//取得购物车中当前商品销售数量:用于无库存禁止销售
function getSaleQtyInCart(pid){
	var totalQty = 0;
	var len = $("#cart tbody tr."+pid).length;
	if(len>0){
		for(var i=0; i<len; i++){
			var qty = $("#cart tbody tr."+pid).eq(i).find("input[name='qty']").val();
			totalQty += parseFloat(qty);
		}
	}		
	return totalQty;
}

//添加购物车预处理
function addCartPre(barcode) {
	console.log("--------------------- barcode @ addCartPre() -> " + barcode);
	if (barcode.length==0) return false;
	
	cartLoading = true;
	$(".ui-autocomplete").css("display","none");//当按下扫描回车时,autocomplete item list隐藏,by fandy AT 20170525
	
	//解析称重商品的条码,并把数量传入addCart();
	var hackbarcode = barcode;
	var qty = 1;
	var priceType = localStorage.getItem("PRICE_TYPE");
	var zeroStockDisabled = getSetting("cZeroStockDisabled");
	
	//取得条码秤设置 START
	//条码秤设置示例:{"method":"1","length":13,"flag":"99","barcode":"3-7","digit":"8-9","decimal":"10-12"}
	var scale_option = getSetting("SCALE_OPTION");
	if(typeof(scale_option)!='undefined' && scale_option!=null && scale_option !='' && barcode.substring(0,2) == scale_option.flag){//如果有条码秤设置 且条码前两位等于称重商品标识符,表示该商品是称重商品
		//console.log("--------------------- 条码秤设置 整数/小数位 @ addCartPre() -> "+ scale_option.digit + "/" + scale_option.decimal);
		var scale_barcode_arr = scale_option.barcode.split("-");	
		hackbarcode = barcode.substring(parseInt(scale_barcode_arr[0])-1,parseInt(scale_barcode_arr[1]));
		console.log("--------------------- 称重商品条码 hackbarcode @ addCartPre() -> " + hackbarcode);
	}
	//取得条码秤设置 END

	db.transaction(function(tx) {
		tx.executeSql(
				"SELECT  p.*, s.qty as stock FROM PRODUCTS p "
				+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
				+" WHERE p.company_id=? AND p.outlet_id=? AND p.active='ON' AND p.del_flag=0 AND (p.barcode = ? OR p.item_no = ?) limit 100 ", 
				[companyId, outletId, hackbarcode.toUpperCase(), hackbarcode ], function(tx, results) {
			if (results.rows.length > 0) {
				if (results.rows.length > 1) {
					cartLoading = false;
					// 显示一码多品矩阵,//称重商品不允许一码多品
					showProducts(hackbarcode);
				} else {
					var product = $.extend({}, results.rows.item(0));
					if(product.stock==null) product.stock = 0;
					
					//非称重商品时,无库存禁止销售> 当前库存-销售<0 禁止销售
					var saleQty = getSaleQtyInCart(product.product_id)+qty;
					console.log("---------------------销售数量 saleQty @ addCartPre() ->"+saleQty);
					//if(product.scale_flag == 0 && zeroStockDisabled == 1 && product.stock <= 0){
					if(product.scale_flag == 0 && zeroStockDisabled == 1 && product.stock-saleQty < 0){
						//message("没有库存,禁止销售!");
						message("库存不足,禁止销售!<br>库存数量"+product.stock+",销售数量"+saleQty+".",3000);
						return;
					}
					
					//解析称重商品数量与金额小计,added by fandy AT 2015-12-23 start
					if(scale_option!='' && product.scale_flag == 1){
						var digit_arr = scale_option.digit.split("-");
						var decimal_arr = scale_option.decimal.split("-");
						
						var dd = barcode.substring(parseInt(digit_arr[0])-1,parseInt(digit_arr[1]))+"."+barcode.substring(parseInt(decimal_arr[0])-1,parseInt(decimal_arr[1]));
						console.log("--------------------- 称重条码数字位 @ addCartPre() -> " + dd);
						
						var scale_method = scale_option.method;
						console.log("--------------------- 称重条码模式 @ addCartPre() -> " + scale_method);
						if(scale_method == 1){//1为金额,2为数量
							qty = parseFloat(dd)/product.price;
						}
						if(scale_method == 2){//1为金额,2为数量
							qty = parseFloat(dd);
						}
						console.log("---------------------称重商品  qty @ addCartPre() -> " + qty);
					}						
					console.log("---------------------scale_flag/qty @ addCartPre() -> " +product.scale_flag +"/"+ qty);					
					//解析称重商品数量与金额小计,added by fandy AT 2015-12-23 end
					
					cartLoading = false;
					addCart(product.product_id, fmtNumber(qty,3,"ROUND",false));//移除小计参数,by fandy
					$("#bar_code").val();
					
				}
			} else {
				alert("没有找到与 "+barcode+" 相关的商品。", () => {
					$("#bar_code").val('');
				});
				cartLoading = false;
			}

		}, function(){
			cartLoading = false;
		});
	},null,function(){
		cartLoading = false;
	});
}

// 添加无码商品到购物车,1-16
function addNoBarcodeProduct2Cart() {
	// alert("execute addNoBarcodeProduct2Cart()");

	var productName = $("#product_name_4_nb").val();
	var price = $("#price_4_nb").val();
	console.log("------------------------ discountEnabled->"+$("#discount_enabled_4_nb").prop("checked"));
	var discountEnabled = $("#discount_enabled_4_nb").prop("checked")?1:0;	
	var salePrice = price;
	var subtotal = salePrice;
	
	var point = $("#point_4_nb").val() || 0;
	
	
	//校验输入格式
	var ths = $("#product_name_4_nb");
	if(productName){
		var regx = /^(([^\^\.<>%&',;=?$"':#@!~\]\[{}\\/`\|])*)$/g;
		if(!regx.test(productName)){
			$(ths).next().text("名称不允许包含特殊字符!").css({"color":"#ff0000","font-weight":"bold"});
			$(ths).css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$(ths).next().text("").removeAttr("style");
	    	$(ths).removeAttr("style");
		}
	}
	else{
		productName = "无码商品";
	}
	
	ths = $("#price_4_nb");
	if(!price){
		$(ths).next().text("标价必须填写!").css({"color":"#ff0000","font-weight":"bold"});
		$(ths).css("border", "1px solid #ff0000").focus().select();
		return;
	}
	else{
		var reg2 = /^[+-]?\d+\.?\d*$/;// 任意整数或小数
		if (!reg2.test(price)) {
			$(ths).next().text("标价必须是数字!").css({"color":"#ff0000","font-weight":"bold"});
			$(ths).css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$(ths).next().text("").removeAttr("style");
	    	$(ths).removeAttr("style");
		}
	}
	
	ths = $("#point_4_nb");
	var reg4 = /^[+-]?\d+\.?\d*$/;// 任意整数或小数
	if (! (reg4.test(point) && point>=0) ) {
		$(ths).next().text("积分不小于零的数字!").css({"color":"#ff0000","font-weight":"bold"});
		$(ths).css("border", "1px solid #ff0000").focus().select();
		return;
	}
	else{
		$(ths).next().text("").removeAttr("style");
    	$(ths).removeAttr("style");
	}
	
	var pointRate = point>0?point/salePrice:0;	
	var pointEnabled = point>0?1:0;
	console.log("------------------------ 无码商品-> 品名 : " + productName + " ,标价 :" + price 
			+ " , 参与折扣 : " + discountEnabled + " , 积分 : " + point);
	
	if(pointEnabled==null || pointEnabled=='')
		pointEnabled = 0;
	
	if(pointRate==null||pointRate=='')
		pointRate=100;
	
	var employeeId = $("#product_employee_id").val() || 0;
	var employeeName = $("#product_employee_name").val() || "";
	db.transaction(function(tx) {
		tx.executeSql(
			'INSERT INTO SHOPPINGCARTS (outlet_id, category_id , category_name, brand_id , brand_name, supplier_id , supplier_name, product_id, product_name, barcode, unit, supply_price, price, discount_enabled, vip_discount_type, commission_type, commission_rate, commission_amount, discount, wholesale_price, vip_price, sale_price, qty, subtotal,point_enabled,point_rate,subtotal_points,subtotal_commission,refund_flag,update_date,employee_id,employee_name , prom_type, prom_id, allow_double_discount,gift_enabled,gift_flag) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', 
			[outletId, 0, "", 0, "", 0, "", 0, productName, "", "", 0, price, discountEnabled, 0, "0", "0", 0, 100, "0", "0", parseFloat(doDecimal(salePrice)), 1, parseFloat(doDecimal(subtotal)),pointEnabled,pointRate,parseFloat(doDecimal(point)),0,0, parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S"), employeeId,employeeName , 0,0,0,0,0], function(tx, result) {
				//loadCart2("add",null,null);// 加载购物车
				loadCartItems("add", null, null, null);
				$('#noBarcodeModal').modal('hide');
				customDisp(1,doDecimal(salePrice));
			}, null);
	});
}


/**
 * 添加购物车
 * @param id : 商品ID
 * @param qty : 添加数量
 * @returns
 */
function addCart(id, qty) {
	cartLoading = true;
	// alert("execute addCart()");
	console.log("--------------------- id,qty@ addCart() -> ",id,qty);
	
	var mergeProduct = getSetting("cMergeProduct");// 是否合并相同条码,01-03
	var zeroStockDisabled = getSetting("cZeroStockDisabled");//无库存禁止销售
	var relatedCartIds;
	
	qty = parseFloat(qty);
	db.transaction(function(tx) {
		tx.executeSql(
				"SELECT p.*, s.qty as stock FROM PRODUCTS p "
				+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
				+" WHERE p.company_id=? AND p.outlet_id=? AND  p.active='ON' AND p.del_flag=0 AND p.product_id = ? ", 
				[companyId, outletId, id ], function(tx, results) {
			
			if (results.rows.length > 0) {
				
				var product = $.extend({}, results.rows.item(0));
				if(product.stock==null) product.stock = 0;
				
				//无库存禁止销售> 当前库存-销售<0 禁止销售
				var saleQty = getSaleQtyInCart(product.product_id)+qty;
				console.log("---------------------销售数量 saleQty @ addCart() ->"+saleQty);
				//if(product.scale_flag == 0 && zeroStockDisabled == 1 && product.stock <= 0){
				if(product.scale_flag == 0 && zeroStockDisabled == 1 && product.stock-saleQty < 0){
					//message("无库存禁止销售!");
					message("库存不足,禁止销售!<br>库存数量"+product.stock+",销售数量"+saleQty+".",3000);
					return;
				}
				
				if(mergeProduct==1 && saleQty>qty){//表示合并收银时购物车已存在同一商品
					var cartitemDiscount = $("#cart tbody tr."+id).find("input[name='discount']").val();
					var cartitemSalePrice = $("#cart tbody tr."+id).find("input[name='sale_price']").val();
					product["discount"] = cartitemDiscount;
					product["sale_price"] = cartitemSalePrice;
				}
					
				
				//wrap price start
				wrapPrice(product, qty, tx, function(discount, salePrice, promotion, cartIds){
					console.log("********************* discount,salePrice FROM wrapPrice() AT addCart()->",discount, salePrice);
					relatedCartIds = cartIds;
					
					var updateDate = parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S");
					var promType = promotion != null?promotion.prom_type:null;
					var promId = promotion != null?promotion.promotion_id:null;
					var allowDoubleDiscount = promotion != null?promotion.allow_double_discount:null;
					
					// 先判断是否存在于购物车中,不存在或不合并相同商品的话,则插入(insert),存在的话且合并相同商品,则增加数量(update)
					//处理本行数据 start
					tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE outlet_id=? AND refund_flag=0 AND product_id = ? ", [ outletId, id ], function(tx, results) {
						// alert(results.rows.length);
						
						if (results.rows.length > 0 && mergeProduct == 1) {// 更新:更新且同码合并
							// alert("在购物车中已存在!");
							
							//因为有买送促销,所以有可能当数量发生变化时,价格也会发生变化,所以不仅要处理数量,也要处理价格,2014-6-13
							var cartItem = results.rows.item(0);
							var newQty = parseFloat(cartItem.qty) + parseFloat(qty);
							// alert(newQty);
							console.log("--------------------- newQty->" + newQty);
							
							/*
							var subtotal = parseFloat(salePrice) * newQty;	
							
							var subtotalPoints = 0;
							if(cartItem.point_enabled==1){
								subtotalPoints = subtotal*cartItem.point_rate;
							}
							
							//V2:提成
							var subtotalCommission = getCommission(product,newQty,subtotal);
							
							console.log("--------------------- UPDATE : discount/sale_price/subtotal/subtotalPoints/subtotalCommission->" 
									+ discount + "/" + salePrice + "/" + subtotal + "/" + subtotalPoints+"/"+subtotalCommission);

							tx.executeSql("UPDATE SHOPPINGCARTS SET discount = ?, sale_price = ?, qty = ?,subtotal = ?, subtotal_points = ?, subtotal_commission = ?, update_date=?  WHERE refund_flag=0  AND outlet_id=? AND  product_id = ? ", 
									[discount, salePrice, newQty, subtotal, subtotalPoints, subtotalCommission, updateDate, outletId, id ], 
									function(tx, r) {
								// successfully
								console.log("### 更新成功 ###");
								customDisp(1,doDecimal(salePrice));//客显需要小数点处理
							}, null);
							
							
							//关联行排除本行
							for(var i in cartIds){
								if(cartIds[i] == cartItem.id){
									cartIds.splice(i,1);
									break;
								}
							}
							*/
							
							//调用更新数量方法
							var obj = $("#cart tbody tr."+id).find("input[name='qty']");
							obj.val(newQty);
							updateCart(cartItem.id, obj, 2);
							
							//clear barcode
							$('#bar_code').val('');
							//$('#bar_code').focus();
							$('#bar_code').blur();
							
							return false;
							
						} else {// 插入:新增或同码不合并
							//addOrderDetail(tx, product, discount, salePrice, qty, promotionFlag,null);
							var subtotal = salePrice*qty;
							var subtotalPoints = 0;
							if(product.point_enabled==1){
								subtotalPoints = subtotal*product.point_rate;
							}
							
							//V2:提成
							var subtotalCommission = getCommission(product,qty,subtotal);
							
							subtotal = doDecimal(subtotal);
							subtotalPoints = doDecimal(subtotalPoints);
							subtotalCommission = doDecimal(subtotalCommission);
							
							console.log("--------------------- INSERT : discount/sale_price/subtotal/subtotalPoints/subtotalCommission->"
									+ discount + "/" + salePrice + "/" + subtotal + "/" + subtotalPoints+"/"+subtotalCommission);
							//var updateDate = parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S");
							
							var employeeId = $("#product_employee_id").val() || 0;
							var employeeName = $("#product_employee_name").val() || "";
							var giftEnabled = product.gift_enabled!=null?product.gift_enabled:0;
							console.log("### gift enabled->"+giftEnabled);
							// refund flag:0 is sale,1 isrefund
							tx.executeSql('INSERT INTO SHOPPINGCARTS (outlet_id, category_id , category_name, brand_id , brand_name, supplier_id , supplier_name, product_id, product_name, barcode,size,cust_props, unit,supply_price, price, discount_enabled, vip_discount_type, commission_type, commission_rate, commission_amount,  discount, wholesale_price, vip_price, sale_price, qty, subtotal,point_enabled,point_rate,subtotal_points, subtotal_commission, refund_flag, scale_flag,update_date,tastes,employee_id,employee_name,item_no, prom_type, prom_id, allow_double_discount,gift_enabled,gift_flag) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', 
								[outletId, product.category_id, product.category_name, product.brand_id, product.brand_name, product.supplier_id, product.supplier_name, product.product_id, product.product_name, product.barcode, product.size, unescape(product.cust_props), product.unit,
								  product.supply_price, product.price, product.discount_enabled, product.vip_discount_type, product.commission_type, product.commission_rate, product.commission_amount , discount, product.wholesale_price, product.vip_price, salePrice, qty, parseFloat(subtotal), product.point_enabled, product.point_rate, parseFloat(subtotalPoints) , parseFloat(subtotalCommission), 
								  0, product.scale_flag,  updateDate,null,employeeId,employeeName,product.item_no,
								  promType, promId ,allowDoubleDiscount, giftEnabled,0],function(tx, r) {
										// successfully
										console.log("### 插入成功 ###");
										customDisp(1,doDecimal(salePrice));
									},function(tx, error) {
										console.log('error: ' + error.message);
									});
						}
						
						//处理关联行数据 start
						//使用场景(promotion.prom_type >2):在买x（不合并）、满立X促销时，添加购物车会影响已存在的关联行(cartIds)数据
						if(promotion != null && promotion.prom_type >2 
								&& cartIds!=null && cartIds.length>0){
							updateRelatedCartItems(tx, cartIds, discount, salePrice, updateDate, promotion);
						}
						//处理关联行数据 end
						
						//clear barcode , add by fandy 2015/03/03
						$('#bar_code').val('');
						//$('#bar_code').focus();
						$('#bar_code').blur();
						
					}, function(tx, error) {
						alert("Error : " + error.message);
						cartLoading = false;
					});
					// 处理本行数据 end
					
					//合并收银时，cartIds中去除同一商品的购物车记录的ID(因为在处理本行数据中已处理，不能重复处理)；
					/*if(mergeProduct == 1){
						var cartTr = $("#cart tbody tr[data-product_id='"+id+"']");
						if(cartTr.length > 0){
							var currCartId = cartTr.eq(0).attr("id");
							for(var i in cartIds){
								if(cartIds[i] == currCartId){
									cartIds.splice(i,1);
									break;
								}
							}
						}
					}*/
					
					
					
				});
				//wrap price end

			} else {
				alert("没有找到匹配的商品。");
				cartLoading = false;
			}
		}, function(tx, error) {
			alert("Error : " + error.message);
			cartLoading = false;
		});
	},function(){
		cartLoading = false;
	},function(){
		//局部刷新UI
		cartLoading = false;
		loadCartItems("add", null, id, relatedCartIds);
	});
}


/**
 * 【处理关联行购物车DB数据】
 * 更新购物车中的商品集：多个同一商品（买X），或同组商品（满立X）
 * @param tx
 * @param cartIds 需更新的购物车ID集(数组)
 * @param discount 买X时的统一折扣 ；满立X的统一折扣
 * @param salePrice 买X时的统一售价；【满立X时因为商品不同，不可使用统一售价！】
 * @param updateDate 购物车记录统一更新时间
 * @param promotion 促销主题
 * @returns
 */
function updateRelatedCartItems(tx, cartIds, discount, salePrice, updateDate, promotion){
	var promType = promotion.prom_type;
	
	var totalListPrice = 0;
	var totalSalePrice = 0;
	
	var _item;
	
	console.log("### cartIds : " + cartIds);
	tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE id IN ("+cartIds.join(',')+")", [], function(tx, result1) {
		console.log("### result1:"+result1,result1.rows.length);
		for(var i = 0; i < result1.rows.length; i++){
			var currCart = result1.rows.item(i);
			_item = result1.rows.item(0);//使用第一个商品的小计进行修正
			
			
			//满立X时因为商品不同，不可使用统一售价，根据统一折扣独立计算售价
			if(promType == 5 || promType == 6 || promType == 11){
				salePrice = currCart.price * discount/100;
			}
			
			//计算每行的subtotal,subtotal_points,subtotal_commission
			var newSubtotal = salePrice*currCart.qty;
			
			var newProduct = new Object();
			newProduct.commission_type = currCart.commission_type;
			newProduct.commission_rate = currCart.commission_rate;
			newProduct.commission_amount = currCart.commission_amount;
			
			var newSsubtotalCommission = getCommission(newProduct,currCart.qty,newSubtotal);
			
			var newSubtotalPoints = 0;
			if(currCart.point_enabled==1){
				newSubtotalPoints = newSubtotal*currCart.point_rate;;
			}
			

			totalListPrice += currCart.price*currCart.qty;
			totalSalePrice += newSubtotal;
			
			tx.executeSql("UPDATE SHOPPINGCARTS SET discount = ?, sale_price = ?,subtotal = ?, subtotal_points = ?,subtotal_commission = ?, update_date = ? WHERE id = ?", 
					[ discount, parseFloat(doDecimal(salePrice)), parseFloat(doDecimal(newSubtotal)), parseFloat(doDecimal(newSubtotalPoints)), parseFloat(doDecimal(newSsubtotalCommission)),  updateDate,currCart.id], 
					function(tx, r) {
				console.log("### 成功更新关联行数据 ###");
			}, function(tx, error) {
				console.log("Error : " + error.message);
			});
		}
		
		//修正满立减时折扣转换造成的金额误差 start
		if((promType == 5 || promType == 11) && _item != null){
			//spendSaveDiff为零表示立减正确，正数表示减少了，负数表示减多了
			var spendSaveDiff =  (totalListPrice- promotion.savex) - totalSalePrice;
			console.log("### 满立减金额误差 spendSaveDiff：" + spendSaveDiff);
			if(spendSaveDiff !=0 ){
				var _id = _item.id;
				var _subtotal = parseFloat(_item.subtotal)+parseFloat(spendSaveDiff);
				var _salePrice = _subtotal/_item.qty;
				var _discount = Math.round(_salePrice/_item.price*100);
				var _subtotalPoints = 0;
				if(_item.point_enabled==1){
					_subtotalPoints = _subtotal*_item.point_rate;
				}
				
				//V2:创建prouct对象,设置提成规则
				var product = new Object();
				product.commission_type = _item.commission_type;
				product.commission_rate = _item.commission_rate;
				product.commission_amount = _item.commission_amount;
				
				//V2:提成
				var _subtotalCommission = getCommission(product,_item.qty,_subtotal);
				
				tx.executeSql("UPDATE SHOPPINGCARTS SET discount = ?,sale_price = ?,subtotal = ?, subtotal_points = ?, subtotal_commission = ?, update_date = ? WHERE id = ? ", 
						[ _discount, parseFloat(doDecimal(_salePrice)), parseFloat(doDecimal(_subtotal)), parseFloat(doDecimal(_subtotalPoints)), parseFloat(doDecimal(_subtotalCommission)), _id, updateDate ], function(tx, r) {
					console.log("### 修正满立减金额误差 ###");
				}, null);
			}
		}
		//修正满立减时折扣转换造成的金额误差 end
	},function(tx, error) {
		console.log("Error : " + error.message);
	});
}



/**
 * 局部刷新购物车明细(局部载入/刷新),用于addCart、updateCart、removeCart等单品操作时，购物车UI局部刷新，by fandy AT 201711
 * 
 * @param act : 动作,添加,更新,删除
 * @param cartid : 购物车行ID,shoppingcart.id,当前操作的购物车行号
 * @param productid : 财物车行商品ID,shoppingcart.product_id ,当前操作的商品ID
 * @param cartIds : 需要刷新的购物车行ID集
 */
function loadCartItems(act,cartid,productid,cartIds) {
	cartLoading = true;
	//将处理逻辑全部放入executeSql的回调中，解决快速点击橱窗商品时购物车会产生重复的问题 ADD BY CPQ 20161115
	db.transaction(function(tx) {
		//遍历购物车
		tx.executeSql('SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? ORDER BY IFNULL(parent_seq,id) DESC,id ASC', [outletId], function(tx, results) {
			
			var industry = getSetting("Industry");
			var defaultLayout = industry=='1004'?'FULL':'QK';
			var cLayout = localStorage.getItem("QUICKKEY")!=undefined?(JSON.parse(localStorage.getItem("QUICKKEY"))).layout:defaultLayout;
			console.log("**************** cLayout->"+cLayout,cLayout == "FULL");

			var priceType = localStorage.getItem("PRICE_TYPE");
			var pricename = priceType==0?'零售价':'批发售价';
			
			// 载入前先清空购物车表格 > 头部与尾部
			$("#cart thead").empty();
			//$("#cart tbody").empty();
			$("#cart tfoot").empty();
			
			//局部刷新修：取得已存在于购物车UI中的行(主商品与加料) , by fand AT 201708
			var allcartids = [];
			$("#cart tbody tr.cart_tr, #cart tbody tr.tastes_tr").each(function(i){
				if($(this).attr("id"))
					allcartids[i] = parseInt($(this).attr("id"));
			});			
			console.log("########### allcartids",allcartids);
			

			// 20170602:Add by dph
			// 通讯秤值
			var isOpenES = false;
			// 商超版 通用版 可用
			if(1004 == industry || 1000 == industry) {
				if("object" === typeof(esName)) {
					isOpenES = esName['isOpen'] || false;
				}
			}
			
			var employee_th = industry != "1003" && getSetting("itemGuideEnabled") == 1 ? "<th>导购</th>" : "";
			//append header title
			var row_header = "<tr>"
				+"<th>#</th>"
				+"<th>品名</th>"
				+"<th>标价</th>"
				+"<th>折扣</th>"
				+"<th>"+pricename+"</th>"
				+"<th>数量</th>"
				+"<th class='text-right'>小计</th>"
				+ employee_th
				+"<th>&nbsp;&nbsp;</th>"
				+"</tr>";
			if (cLayout == "FULL") {// 全屏
				$("#cart").removeAttr("style");
				//$("#cart").closest(".panel").css("margin-top","5px");
				
				row_header = "<tr>"
					+"<th>#</th>"
					+"<th>条码</th>"
					+"<th>品名</th>"
					+"<th style='text-align:center;'>标价</th>"
					+"<th>折扣</th>"
					+"<th>"+pricename+"</th>"
					+"<th>数量</th>"
					+"<th class='text-right'>小计</th>"
					+ employee_th
					+"<th>&nbsp;</th>"
					+"</tr>";
			}
			
			$("#cart thead").append(row_header);
	
			var len = results.rows.length, i;
			if(len>0){
				//console.log("载入开始行");
				
				var totalQty = 0;//总数量
				var totalPoints = 0;//总积分
				var totalCommission = 0;//V2:提成合计
				
				var totalPrice = 0;//整单金额总计(包含退货金额)
				var totalListPrice = 0;//标价总计
				var totalSaleListPrice = 0;//销售标价总计(即不含退货的标价总计)
				var totalRefundPrice = 0;//退货金额总计
				var totalSalePrice = 0;//销售金额总计(即不含退货的售价总计)
				var totalDiscountEnabledListPrice = 0;//参与打折的标价总计(即不含退货与不参与打折的标价总计)
				var totalDiscountEnabledSalePrice = 0;//参与打折的销售金额总计(即不含退货与不参与打折的售价总计)
				var totalSaving = 0 ;//优惠金额总计
				
				var totalCut = 0;//可直减的金额,需要考虑收银员的最低折扣权限,by fandy
				var role = $("#auth_role").val();
				var minDiscount = role.indexOf('ROLE_CASHIER')>-1?getSetting("cMinDiscount"):0;//最低折扣权限,非收银员,可以全折扣(即0)
				console.log("############## minDiscount->",minDiscount);
				
				var orderType = 0;
				var relatedSaleOrderNo = [];
				var index = 0;
				
				
				//局部刷新修：取得当前插入商品的购物车记录update_date（非合并时，包括其它同一商品记录，update_date是一样的取一次即可） , by fand AT 201708
				var currentRowUpdateDate;//买X同一商品或满立X同组促销商品的DB更新时间是一致的，用此来定位需要刷新UI的行。
				for (i = 0; i < results.rows.length; i++){
					var p = results.rows.item(i);// p是购物车中的明细项
					console.log(p.product_id , productid, act == 'remove' && productid !=0 &&  p.product_id == productid)
					
					if((act == 'add' &&  p.product_id == productid) 
							|| (act == 'update' &&  p.id == cartid)  
								//|| (act == 'remove' && productid !=0 &&  p.product_id == productid))//为何需要productid!=0?
							
							//p.product_id == productide用于买X的同一商品;$.inArray(p.id, cartIds)!=-1用于满立X，行在需要更新的行列中
							|| (act == 'remove' && productid !=0 &&  (p.product_id == productid || $.inArray(p.id, cartIds)!=-1 ) ))
							{
						currentRowUpdateDate = p.update_date;
						break;
					}
				}
				
				var mergeProduct = getSetting("cMergeProduct");// 是否合并相同条码
				for (i = 0; i < len; i++) {
					//console.log("载入第" + (i + 1) + "行");
					// alert(results.rows.item(i).product_name);
					var p = results.rows.item(i);// 此不是商品,是购物车中的明细项
					// console.log(p.id)
					// 如果是退货,设为只读12-30,by
					// fandy,1-3更新,因为退货可能同码,另外收银如果不合同同条码的,在这儿使用条码无法定位唯一,改为ID
					var updateDiscountStr = "onchange='updateCart(\"" + p.id + "\",this,1)' ";
					var updateSalePriceStr = "onchange='updateCart(\"" + p.id + "\",this,3)' ";
					var updateQtyStr = "onchange='updateCart(\"" + p.id + "\",this,2)' ";
					var readonlyStr = "readonly='readonly'";
					var discoutPart = (p.refund_flag == 1 || p.discount_enabled == 0 || p.parent_seq) ? readonlyStr : updateDiscountStr;//退货与不参与打折的都readonly
					var salePricePart = (p.refund_flag == 1 || p.discount_enabled == 0 || p.parent_seq) ? readonlyStr : updateSalePriceStr;//退货与不参与打折的都readonly
					var qtyPart = (p.refund_flag == 1 || p.parent_seq) ? readonlyStr : updateQtyStr;
					var removePart = !p.parent_seq ? "<span class='btn btn-stroke waves-effect' onclick='removeCart(\"" + p.id + "\", \"" + p.product_id + "\")'><i class='fa fa-remove'></span></i>" : "";
					
					//操作按钮(赠品与删除)
					var giftPart = p.gift_enabled!=null && p.gift_enabled == 1?
							"<span class='btn btn-stroke waves-effect' onclick='setGift(" + p.id + ", " + (p.gift_flag==0?1:0) + ")'><i class='fa fa-gift'></span></i>" : "<span class='nullGift' ></span>";
					
					// 2014-2-16,处理附加属性
					var custProps = custPropFormatted(p.cust_props, true);
					//console.log("--------------------- product name/cust_props @ SHOPPINGCART->" +p.product_name + "/"+custProps);
					var proname = p.product_name + custProps;
					//console.log("--------------------- proname/proname.length->" +proname +"/"+proname.length);
					
					//退货商品时，
					if(p.refund_flag == 1){
						//单据类型为退货orderType = 1;
						orderType = 1;
						
						//取得关联单号
						if(p.remark && relatedSaleOrderNo.indexOf(p.remark) == -1){
							relatedSaleOrderNo.push(p.remark);
						}
					}
					
					var cartindex = !p.parent_seq ?++index:index;
					
					/*//品名保留长度12其余省略号
					var oldText =proname;  
					if (oldText.length > 12) {  
					    var newText = oldText.substring(0,12)+"...";  
					    proname=newText;  
					}		*/
					//口味行ADD BY CPQ
					var taste_tr = "<tr class='tastes_tr' data-tastes='"+(p.tastes || "")+"' data-cart_id='"+p.id+"'><td>口味:</td><td colspan='7'>"+(p.tastes || "")+"</td></tr>";
					
					//导购员行ADD BY CPQ
					var employee_td = industry != "1003" && getSetting("itemGuideEnabled") == 1 ? "<td class='employee_click_td'" +
							" data-employee_id='"+ p.employee_id + "'" +
							" data-employee_name='"+ p.employee_name + "'" +
							" data-cart_id='"+ p.id + "'" +
							">" +(p.employee_name ? "<span class='btn btn-stroke'>"+p.employee_name+"</span>" : "<span class='btn btn-stroke'>导购</span>")+"</td>" : "";
					
					var row_tr = "<tr data-refund_flag='"+p.refund_flag+"' data-remark='"+(p.remark || "")+"' id='"+p.id+"' class='"+p.product_id+" "+(p.parent_seq ? "tastes_tr" : "cart_tr")+"'"+(p.parent_seq ? "style='font-weight: normal !important;'" : "")+" data-parent_seq='"+(p.parent_seq || 0)+"' data-product_id='"+p.product_id+"'>"
						+ "<td>" + (!p.parent_seq ?"<span class='cart-index'>"+cartindex+"</span>": "") + (p.discount==0 && p.gift_flag==1?'<br /><i class=\"fa fa-gift text-xs\"></i>':'') + "</td>"
						+ "<td class='clip' title='"+p.product_name + custProps+"'><p class='product_name ellipsis-1 no-margin no-padding' style='max-width:150px;'>" + proname + "</p><p class='no-margin no-padding text-muted-l barcode' style='max-width:150px;'>" + p.barcode + "</p>" + "</td>"
						+ "<td class='p-v-sm ori_price'>" + doDecimal(p.price) + "</td>"
						+ "<td>" + "<input class='form-control md-input remember cart_item_input' " + discoutPart + "  type='tel' name='discount' value='" + Math.round(p.discount) + "' style='' />" + "</td>"
						+ "<td>" + "<input class='form-control md-input price remember cart_item_input' " + salePricePart + "  type='tel' name='sale_price' value='" + doDecimal(p.sale_price) + "' />" + "</td>"
						+ "<td class='form-inline'>" + "<input class='form-control md-input remember cart_item_input' " + qtyPart + " type='tel' step='1'  name='qty' value='" + fmtNumber(p.qty,3,"ROUND",false) + "' />"
						+ (isOpenES && (p.scale_flag !=null && p.scale_flag ==2) ? "<a href='#' title='称重'><button class='text-success fa fa-flask es-btn' name='es_btn'>称重</button></a>" : "") + "</td>" 
						+ "<td style='text-align:right' class='bottom subtotal'>" + doDecimal(p.subtotal) + "</td>"
						+ employee_td
						+ "<td style='text-align:center'>" + removePart + giftPart + "</td></tr>";
					if (cLayout == "FULL") {// 全屏
						row_tr = "<tr data-refund_flag='"+p.refund_flag+"' data-remark='"+p.remark+"' id='"+p.id+"' class='"+p.product_id+" "+(p.parent_seq ? "tastes_tr" : "cart_tr")+"' "+(p.parent_seq ? "style='font-weight: normal !important;'" : "")+" data-parent_seq='"+(p.parent_seq || 0)+"' data-product_id='"+p.product_id+"'>"
						+"<td>" + (!p.parent_seq ?"<span class='cart-index'>"+cartindex+"</span>": "") + (p.discount==0 && p.gift_flag==1?'<i class=\"fa fa-gift text-xs\"></i>':'') 
						+ "</td><td class='barcode'>" + p.barcode + "</td><td class='product_name ellipsis-1'>" + p.product_name + custProps 
						+ "</td><td class='ori_price'  style='text-align:center'>" + doDecimal(p.price) + "</td><td>" 
						+ "<input class='form-control md-input remember' " + discoutPart + "  type='tel' name='discount' value='" + Math.round(p.discount) + "'  />" 
						+ "</td><td style='text-align:center'>" + "<input class='form-control md-input price remember' " + salePricePart + " type='tel' name='sale_price' value='" + doDecimal(p.sale_price) + "' style='text-align:center !important' />"
						+ "</td><td class='form-inline'>" + "<input class='form-control md-input remember' " + qtyPart + " type='tel' step='1'  name='qty' value='" + fmtNumber(p.qty,3,"ROUND",false) + "'  />" + (isOpenES && (p.scale_flag !=null && p.scale_flag ==2) ? "<a href='#' title='称重'><button class='text-success glyphicon glyphicon-save es-btn' name='es_btn'>称重</button></a>" : "")
						+ "</td><td class='subtotal' style='text-align:right'>" + doDecimal(p.subtotal) + "</td>"
						+ employee_td
						+"<td style='text-align:right'>" + removePart + giftPart + "</td></tr>";						
					}
					//console.log("### 局部刷新的行:\n"+row_tr);
					//$("#cart tbody").append(row_tr);
					
					//局部刷新修改 START
					//console.log(act,p.id, allcartids,$.inArray(p.id, allcartids),productid,currentRowUpdateDate);
					if(act=='add'){
						//不存在的shoppingcart.id，则新插入在最上方
						if($.inArray(p.id, allcartids)==-1){
							$("#cart tbody").prepend(row_tr);
						}
						
						//如果存在于购物车且为合并收银，当同一商品时，替换此行，注意轻餐饮版不合并收银
//						var mergeProduct = getSetting("cMergeProduct");// 是否合并相同条码
						if($.inArray(p.id, allcartids)!=-1 && mergeProduct == 1 && p.product_id == productid){
							$("#cart tbody tr#"+p.id).replaceWith(row_tr);
						}
						
						
						//买折/买送促销,非合并,触发促销条件时,原同一商品价格发生变化,需要替换
						//实现方法:购物车记录的update_date与当前插入的相同（如有触发买折/买送促销，同一商品的一定相同）,都需要替换
						if(mergeProduct != 1 
								&& $.inArray(p.id, allcartids)!=-1 && (p.prom_type == 3 || p.prom_type == 4) &&  p.update_date == currentRowUpdateDate){
							$("#cart tbody tr#"+p.id).replaceWith(row_tr);
						}
						
						//满立X促销,触发促销条件时,原同一促销主题的商品价格发生变化,需要替换
						//实现方法:购物车记录的update_date与当前插入的相同（如有触发满立X促销，同一促销主题的商品的一定相同）,都需要替换
						if($.inArray(p.id, allcartids)!=-1 && (p.prom_type == 5 || p.prom_type == 6|| p.prom_type == 11) && p.update_date == currentRowUpdateDate){
							$("#cart tbody tr#"+p.id).replaceWith(row_tr);
						}
						
						//重置行号
						$("#cart tbody tr#"+p.id).find(".cart-index").text(cartindex);
					}
					
					if(act=='update'){
						//替换本行
						if(p.id == cartid){
							$("#cart tbody tr#"+p.id).replaceWith(row_tr);
						}
						
						//非本行,非合并,触发促销条件(买送/买折)的，其它同一商品，需要替换
						if(mergeProduct != 1 
								&& p.id != cartid && (p.prom_type == 3 || p.prom_type == 4) &&  p.update_date == currentRowUpdateDate){
							$("#cart tbody tr#"+p.id).replaceWith(row_tr);
						}
						
						//满立X促销,触发促销条件时,原同一促销主题的商品价格发生变化,需要替换
						//实现方法:购物车记录的update_date与当前插入的相同（如有触发满立X促销，同一促销主题的商品的一定相同）,都需要替换
						if(p.id != cartid && (p.prom_type == 5 || p.prom_type == 6) && p.update_date == currentRowUpdateDate){
							$("#cart tbody tr#"+p.id).replaceWith(row_tr);
						}
					}
					
					if(act=='remove'){
						//移除本行
						$("#cart tbody tr#"+cartid).remove();
						
						//轻餐饮口味与加料关联删除
						if(industry == "1003" && getSetting("tastes_enabled") == 1){
							$("#cart tbody tr.tastes_tr[data-parent_seq='"+cartid+"']").remove();
							$("#cart tbody tr.tastes_tr[data-cart_id='"+cartid+"']").remove();
						}						
						
						//非本行,非合并,触发促销条件(买送/买折)的，其它同一商品，需要替换
						if(mergeProduct != 1 
								&& p.id != cartid && (p.prom_type == 3 || p.prom_type == 4) && p.update_date == currentRowUpdateDate){
							$("#cart tbody tr#"+p.id).replaceWith(row_tr);
						}
						
						//满立X促销,触发促销条件时,原同一促销主题的商品价格发生变化,需要替换
						//实现方法:购物车记录的update_date与当前插入的相同（如有触发满立X促销，同一促销主题的商品的一定相同）,都需要替换
						if(p.id != cartid && (p.prom_type == 5 || p.prom_type == 6) && p.update_date == currentRowUpdateDate){
							$("#cart tbody tr#"+p.id).replaceWith(row_tr);
						}
						
						//重置行号
						$("#cart tbody tr#"+p.id).find(".cart-index").text(cartindex);
					}
					
					//口味启用条件 ADD BY CPQ
					if(industry == "1003" && getSetting("tastes_enabled") == 1 && p.tastes){
						//如果口味行存在，则更新具体口味，如果不存在，则插入
						console.log("#####口味行",$(".tastes_tr[data-cart_id="+p.id+"]").length);
						
						if($(".tastes_tr[data-cart_id="+p.id+"]").length==0){
							$("#cart tbody tr#"+p.id).after(taste_tr);//口味行 ADD BY CPQ 201703
						}else{
							$(".tastes_tr[data-cart_id="+p.id+"]").find("td").eq(1).text(p.tastes);
							$(".tastes_tr[data-cart_id="+p.id+"]").attr("data-tastes",p.tastes);
						}	
					}
					//局部刷新修改 END
					
					totalQty += parseFloat(p.qty);
					totalPrice += parseFloat(p.subtotal);// 使用转成浮点
					var subTotalPoints = p.refund_flag ==0?p.subtotal_points:0-p.subtotal_points;
					totalPoints += Number(subTotalPoints);
					totalCommission += p.subtotal_commission;//V2:退货负数在soi中已处理
					totalListPrice += parseFloat(p.price)*p.qty;// 使用转成浮点
					
					var subtotalSaleListPrice = p.refund_flag ==0?parseFloat(p.price)*p.qty:0;
					var subtotalSalePrice = p.refund_flag ==0?parseFloat(p.subtotal):0;
					var subtotalDiscountEnabledListPrice = p.discount_enabled==1 && p.gift_flag!=1?parseFloat(subtotalSaleListPrice):0;
					var subtotalDiscountEnabledSalePrice = p.discount_enabled==1?parseFloat(p.subtotal):0;
					var subtotalRefundPrice = p.refund_flag ==1?0-parseFloat(p.subtotal):0;//转正数
					
					var subtotalCut = subtotalDiscountEnabledListPrice*(100-minDiscount)/100;//可直减的金额小计
					
					totalSaleListPrice += subtotalSaleListPrice;
					totalSalePrice += subtotalSalePrice;
					totalDiscountEnabledListPrice += subtotalDiscountEnabledListPrice;
					totalDiscountEnabledSalePrice += subtotalDiscountEnabledSalePrice;
					totalRefundPrice += subtotalRefundPrice;
					
					totalCut += subtotalCut;//可直减的金额合计
				}
				
				if(industry == "1003" && getSetting("tastes_enabled") == 1){
					$("#cart tbody tr.cart_tr").each(function(){
						var parentSeq = $(this).attr("id");
						$("#cart tbody tr.tastes_tr[data-parent_seq='"+parentSeq+"']:last").after($(this).next(".tastes_tr"))
					})
				}
				
				setCurrentRowBg(function() {

					//20180516:Add by dph
					// 开启通讯秤并且设为自动取重后，自动称重
					if(isOpenES && act=='add') {
						if(esName['autoScale']) {
							setTimeout(function() {
								$('table#cart').find('tr.currentRow').find('.es-btn[name=es_btn]').click();
							}, 10);
						}
					}

				});//独立设置当前行背景色
				
				//需要抹零,其它合计都使用原值,用绝对值抹零,再乘以calc
				var calc = totalPrice < 0 ? -1 : 1;
				var calc1 = totalListPrice-totalPrice < 0 ? -1 : 1;
				var calc2 = totalListPrice < 0 ? -1 : 1;
				var calc3 = totalPoints < 0 ? -1 : 1;
				
				totalPrice = doDecimal( doRound( Math.abs(totalPrice) ) * calc );			
				totalSaving = doRound(Math.abs(totalListPrice - totalPrice)) * calc1;
				totalPoints = doDecimal( doRound( Math.abs(totalPoints) ) * calc3 );	
				
				$("#order_type").val(orderType);
				$("#related_sale_order_no").val(relatedSaleOrderNo.length > 0 ? relatedSaleOrderNo.join(',') : "");
				
				// 有内容,才载入合计行
				if ($("#cart tbody").children("tr").length > 0) {
					
					$("#total_qty").val(totalQty);
					$("#total_price").val(totalPrice);
					$("#total_points").val(totalPoints);
					$("#total_commission").val(totalCommission);
					$("#total_list_price").val(totalListPrice);
					$("#total_sale_list_price").val(totalSaleListPrice);
					$("#total_sale_price").val(totalSalePrice);
					$("#total_discount_enabled_list_price").val(totalDiscountEnabledListPrice);
					$("#total_discount_enabled_sale_price").val(totalDiscountEnabledSalePrice);
					$("#total_refund_price").val(totalRefundPrice);
					$("#total_saving").val(totalSaving);

					$("#spn_total_discount_enabled_list_price").text("最多可直减 "+doDecimal(totalCut)+ "元");
					$("#t_sale_price").text(totalPrice);
					$("#t_points").text(doDecimal(totalPoints));
					$("#t_list_price").text(doDecimal(doRound(Math.abs(totalListPrice)) * calc2 ));
					$("#t_saving").text(totalSaving);
					$("#total_cut").val(totalCut);
					$("#t_qty").text("("+totalQty+")");
					
					if(!$("#customer_no").val()){
						$("#spn_t_points").hide();
					}
					else{
						$("#spn_t_points").show();
					}
					
					//原价、直减
					$("#total-desc").show();
				}
				
				//console.log("载入结束行");
				
				//生产单号（流水号）,added by fandy AT 20150918
				var saleOrderNo = ((new Date()).valueOf()).toString()+getRandomNumber(10001,99999);//时间戳+5位随机数
				console.log("-------------------------- 订单号@loadCart()->"+saleOrderNo);
				$("#sale_order_no").val(saleOrderNo);
			}
			
			else{				
				//局部刷新：如果len为0，可能是删除单行,直接清空body,by fandy AT 201708
				$("#cart tbody").empty();
				$("#total-desc").hide();
				$("#t_qty").text("");
				$("#t_sale_price").text(0);
				$("#product_employee_id").val($("#employee_id").val());
				$("#product_employee_name").val($("#employee_name").val());
				//清空购物车hidden
				$("#cart_hidden input[type='hidden']").val("");
				$("#order_type").val(0);
			}
			inform("gen_cs");
			//ADD BY CPQ_PAGE 20170324
			$("#btnCheckout").prop("disabled",false);
			cartUpdating = false;
			cartLoading = false;
			
			if(__PB_sell_display_setting_json && 1 == __PB_sell_display_setting_json['sellTimerFlag']) {
				if(-1 < __PB_sell_display_timer)
					clearTimeout(__PB_sell_display_timer);
				__PB_sell_display_timer = setTimeout(function() {
					customDisp(2,doDecimal($("#total_price").val()));
					__PB_sell_display_timer = -1;
				}, 1500);
			}
		}, function(){
			alert("重新载入购物车商品时发生错误.");
			$("#btnCheckout").prop("disabled",false);
			cartUpdating = false;
			cartLoading = false;
		});
	});

}



//取得商品库存:用于无库存禁止销售
function getProductStock(tx,id,callback){
	tx.executeSql(
			"SELECT p.*, s.qty as stock FROM PRODUCTS p "
			+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
			+" WHERE p.company_id=? AND p.outlet_id=? AND p.active='ON' AND p.del_flag=0 AND p.product_id = ? ", 
			[companyId, outletId, id ], function(tx, results) {
		
		if (results.rows.length > 0) {				
			var product = $.extend({}, results.rows.item(0));
			if(product.stock==null) product.stock = 0;
			console.log("---------------------库存数量 @ getProductStock() ->"+product.stock);
			callback(product.stock);
		}
		else{
			callback(0);
		}
	});
}



/**
 * 更新购物车
 * 
 * @param id : 购物车行号 
 * @param ths 
 * @param typ : 更新类型，1：更新折扣,2：更新数量,3：更新售价
 * @returns
 */
function updateCart(id, ths, typ) {
	// alert("execute updateCart()");

	id = id.toString();
	var val = $(ths).val();
	
	cartUpdating = true;
	$("#btnCheckout").prop("disabled",true);
	
	var relatedCartIds;//需要刷新UI的购物车行ID集
	
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE id = ? ", [ id ], function(tx, results) {
			// alert(cartResults.rows.length);
			if (results.rows.length > 0) {// 更新
				// alert(results.rows.item(0).sale_price);
				var cartItem = $.extend({}, results.rows.item(0));
				
				// V2:创建prouct对象,设置提成规则
				var product = new Object();
				product.commission_type = cartItem.commission_type;
				product.commission_rate = cartItem.commission_rate;
				product.commission_amount = cartItem.commission_amount;
				
				var updateDate = parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S");
				
				// 校验 start
				if (typ == 1) {
					// alert("更新折扣");
					
					// 校验收银员权限
					var minDiscount = getSetting("cMinDiscount");
					var role = $("#auth_role").val();
					if(role.indexOf('ROLE_CASHIER')>-1  && parseInt(val)<parseInt(minDiscount)){
						alert("收银员最低折扣为:"+minDiscount+"%");
						return;
					}

					// 校验折扣
					//var reg = /^(?:1|[1-9][0-9]?|100)$/;//1~100
					var reg = /^100$|^(\d|[1-9]\d)$/;
					if (!reg.test(val)) {
						alert("折扣必须是0~100的整数!");
						$(ths).css("border", "2px solid #ff0000");
						$(ths).focus();
						$(ths).select();
						return;
					}
					
					cartItem.discount = val;
					cartItem.sale_price = cartItem.price*val/100;
					
					updateCartCommon(id,cartItem, 0, tx, typ, val, product, updateDate);
				}else if (typ == 3) {
					// alert("更新售价");
					// 校验售价格式(数字)
					var reg = /^[+-]?\d+\.?\d*$/;// 任意整数或小数
					if (!reg.test(val)) {
						alert("售价必须数字!");
						$(ths).css("border", "2px solid #ff0000");
						$(ths).focus();
						$(ths).select();
						return;
					}
					
					cartItem.sale_price = val;
					cartItem.discount = val/cartItem.price*100;
					
					updateCartCommon(id,cartItem, 0, tx, typ, val, product, updateDate);
				}else if (typ == 2) {
					 // alert("更新数量");
					// var mergeProduct = getSetting("cMergeProduct");//
					// 是否合并相同条码
					// 校验数量,称重商品可输入小数,edited by fandy START
					// var scale_flag = cartItem.scale_flag;
					// 【重要】更新数量可能会影响同一促销主题下的商品的价格(触发或还原)，因为促销条件发生变化了。
					
					var industryFlag = getSetting("Industry") == "1001";
					var r1 = /^[0-9]*[1-9][0-9]*$/; // 正整数
					var r2 = /^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$/; // 正浮点数
					console.log(r1.test(val),r2.test(val));
					
					if( !industryFlag && !( r2.test(val) || r1.test(val) ) ){// 改为支持小数
						message("请输入大于零的数字!");
						$(ths).css("border", "2px solid #ff0000");
						$(ths).focus();
						$(ths).select();
						return;
					}
					// 校验数量,称重商品可输入小数,edited by fandy END
					
					// 服装版只能输入整数 ADD BY CPQ
					if(industryFlag && !r1.test(val)){
						message("请输入大于零的整数!");
						$(ths).css("border", "2px solid #ff0000");
						$(ths).focus();
						$(ths).select();
						return;
					}
					
					
					// 判断 无库存禁止销售 START
					var zeroStockDisabled = getSetting("cZeroStockDisabled");// 无库存禁止销售
					var qty = val-cartItem.qty;// 更新时，传入数量增量
					if(cartItem.scale_flag == 0 && zeroStockDisabled == 1){
						getProductStock(tx,cartItem.product_id,function(stockQty){// 取得该商品的库存后的回调
							
							// 无库存禁止销售> 当前库存-销售<0 禁止销售
							var saleQty = getSaleQtyInCart(cartItem.product_id);
							console.log("---------------------销售数量 saleQty @ updateCart() ->"+saleQty);
							if(stockQty-saleQty < 0){
								message("库存不足,禁止销售!<br>库存数量"+stockQty+",销售数量"+saleQty+".",3000);
								$(ths).css("border", "2px solid #ff0000");
								$(ths).focus();
								$(ths).select();
								return;
							}
							
							updateCartCommon(id,cartItem, qty, tx, typ, val, product, updateDate);
						});
					}else{
						updateCartCommon(id,cartItem, qty, tx, typ, val, product, updateDate);
					}
					// 判断 无库存禁止销售 END
				}
				// 校验 end
			}// 行存在判断 结束
		}, function(tx, error) {
			console.log('error: ' + error.message);
		});
		// 行查询结束
		
	},function(){
		// 事务error ： 更新时如果正在收银中，弹出提示并关闭收银界面
		alert("更新购物车商品时发生错误,请核对收银金额是否正确.");
		$("#btnCheckout").prop("disabled",false);
		cartUpdating = false;
	},function(){
		// 事务成功后重新载入购物车 ADD BY CPQ 20161115
		//loadCart2("update",id,null);
		loadCartItems("update", id, null, relatedCartIds);
	});
}

//购物车更新，提取wrapPrice部分为方法
function updateCartCommon(id,cartItem, qty, tx,typ,val, product, updateDate){
	// wrap price
	wrapPrice(cartItem , qty, tx,  function(discount, salePrice, promotion, cartIds ){
		
		// 二次校验 start
		if(typ == 3){// 直接修改价格时
			// 校验收银员权限
			var minDiscount = getSetting("cMinDiscount");
			var role = $("#auth_role").val();
			if(role.indexOf('ROLE_CASHIER')>-1  && discount<parseInt(minDiscount)){
				alert("收银员最低折扣为:"+minDiscount+"%");
				return;
			}
		}
		// 二次校验 end
		
		//赠品标记处理:当赠品改折扣/改价格(价格不为0)后,gift_flag需要设为0
		var giftFlag = cartItem.gift_flag;
		if(cartItem.gift_flag == 1 && discount != 0){
			giftFlag = 0;
		}
		
		relatedCartIds = cartIds;
		
		var hackedQty = typ==2?val:cartItem.qty;
		
		var subtotal = parseFloat(salePrice * hackedQty);
		var subtotalPoints = 0;
		if(cartItem.point_enabled==1){
			subtotalPoints = subtotal*cartItem.point_rate;
		}
		
		// V2:提成
		var subtotalCommission = getCommission(product,hackedQty,subtotal);
		
		console.log("--------------------- 更新折扣 @ updateCart(),subtotalPoints/subtotalCommission->"+subtotalPoints+'/'+subtotalCommission);
		
		tx.executeSql(
				"UPDATE SHOPPINGCARTS SET discount = ?,sale_price = ?,qty =?, subtotal = ?, subtotal_points = ? , subtotal_commission = ? , update_date = ?, gift_flag = ?  WHERE id = ? ", 
				[ discount, parseFloat(doDecimal(salePrice)), hackedQty, parseFloat(doDecimal(subtotal)), parseFloat(doDecimal(subtotalPoints)), parseFloat(doDecimal(subtotalCommission)), updateDate, giftFlag, id ], 
				function(tx, r) {
			console.log("### 更新成功(类型:"+typ+") ###");
		}, null);
		
		//关联行排除本行
		for(var i in cartIds){
			if(cartIds[i] == id){
				cartIds.splice(i,1);
				break;
			}
		}
		
		// 处理关联行数据 start
		// 使用场景(promotion.prom_type
		// >2):在买x（不合并）、满立X促销时，添加购物车会影响已存在的关联行(cartIds)数据
		if(promotion != null && promotion.prom_type >2 && cartIds!=null)
			updateRelatedCartItems(tx, cartIds, discount, salePrice, updateDate, promotion)
		// 处理关联行数据 end
		
		
	} ,typ);
}

/**
 * 赠品设置
 * 
 * @param id : 购物车行号 
 * @param giftFlag : 是否在设置赠品 0|1
 * @returns
 */
function setGift(id, giftFlag) {
	// alert("execute setGift()");

	id = id.toString();
	
	cartUpdating = true;
	$("#btnCheckout").prop("disabled",true);
	
	var relatedCartIds;//需要刷新UI的购物车行ID集
	
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE id = ? ", [ id ], function(tx, results) {
			// alert(cartResults.rows.length);
			if (results.rows.length > 0) {// 更新
				// alert(results.rows.item(0).sale_price);
				var cartItem = $.extend({}, results.rows.item(0));
				
				// V2:创建prouct对象,设置提成规则
				var product = new Object();
				product.commission_type = cartItem.commission_type;
				product.commission_rate = cartItem.commission_rate;
				product.commission_amount = cartItem.commission_amount;
				
				var updateDate = parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S");
				
				var qty = 0;//数量增量
				cartItem.gift_flag = giftFlag;//传入赠品标记
				
				wrapPrice(cartItem , qty, tx,  function(discount, salePrice, promotion, cartIds ){
					
					relatedCartIds = cartIds;
					
					//当设为赠品时,本行的discount与salePrice为0,关联行(如果有)用回调返回
					var _discount = giftFlag == 1?0:discount;
					var _salePrice = giftFlag == 1?0:salePrice;
					
					var hackedQty = cartItem.qty;
					var subtotal = parseFloat(_salePrice * hackedQty);
					var subtotalPoints = 0;
					if(cartItem.point_enabled==1){
						subtotalPoints = subtotal*cartItem.point_rate;
					}
					
					// V2:提成
					var subtotalCommission = getCommission(product,hackedQty,subtotal);
					
					console.log("--------------------- 更新折扣 @ setGift(),subtotalPoints/subtotalCommission->"
							+subtotalPoints+'/'+subtotalCommission);
					
					
					tx.executeSql(
							"UPDATE SHOPPINGCARTS SET discount = ?,sale_price = ?, subtotal = ?, subtotal_points = ? , subtotal_commission = ? , update_date = ? , gift_flag = ?  WHERE id = ? ", 
							[ _discount, parseFloat(doDecimal(_salePrice)), parseFloat(doDecimal(subtotal)), parseFloat(doDecimal(subtotalPoints)), parseFloat(doDecimal(subtotalCommission)), updateDate, giftFlag, id ], 
							function(tx, r) {
						console.log("### 更新成功(赠品设置) ###");
					}, null);
					
					//关联行排除本行
					for(var i in cartIds){
						if(cartIds[i] == id){
							cartIds.splice(i,1);
							break;
						}
					}
					
					// 处理关联行数据 start
					// 使用场景(promotion.prom_type
					// >2):在买x（不合并）、满立X促销时，添加购物车会影响已存在的关联行(cartIds)数据
					if(promotion != null && promotion.prom_type >2 && cartIds!=null)
						updateRelatedCartItems(tx, cartIds, discount, salePrice, updateDate, promotion)
					// 处理关联行数据 end
					
					
				}
				);
				// wrap price
			}// 行存在判断 结束
		}, function(tx, error) {
			console.log('error: ' + error.message);
		});
		// 行查询结束
		
	},function(){
		// 事务error ： 更新时如果正在收银中，弹出提示并关闭收银界面
		alert("更新购物车商品时发生错误,请核对收银金额是否正确.");
		$("#btnCheckout").prop("disabled",false);
		cartUpdating = false;
	},function(){
		// 事务成功后,局部刷新购物车行 
		loadCartItems("update", id, null, relatedCartIds);
	});
}


/**
 * 移除购物车项目
 * 
 * @param id
 * @param productid
 * @returns
 */
function removeCart(id, productid) {
	// alert("execute 移除动作");
	cartLoading = true;
	
	var relatedCartIds;
	
	db.transaction(function(tx) {
		//删除的是主商品时，同时删除加料 ADD BY CPQ
		tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE id = ? OR parent_seq=?", [id ,id], function(tx, cartResults) {
			// alert(cartResults.rows.length);
			if (cartResults.rows.length > 0) {// 更新
				
				for(var i = 0; i < cartResults.rows.length; i++){
					var cartItem = cartResults.rows.item(i) || cartResults.rows[i];
					deleteCartItem(tx,cartItem,function(result){
						relatedCartIds  = result;
					});
				}
			}
		}, null);
		
	},function(){
		cartLoading = false; 
	},function(){
		//事务成功后重新载入购物车 ADD BY CPQ 20161115
		//loadCart2("remove", id, productid);
		loadCartItems("remove", id, productid, relatedCartIds);
	});
}


/**
 * 
 * 删除购物车行：做成方法可以解决for循环的异步问题;
 * 
 * @param tx
 * @param cartItem : 购物车行
 * @returns
 */
function deleteCartItem(tx, cartItem, callback){
	tx.executeSql("DELETE FROM SHOPPINGCARTS WHERE id = ? ", [cartItem.id], function(tx, r) {
		console.log("### 成功删除购物车行 ###"+r);
		
		var mergeProduct = getSetting("cMergeProduct");// 是否合并相同商品
		
		//删除时，传入的基础价格与基础折扣为初始的
		cartItem.sale_price = cartItem.price;
		cartItem.discount = 100;
		
		//主商品，买X非合并或满立X促销
		var buyCondition =  mergeProduct != 1 && cartItem.prom_type!=null && (cartItem.prom_type==2 || cartItem.prom_type==3);
		var spendCondition = cartItem.prom_type!=null && (cartItem.prom_type==5 || cartItem.prom_type==6);
		
		if(!cartItem.parent_seq && (buyCondition || spendCondition)){
			//【重要】买X、满立X促销时，删除行可能会影响同一促销主题下的商品的价格(促销条件不满足，还原价格)
			//wrap price start
			wrapPrice(cartItem, 0, tx, function(discount, salePrice, promotion, cartIds){
				
				var updateDate = parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S");
				
				// 处理关联行数据 start
				// 使用场景(promotion.prom_type
				// >2):在买x（不合并）、满立X促销时，添加购物车会影响已存在的关联行(cartIds)数据
				if(promotion != null && promotion.prom_type >2 && cartIds!=null)
					updateRelatedCartItems(tx, cartIds, discount, salePrice, updateDate, promotion)
				// 处理关联行数据 end
					
				callback(cartIds);
			});
			//wrap price end
		}
	}, function(tx, error) {
		console.log('error: ' + error.message);
	});
}


// 清空购物车,使用web sql db
function clearCart() {
	console.log("******执行clearCart()*******");
	
	// 清空数据库,再移除购物车表格内容
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? ORDER BY ID DESC", [outletId], function(tx, cartResults) {
			// alert(cartResults.rows.length);
			if (cartResults.rows.length > 0) {// 有内容
				// alert("在购物车中存在!");
				tx.executeSql("DELETE FROM SHOPPINGCARTS WHERE outlet_id = ? ", [outletId], function(tx, r) {
					// 移除购物车表格内容
					$("#cart tbody").empty();
					$("#cart tfoot").empty();

					$("#t_sale_price").text("");
					$("#t_points").text("");
					$("#t_list_price").text("");
					$("#t_saving").text("");
					$("#t_qty").text("");
					
					$("#total-desc").hide();
					
					// loadCart();//清空了,不用再载入,如果再载入,当当前单有内容时,取单会重复载入。
					inform("gen_cs");

					// 清空会员信息
					clearCustomerInfo();
					
					// 清空导购员选项
					removeEmployee(0);
					
					//复位可收银,2014-8-18
					checkoutEnabled = true;
					$("#btnPay").removeAttr("disabled");
					
					//清空购物车hidden
					$("#cart_hidden input[type='hidden']").val("");
					$("#order_type").val(0);
					
					console.log("### remove focus ###");
					$(".btn-clear-cart").blur();
				}, null);
			}
		}, null);
	});
	//清空导购员和会员按钮
	clearBtnInfo()
}


/**
 * 价格包装方法:影响因素有销售模式、会员、促销
 * 
 * @param product : 商品或购物车行
 * @param qty : 数量增量
 * @param tx 
 * @param callback
 * @param typ : 操作动作:updateCart的动作，1为改折扣，3为改售价，两者都直接修改直接返回；sellForCustomer的动作,8为会员销售
 * @returns
 */
function wrapPrice(product , qty, tx,  callback , typ){	
	var id = product.product_id;
	var price = product.price;
	var scaleFlag = product.scale_flag;//称重商品标识
	
	var _wrapDiscount = 100;//初始折扣为100 > 下方会重新计算最后的返回折扣
	var _wrapPrice = product.price;//初始售价为标价 > 下方会重新计算最后的返回价格
	
	var priceType = localStorage.getItem("PRICE_TYPE");//0零售,1批发
	var cdFlag = false; //用于控制促销商品的促销条件还没达到,但又是会员销售,需要采用会员价格
	
	
	if(typ!=null && typ ==1){//直改折扣，直接返回
		_wrapDiscount = product.discount;
		_wrapPrice = price*product.discount/100;
		callback(_wrapDiscount,_wrapPrice);
		return;
	} 
	if(typ!=null && typ ==3){//直改售价，直接返回
		_wrapPrice = product.sale_price;
		_wrapDiscount = product.sale_price/product.price*100;
		callback(_wrapDiscount,_wrapPrice);
		return;
	}
	if(typ!=null && typ ==2 && product.gift_flag == 1){//赠品改数量，直接返回
		_wrapPrice = 0;
		_wrapDiscount = 0;
		callback(_wrapDiscount,_wrapPrice);
		return;
	}
	
	if(typ!=null && typ ==2 && priceType == 1){//批发改数量，直接返回
		_wrapPrice = product.sale_price;
		_wrapDiscount = product.discount;
		callback(_wrapDiscount,_wrapPrice);
		return;
	}
	
	//批发模式 START
	//注意：批发价销售不受是否参与打折影响
	if (priceType == 1) {// 1为批发价
		console.log("##################### 进入批发模式  #####################");
		_wrapPrice = product.wholesale_price;
		//_wrapDiscount = Math.round(product.wholesale_price / product.price * 100);
		_wrapDiscount = product.wholesale_price / product.price * 100;
		console.log(_wrapDiscount,_wrapPrice);
		callback(_wrapDiscount,_wrapPrice);
		return;
	}
	//批发模式 END
	
	//零售模式 START
	if (priceType == 0) {// 0为零售价
		console.log("##################### 进入零售模式  #####################");
		console.log("--------------------- ID/是否参与打折 @ wrapPrice()-> " + product.product_id+"/"+product.discount_enabled);
		if(product.gift_enabled !=1 && product.discount_enabled!=1){//零售时,如商品不参与打折时,原值返回  > 非赠品时
			callback(_wrapDiscount,_wrapPrice);
			return;
		}
		
		//get customer start	
		var isSellForCustomer = false;	
		var customerInfoJsonStr = "{}";
		if($("#customer_no").val()){
			isSellForCustomer = true;
			customerInfoJsonStr = localStorage.getItem("CURRENT_CUSTOMER");
		}
		//console.log("--------------------- 会员信息 customerInfoJsonStr @ wrapPrice() ->"+customerInfoJsonStr);
		//get customer end
		
		
		//******************促销 START****************** 		
		//V2:增加支持全场促销		
		var sql  = "SELECT p.* FROM PROMOTIONS p "
			//取得本店有效期内,所有可用的全场促销
			+" WHERE ( p.enabled = 1 AND p.del_flag = 0 "
			+" AND p.company_id = ? AND p.outlet_id = ? "
			+" AND datetime('now','+8 hour') BETWEEN datetime(p.start_datetime) AND datetime(p.end_datetime) " 
			+" AND p.is_all = 1 )"
			//加上某商品(product id)本店有效期内,可用的非全场促销
			+" OR p.promotion_id IN ("			
				+" SELECT p.promotion_id FROM PROMOTIONS p INNER JOIN  PROMOTIONPRODUCTS pp ON  p.promotion_id = pp.promotion_id "
				+" WHERE p.enabled = 1 AND p.del_flag = 0 "
				+" AND pp.del_flag = 0 "
				+" AND p.company_id = ? AND p.outlet_id = ? "
				+" AND pp.promotion_id = p.promotion_id  AND pp.product_id = ? "
				+" AND datetime('now','+8 hour') BETWEEN datetime(p.start_datetime) AND datetime(p.end_datetime)" 
				+" ORDER BY p.prom_level DESC"
			+" ) "
			//全场促销优先，然后按优先级排序
			+" ORDER BY p.is_all DESC,p.prom_level DESC";	
		
		//console.log("--------------------- sql @wrapPrice ? ->"+sql);
		
		tx.executeSql(sql, [companyId, outletId, companyId, outletId, id],function(tx,result){
			var len = result.rows.length;
			console.log("--------------------- ID/是否属于促销商品 @ wrapPrice() ? ->"+id+"/"+len);
			
			//没有促销 START
			if(len==0){//商品不在促销商品列表中时	
				
				//没有促销也没有会员销售时,保持原来的折扣与售价
				_wrapDiscount = product.discount || 100;//更新为原折扣,新增为100
				_wrapPrice = product.sale_price || product.price;//更新为原售价,新增为标价
				
				//没有促销,会员销售 START
				if(isSellForCustomer){
					var customerInfo = JSON.parse(customerInfoJsonStr);
//					wrapCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount, 1 ,function(wd, wp){
//						_wrapDiscount = wd;
//						_wrapPrice = wp;
//					});			
					product.allow_double_discount = 0;
					var customerPriceResult = calCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount); 
					_wrapDiscount = customerPriceResult.discount;
					_wrapPrice = customerPriceResult.sale_price;
					console.log("_wrapDiscount,_wrapPrice @ 会员销售(无促销) ->",_wrapDiscount,_wrapPrice);
				}
				//没有促销,会员销售 END
				
				callback(_wrapDiscount,_wrapPrice);
			}
			//没有促销 END
			
			//有促销 START
			if(len>0){//商品在促销商品列表中时
				var item = result.rows.item(0);				
				console.log("--------------------- product ID/promotion type/promotion name->"
						+item.product_id+"/"+item.prom_type+"/"+item.prom_name);
				
				var promId = item.promotion_id;//促销主题ID
				var promType = item.prom_type;
				var allowDoubleDiscount = item.allow_double_discount;
				var specialPrice = item.special_price;
				var buy = item.buy;
				var getx = item.getx;
				var promDiscount = item.discount;
				var spend = item.spend;
				var savex = item.savex;
				
				//特价 //固定折扣 START
				if(promType==1 || promType==2){//特价 //固定折扣
					/*tx.executeSql(
						"SELECT * FROM SHOPPINGCARTS WHERE gift_flag !=1 and outlet_id = ? AND product_id = ? ",
						[outletId, id],
						function(tx,result){
						console.log("--------------------- 购物车中是否已存在 AT 买 ?->"+result.rows.length);
						//是否有促销打折 ADD BY CPQ
						if(result.rows.length>0){
							
						}
					},null);*/
					
					
					if(promType==1){//特价
						_wrapPrice = specialPrice;
						_wrapDiscount = specialPrice/price*100;
					}
					if(promType==2){//固定折扣
						_wrapPrice = price*promDiscount/100;
						_wrapDiscount = promDiscount;
					}						
					console.log("--------------------- price/_wrapDiscount/_wrapPrice AT 促销("+promType+") ->"
							+price+"/"+_wrapDiscount+"/"+_wrapPrice);
					
					
					//会员折上折处理 START
					if(isSellForCustomer 
							&& (allowDoubleDiscount == 1 || typ == 8) ){
						var customerInfo = JSON.parse(customerInfoJsonStr);
//							wrapCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount, 1 ,function(wd, wp){
//								_wrapDiscount = wd;
//								_wrapPrice = wp;
//							});	
						product.allow_double_discount = allowDoubleDiscount;
						var customerPriceResult = calCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount); 
						_wrapDiscount = customerPriceResult.discount;
						_wrapPrice = customerPriceResult.sale_price;
						console.log("--------------------- price/_wrapDiscount/_wrapPrice AT 促销("+promType+") 会员折上折 ->"
								+price+"/"+_wrapDiscount+"/"+_wrapPrice);
					}
					//会员折上折处理 END
					
					console.log("_wrapDiscount,_wrapPrice @ 特价或固折 促销 ->",_wrapDiscount,_wrapPrice);
					callback(_wrapDiscount,_wrapPrice);
				}
				//特价 //固定折扣 END
				
				
				//买N送n	//买N件打n折 START
				if(promType==3 || promType==4 ){//买N送n,满N打n折		
					
					var cartIds = [];//需同时更新的其它购物车行号ID集：条件--买X促销时同一个商品（product ID相同）
					
					tx.executeSql(
						//"SELECT sum(qty) AS subtotalQty FROM SHOPPINGCARTS WHERE outlet_id = ? AND product_id = ? ",
						"SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? AND product_id = ? ",
						[outletId, id],
						function(tx,result){
						console.log("--------------------- 购物车中是否已存在 AT 买 ?->"+result.rows.length);
						//是否有促销打折 ADD BY CPQ
						if(result.rows.length>0){//因为事务,所以一定会存在的!!!
							//var subtotalQty = result.rows.item(0).subtotalQty!=null?result.rows.item(0).subtotalQty:0;
							var subtotalQty = 0;
							//取得同一满立X促销主题下的购物车中的商品合计金额，以及将购物行号放入数组cartIds中
							for(var i=0; i<result.rows.length; i++){
								var cartItem = result.rows.item(i);
								
								//赠品不参与合计: 赠品本身或赠品本中已存在的
								if((cartItem.id == product.id && product.gift_flag == 1) 
										|| (cartItem.id != product.id && cartItem.gift_flag == 1)) continue;
								
								cartIds.push(cartItem.id);
								subtotalQty += cartItem.qty;
							}
							
							console.log("--------------------- subtotal qty->"+subtotalQty);
							
							if(promType==3){//买N送n
								if( (subtotalQty+qty)>=(buy+getx)){//买送条件满足
									var times = Math.floor((subtotalQty+qty)/(buy+getx));//送的次数
									if((subtotalQty+qty)%(buy+getx)==0){
										_wrapPrice = price*buy/(buy+getx);
										_wrapDiscount = _wrapPrice/price*100;
									}
									else{
										_wrapPrice = price*(subtotalQty+qty-times)/(subtotalQty+qty);
										_wrapDiscount = _wrapPrice/price*100;
									}
									
									console.log("--------------------- price/_wrapDiscount/_wrapPrice AT 促销("+promType+") ->"
											+price+"/"+_wrapDiscount+"/"+_wrapPrice);
								}
								else{
									cdFlag = true;//因为走了促销分支,却又达不到条件,但是是会员销售
								}
							}
							
							if(promType==4){//买N打n折(>=N时打n折,不累加)
								if( (subtotalQty+qty)>=buy){//买折条件满足
									_wrapPrice = price*promDiscount/100;
									_wrapDiscount = promDiscount;
									
									console.log("--------------------- price/_wrapDiscount/_wrapPrice AT 促销("+promType+") ->"
											+price+"/"+_wrapDiscount+"/"+_wrapPrice);
								}
								else{
									cdFlag = true;
								}
							}
						}	
						
						//会员销售(折上折或单纯会员折扣) START
						if(isSellForCustomer  
								&& (allowDoubleDiscount == 1 || cdFlag || typ == 8) ){
							var customerInfo = JSON.parse(customerInfoJsonStr);
//							wrapCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount, 1 ,function(wd, wp){
//								_wrapDiscount = wd;
//								_wrapPrice = wp;
//							});	
							product.allow_double_discount = allowDoubleDiscount;
							var customerPriceResult = calCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount); 
							_wrapDiscount = customerPriceResult.discount;
							_wrapPrice = customerPriceResult.sale_price;
							console.log("--------------------- price/_wrapDiscount/_wrapPrice AT 促销("+promType+") 会员折上折或会员销售 ->"
									+price+"/"+_wrapDiscount+"/"+_wrapPrice);	
						}
						//会员销售(折上折或单纯会员折扣) END
									
						console.log("_wrapDiscount,_wrapPrice @ 买送或满折 促销 ->",_wrapDiscount,_wrapPrice);
						
						//买N送n,满N打n折时，返回promotion，表示要在非合并收银时更新同一商品的价格和折扣 ADD BY CPQ
						callback(_wrapDiscount,_wrapPrice, item, cartIds);
					},null);
				}
				//买N送n	//买N件打n折 END
				
				
				//满减/满折 START
				if(promType==5 || promType==6 || promType==11){
					
					var cartIds = [];//需同时更新的其它购物车行号ID集：条件--满立X促销时同一个促销主题（promotion ID相同）
					var totalListPrice = 0;
					
					tx.executeSql(
						"SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? AND prom_id = ? ",
						[outletId, promId],
						function(tx,result){
							console.log("--------------------- 购物车中是否已存在 AT 满立X ?->"+result.rows.length);
							//是否有促销打折 ADD BY CPQ
							if(result.rows.length>0){//因为事务,所以一定会存在的!!!
								//取得同一满立X促销主题下的购物车中的商品合计金额，以及将购物行号放入数组cartIds中
								for(var i=0; i<result.rows.length; i++){
									var cartItem = result.rows.item(i);
									
									//赠品不参与合计: 赠品本身或赠品本中已存在的
									if((cartItem.id == product.id && product.gift_flag == 1) 
											|| (cartItem.id != product.id && cartItem.gift_flag == 1)) continue;
									
									cartIds.push(cartItem.id);
									totalListPrice += cartItem.price*cartItem.qty;
								}
							}
							
							console.log("--------------------- totalListPrice/cartIds->"+totalListPrice+"/"+cartIds);
							//addCart()时可能不存在，即满立X促销的第一件商品，也需要判断是否满路条件，所以下方代码从上面if分支里移出
							var tempTotalPrice = totalListPrice+price*qty;
							if(tempTotalPrice >= spend){//满足满立X条件
								if(promType == 11){
									savex *= Math.floor(tempTotalPrice/spend);
								}
								//满立减
								if(promType == 5 || promType == 11){
									_wrapDiscount = (tempTotalPrice-savex)/(tempTotalPrice)*100;
									_wrapPrice = price*_wrapDiscount/100;
								}
								
								//满立折
								if(promType == 6){
									_wrapDiscount = promDiscount;
									_wrapPrice = price*promDiscount/100;
								}
							}
							else{
								cdFlag = true;//因为走了促销分支,却又达不到条件,但是是会员销售
							}
							
							
							//会员销售(折上折或单纯会员折扣) START
							if(isSellForCustomer 
									&& (allowDoubleDiscount == 1 || cdFlag || typ == 8) ){
								var customerInfo = JSON.parse(customerInfoJsonStr);
//								wrapCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount, 1 ,function(wd, wp){
//									_wrapDiscount = wd;
//									_wrapPrice = wp;
//								});	
								product.allow_double_discount = allowDoubleDiscount;
								var customerPriceResult = calCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount); 
								_wrapDiscount = customerPriceResult.discount;
								_wrapPrice = customerPriceResult.sale_price;
								console.log("--------------------- price/_wrapDiscount/_wrapPrice AT 促销("+promType+") 会员折上折或会员销售 ->"
										+price+"/"+_wrapDiscount+"/"+_wrapPrice);	
							}
							//会员销售(折上折或单纯会员折扣) END
										
							console.log("_wrapDiscount,_wrapPrice @ 满立X 促销 ->",_wrapDiscount,_wrapPrice);
							
							//满立X时，返回promotion和cartIds
							callback(_wrapDiscount, _wrapPrice, item, cartIds);
						},
						null
					);
				}
				//满减/满折 END
			}
			//有促销 END
			
		},function(tx, error) {
		    console.log("促销判断出错 Error : " + error.message);
		    
		    //促销判断出错,保持原来的折扣与售价
			_wrapDiscount = product.discount || 100;//更新为原折扣,新增为100
			_wrapPrice = product.sale_price || product.price;//更新为原售价,新增为标价
		    
			//会员销售 START
			if(isSellForCustomer){
				var customerInfo = JSON.parse(customerInfoJsonStr);
//				wrapCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount, 1 ,function(wd, wp){
//					_wrapDiscount = wd;
//					_wrapPrice = wp;
//				});
				product.allow_double_discount = 0;
				var customerPriceResult = calCustomerPrice(customerInfo, product, _wrapPrice, _wrapDiscount); 
				_wrapDiscount = customerPriceResult.discount;
				_wrapPrice = customerPriceResult.sale_price;
				console.log("_wrapDiscount,_wrapPrice @ 会员销售(促销判断出错) ->",_wrapDiscount,_wrapPrice);
			}
			//会员销售 END
			
			callback(_wrapDiscount,_wrapPrice);//无促销无会员时,原值返回
		});
		//******************促销  END******************
	}
	//零售模式 END
}



/**
 * 包装购物车明细的价格：用于会员销售sellForCustomer(),取消会员销售restorePrice(),与切换销售模式switchPriceType()
 * update2016-01-06:以上三个方式都适用于称重商品
 * 规则:后者优先，如果有折上折，则促销价*会员组折扣(务必是会员组折扣)，如果没有折上折，以会员折方式扣计算
 *     批发模式下，促销与会员都不起作用
 * 
 * @param cartItem
 * @param tx
 * @param callback
 * @returns
 */
function wrapCartItem(cartItem , tx,  callback, isCustomerSell){	
	console.log("--------------------- 执行wrapCartItem() ---------------------");
	
	var id = cartItem.id;
	var pid = cartItem.product_id;//未使用
	var qty = cartItem.qty;
	var pointEnabled = cartItem.point_enabled;
	var pointRate = cartItem.point_rate;
	
	//V2:创建prouct对象,设置提成规则
	var product = new Object();
	product.commission_type = cartItem.commission_type;
	product.commission_rate = cartItem.commission_rate;
	product.commission_amount = cartItem.commission_amount;
	
	var typ = isCustomerSell?8:null;//会员销售时，传入8，这样在促销商品满足促销条件但没有折上折时，可以进入会员折扣分支
	
	//也是需要促销与会员价格包装的，直接使用wrapPrice()方法
	//wrap price start
	wrapPrice(cartItem, 0, tx, function(discount, salePrice, promotion, cartIds){
		_wrapDiscount = discount;
		_wrapPrice = salePrice;
		
		var subtotal = parseFloat(_wrapPrice * qty);								
		var subtotalPoints = 0;
		if(pointEnabled==1){
			subtotalPoints = subtotal*pointRate;
		}
		
		//V2:提成
		var subtotalCommission = getCommission(product,qty,subtotal);
		
		console.log("--------------------- UPDATE @ wrapCart() -> id/pid : discount/salePrice/subtotal/subtotalPoints/subtotalCommission->" 
				+ id+"/"+pid + ":"+ _wrapDiscount + "/" + _wrapPrice + "/" + subtotal + "/" + subtotalPoints + "/" + subtotalCommission);
		//更新cart row
		tx.executeSql("UPDATE SHOPPINGCARTS SET discount = ?,sale_price = ?,subtotal = ?, subtotal_points = ?, subtotal_commission = ? WHERE id = ? ",
				[ _wrapDiscount, parseFloat(doDecimal(_wrapPrice)), parseFloat(doDecimal(subtotal)), parseFloat(doDecimal(subtotalPoints)), parseFloat(doDecimal(subtotalCommission)), id ], function(tx, r) {
			callback(true);
		}, null);
		
	},
	typ
	);
	//wrap price end
}


/**
 * 会员价格封装方法(在促销之后)，用于会员销售、会员销售撤销、切换与促销会员折上折
 * 规则:1.单纯会员折扣，依据商品中的会员折扣方式计算(商品会员价由商品资料中的vip_disoucnt,vip_price决定)；2.促销时会员折上折，售价*会员组的折扣率
 * 
 * @param customerInfo
 * @param cartItem : 购物车行或商品
 * @param basePrice : 当前售价
 * @param baseDiscount : 当前折扣
 * @param allowDoubleDiscount > 从cartItem取
 * @returns result : 对象，第一个元素是折扣，和二个元素是售价
 */
function calCustomerPrice(customerInfo, cartItem, basePrice, baseDiscount){
	
	var result = new Object();
	
	var _wrapPrice = basePrice;
	var _wrapDiscount = baseDiscount;
	
	//在调用它的层判断是否打折,这儿一定是有参与打折的,wrapPrice(),wrapCart()有调用

	// 如果是会员销售,则execute 会员价格体系 start
	//默认为-1,即非会员销售, 0不打折只积分, 1为即打折又积分, 2为只打折不积分, 3为不打折不积分(可能用于会员卡余额消费)
	var customerSaleType = $("#customer_sale_type").val();
	//var customerDiscount = customerInfo.discount_rate;
	var customerDiscount = customerInfo.discount_rate || 0;
	console.log("--------------------- 会员销售方式(1,2有打折)/会员折扣 @ wrapCustomerPrice() -> " + customerSaleType + "/" + customerDiscount);
	
	//if (customerDiscount && (customerSaleType==1 || customerSaleType==2)) {//1或2有打折
	if (customerDiscount!=0 && (customerSaleType==1 || customerSaleType==2)) {//1或2有打折
		// 取得会员价格类型
		//var vipPriceType = getSetting("cVipPriceType");// 0为零售价*会员折扣,1为会员价
		var vipPriceType = cartItem.vip_discount_type;//V2:vip_discount_type为商品会员打折方式-1不打折
		if(vipPriceType==0) vipPriceType = getSetting("cVipPriceType")==1?2:1;
		
		console.log("--------------------- 会员价格类型(0为零售价*会员折扣,1为会员价) @ wrapCustomerPrice() -> " + vipPriceType);
		
		var allowDoubleDiscount = cartItem.allow_double_discount;
		
		if(allowDoubleDiscount != null && allowDoubleDiscount == 1){
//			_wrapPrice = basePrice>cartItem.vip_price?cartItem.vip_price:basePrice;//两者取其低
			_wrapPrice = basePrice * customerDiscount/100;//促销时会员折上折，售价*会员组的折扣率
			_wrapDiscount = _wrapPrice / cartItem.price * 100
			
		}
		else{//无折上折,仅会员折扣
			// 1.价格类型为:使用零售价*会员折扣
			if (vipPriceType == 1) {
				_wrapPrice = cartItem.price * customerDiscount / 100;
				_wrapDiscount = _wrapPrice / cartItem.price * 100;//折扣不等于customerDiscount,因为可能是折上折(促销时),所以需要使用售价/标价重新计算
			}

			// 2.价格类型为:使用会员价
			if (vipPriceType == 2) {			
				_wrapPrice = cartItem.vip_price;
				_wrapDiscount = _wrapPrice / cartItem.price * 100
			}
			
			var _customerPromMode = 1;//1为后者优先,2为两者取其低
			
			//没有折上折时，会员价格与促销价格，两者取其低 > 后者优先
//			_wrapPrice = _wrapPrice>cartItem.sale_price?cartItem.sale_price:_wrapPrice;//两者取其低
//			_wrapDiscount = _wrapPrice / cartItem.price * 100
		}
		
		
	}
	// 如果是会员销售,则execute 会员价格体系 end
	
	//callback(_wrapDiscount,_wrapPrice);
	result.discount = _wrapDiscount;
	result.sale_price = _wrapPrice;
	
	return result;
}



// 新整单折扣方法,4-9
function discountFull() {
	var discountType = $("#all_discount_type").val();
	console.log("--------------------- discountType @ discountFull() ->"+discountType);
	
	if(discountType==null||discountType=='')
		return;
	
	//var val = 100;//默认折扣
	
	//直减 开始
	if(discountType == 1){
		var ths = $("#all_saving");
		var listSaving = $("#all_saving").val();//优惠金额,以原价为基准
		var finalPay = $("#final_pay").val();
		
		// 校验直减金额
		var reg = /^[+-]?\d+\.?\d*$/;// 任意整数或小数
		if (!reg.test(listSaving)) {
			$("#all_saving").next().text("直接金额必须是数字!").css({"color":"#ff0000","font-weight":"bold"});
			$("#all_saving").css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$("#all_saving").next().text("").removeAttr("style");
			$("#all_saving").removeAttr("style");
		}
		
		if (!reg.test(finalPay)) {
			$("#final_pay").next().text("实收金额必须是数字!").css({"color":"#ff0000","font-weight":"bold"});
			$("#final_pay").css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$("#final_pay").next().text("").removeAttr("style");
			$("#final_pay").removeAttr("style");
		}
		
		
		//改为按当前售价比例分摊到每一个非退货商品(可能每一个商品的折扣不会相同),前提条件:退货独立,否则平均折扣与合计都会不准确或者退货不计入直减运算,2014-6-12
		var totalSalePrice = parseFloat($("#total_sale_price").val());//非退货销售合计
		var totalDiscountEnabledSalePrice = parseFloat($("#total_discount_enabled_sale_price").val());//非退货参与打折的销售合计,2014-7-31增加
		var totalSaleListPrice = parseFloat($("#total_sale_list_price").val());	//销售标价合计
		var currentTotalSaving = parseFloat($("#total_saving").val());	//当前优惠
		var saving = listSaving-currentTotalSaving ;//相对优惠总额,以当前售价为基准 
		
		var _totalSalePrice = 0;//最后的总计,用于修正金额合计		
		
		//直减总金额不能大于可用于折扣的金额, add by fandy 2015-02-02 > 如果是收银员,直减金额不能大于收银员权限内的金额,by fandy
		//var totalDiscountEnabledListPrice = parseFloat($("#total_discount_enabled_list_price").val());
		var totalDiscountEnabledListPrice = parseFloat($("#total_cut").val());
		console.log("--------------------- 优惠总额/可用于折扣的金额合计 @ discountFUll()-> " +parseFloat(listSaving)+"/"+ totalDiscountEnabledListPrice);
		if(parseFloat(listSaving) > totalDiscountEnabledListPrice){
			$("#all_saving").next().text("直接金额不能大于可折扣的商品小计总和!").css({"color":"#ff0000","font-weight":"bold"});
			$("#all_saving").css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$("#all_saving").next().text("").removeAttr("style");
			$("#all_saving").removeAttr("style");
		}
		
		
		db.transaction(function(tx) {
			tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? AND gift_flag <>1 AND refund_flag = 0 AND discount_enabled = 1 ORDER BY ID DESC", [outletId], function(tx, results) {
			//V2:增加提成
			//tx.executeSql("SELECT cart.*,p.commission_type,p.commission_rate,p.commission_amount  FROM SHOPPINGCARTS cart,PRODUCTS p WHERE cart.product_id=p.product_id AND cart.outlet_id = ? AND cart.refund_flag = 0 AND cart.discount_enabled = 1 ORDER BY cart.ID DESC", [outletId], function(tx, results) {
				
				if (results.rows.length > 0) {// 如果购物车中有商品
					// alert("购物车中存在商品!");

					var len = results.rows.length, i;
					
					// 先检查收银员折扣权限,7-29
					for (i = 0; i < len; i++) {
						var item = results.rows.item(i);				
						
						console.log("--------------------- 是否参与打折/直减A @ discountFUll()-> " +item.product_id+"/"+ item.discount_enabled);
						if(item.discount_enabled!=1){
							continue;
						}

						var id = item.id;
						//var salePrice = doDecimal(item.sale_price-saving*(item.sale_price/totalSalePrice));
						var salePrice = item.sale_price-saving*(item.sale_price/totalDiscountEnabledSalePrice);
						var discount = Math.round(salePrice/item.price*100);
						// 校验收银员权限
						var minDiscount = getSetting("cMinDiscount");
						var role = $("#auth_role").val();
						if(role.indexOf('ROLE_CASHIER')>-1  && discount<parseInt(minDiscount)){
							$("#all_discount").next().html("收银员最低折扣为:"+minDiscount+"%,<br /> 直减后, "+item.product_name+" 折扣为:"+discount+"%.").css({"color":"#ff0000","font-weight":"bold"});
							$("#all_discount").css("border", "1px solid #ff0000").focus().select();
							return;
						}
						else{
							$("#all_discount").next().text("").removeAttr("style");
							$("#all_discount").removeAttr("style");
						}
						
					}

					// 更新折扣、售价、小计、积分开始
					for (i = 0; i < len; i++) {
						var item = results.rows.item(i);
						//V2:创建prouct对象,设置提成规则
						var product = new Object();
						product.commission_type = item.commission_type;
						product.commission_rate = item.commission_rate;
						product.commission_amount = item.commission_amount;
						
						//在上方的select中已筛选过
						//console.log("--------------------- 是否参与打折/直减B  @ discountFUll()-> " item.product_id+"/"+ item.discount_enabled);
						//if(item.discount_enabled!=1){
						//	continue;
						//}

						var id = item.id;
						//var salePrice = doDecimal(item.sale_price-saving*(item.sale_price/totalSalePrice));
						var subtotal = item.subtotal-saving*( item.subtotal / totalDiscountEnabledSalePrice);
						var salePrice = parseFloat(subtotal / item.qty);
						var discount = Math.round(salePrice/item.price*100);	
						
						var subtotalPoints = 0;
						if(item.point_enabled==1){
							subtotalPoints = subtotal*item.point_rate;
						}
						
						//V2:提成
						var subtotalCommission = getCommission(product,item.qty,subtotal);
						
						console.log("--------------------- UPDATE @ discountFull() : discount/sale_price/subtotal/subtotalPoints/subtotalCommission->" 
								+ discount + "/" + salePrice + "/" + subtotal + "/" + subtotalPoints + "/" + subtotalCommission);

						tx.executeSql("UPDATE SHOPPINGCARTS SET discount = ?,sale_price = ?,subtotal = ?, subtotal_points = ?, subtotal_commission = ? WHERE id = ? ", 
								[ discount, parseFloat(doDecimal(salePrice)), parseFloat(doDecimal(subtotal)), parseFloat(doDecimal(subtotalPoints)), parseFloat(doDecimal(subtotalCommission)), id ], function(tx, r) {
							
						}, null);
						
						//_totalSalePrice += subtotal*item.point_rate;//小计总计,用于修正合计,或许存在小计总计不等于合计的问题
						_totalSalePrice += parseFloat(subtotal);//小计总计,用于修正合计,或许存在小计总计不等于合计的问题

					}
					// 更新折扣、售价、小计、积分结束
					
				//修正合计 开始
				var diff = (totalDiscountEnabledSalePrice-parseFloat(saving))-_totalSalePrice;
				console.log("--------------------- diff @ discountFull()->"+diff);
				
				if(diff!=0){
					tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? AND refund_flag = 0 AND discount_enabled = 1 ORDER BY ID DESC", [outletId], function(tx, results) {
					//V2:增加提成
					//tx.executeSql("SELECT cart.*,p.commission_type,p.commission_rate,p.commission_amount  FROM SHOPPINGCARTS cart,PRODUCTS p WHERE cart.product_id=p.product_id AND cart.outlet_id = ? AND cart.refund_flag = 0 AND cart.discount_enabled = 1 ORDER BY cart.ID DESC", [outletId], function(tx, results) {
						
						if (results.rows.length > 0) {// 如果购物车中有商品
							var _item = results.rows.item(0);//使用第一个商品的小计进行修正
							var _id = _item.id;
							var _subtotal = parseFloat(_item.subtotal)+parseFloat(diff);
							var _salePrice = _subtotal/_item.qty;
							var _discount = Math.round(_salePrice/_item.price*100);
							var _subtotalPoints = 0;
							if(_item.point_enabled==1){
								_subtotalPoints = _subtotal*_item.point_rate;
							}
							
							//V2:创建prouct对象,设置提成规则
							var product = new Object();
							product.commission_type = _item.commission_type;
							product.commission_rate = _item.commission_rate;
							product.commission_amount = _item.commission_amount;
							
							//V2:提成
							var _subtotalCommission = getCommission(product,_item.qty,_subtotal);
							
							tx.executeSql("UPDATE SHOPPINGCARTS SET discount = ?,sale_price = ?,subtotal = ?, subtotal_points = ?, subtotal_commission = ? WHERE id = ? ", 
									[ _discount, parseFloat(doDecimal(_salePrice)), parseFloat(doDecimal(_subtotal)),parseFloat( doDecimal(_subtotalPoints)), parseFloat(doDecimal(_subtotalCommission)), _id ], function(tx, r) {
							}, null);
							
						}
					},null);
					
				}
				//修正合计 结束
				
				initDiscountFull();
				$('#discountModal').modal('hide');

				loadCart();// 重新载入购物车
				
				}
			}, null);
		});
		
		
	}
	//直减 结束
	
	//整单折扣 开始
	if(discountType == 2){
		var ths = $("#all_discount");
		var val = $("#all_discount").val();
		
		
		// 校验收银员权限
		var minDiscount = getSetting("cMinDiscount");
		var role = $("#auth_role").val();		
		if(role.indexOf('ROLE_CASHIER')>-1  && parseInt(val)>0 && parseInt(val)<parseInt(minDiscount)){
			$("#all_discount").next().text("收银员最低折扣为:"+minDiscount+"%").css({"color":"#ff0000","font-weight":"bold"});
			$("#all_discount").css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$("#all_discount").next().text("").removeAttr("style");
			$("#all_discount").removeAttr("style");
		}
		
		// 校验折扣
		var reg = /^(?:1|[1-9][0-9]?|100)$/;
		if (!reg.test(val)) {
			$("#all_discount").next().text("请输入折扣,1~100的整数!").css({"color":"#ff0000","font-weight":"bold"});
			$("#all_discount").css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$("#all_discount").next().text("").removeAttr("style");
			$("#all_discount").removeAttr("style");
		}
		
		
		// alert("execute 整单折扣动作");
		// 判断更新类型,更新,然后再载入购物车
		db.transaction(function(tx) {
			tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? AND gift_flag !=1 AND refund_flag = 0 AND discount_enabled = 1 ORDER BY ID DESC", [outletId], function(tx, results) {
				// alert(cartResults.rows.length);
				if (results.rows.length > 0) {// 如果购物车中有商品
					// alert("购物车中存在商品!");

					var len = results.rows.length, i;

					// 更新折扣、售价、小计开始
					for (i = 0; i < len; i++) {
						var item = results.rows.item(i);
						//V2:创建prouct对象,设置提成规则
						var product = new Object();
						product.commission_type = item.commission_type;
						product.commission_rate = item.commission_rate;
						product.commission_amount = item.commission_amount;
						
						//在上方的select中已筛选过
						//console.log("--------------------- 是否参与打折/整折 @ discountFUll()-> " item.product_id+"/"+ item.discount_enabled);
						//if(item.discount_enabled!=1){
						//	continue;
						//}
						

						var id = item.id;
						var salePrice = parseFloat(item.price * (val / 100));// 重新计算售价
						var subtotal = parseFloat(salePrice * item.qty);// 更新折扣需要同时更新小计
						
						var subtotalPoints = 0;
						if(item.point_enabled==1){
							subtotalPoints = subtotal*item.point_rate;
						}
						
						//V2:提成
						var subtotalCommission = getCommission(product,item.qty,subtotal);
						
						console.log("--------------------- UPDATE @ discountFull(2) : discount/sale_price/subtotal/subtotalPoints/subtotalCommission->" 
								+ val + "/" + salePrice + "/" + subtotal + "/" + subtotalPoints + "/" + subtotalCommission);

						tx.executeSql("UPDATE SHOPPINGCARTS SET discount = ?,sale_price = ?,subtotal = ?, subtotal_points = ?, subtotal_commission = ? WHERE id = ? ", 
								[ val, parseFloat(doDecimal(salePrice)), parseFloat(doDecimal(subtotal)), parseFloat(doDecimal(subtotalPoints)), parseFloat(doDecimal(subtotalCommission)), id ], function(tx, r) {
							
						}, null);

					}
					// 更新折扣、售价、小计结束
					
					initDiscountFull();
					$('#discountModal').modal('hide');

					loadCart();// 重新载入购物车
				}
			}, null);
		});
	}
	//整单折扣 结束
}


//挂单备注,3-13
function parkRemark(){
	//loadSaleItems2Receipt();
	
	if ($("#cart tbody").children("tr").length == 0) {
		//alert("没有需要挂单的商品!");
		return;
	}
	
	//挂单打印按钮处理
	if(getSetting("parkPrintEnabled")){
		$("#park_print_div").removeClass("hide");
	} else {
		$("#park_print_div").removeClass("hide").addClass("hide");
		$("#park_btn").parent().removeClass("col-sm-6").addClass("col-sm-12");
	}

	//$("#park_receipt_div").addClass("hide");
	$('#parkModal').modal('show');
	
	//启用挂单备注
	var parkRemarkEnabled = getSetting("cParkRemark");
	console.log("--------------------- parkRemarkEnabled ->"+parkRemarkEnabled+"/"+(parkRemarkEnabled=='1'));
	if(parkRemarkEnabled=='1'){
		$("#park_remark_div").removeClass("hide");
		$('#parkModal').one('shown.bs.modal',function(){
			$('#park_remark').select(); 
		});
	}
	
	$('#parkModal').modal('show');
	
	$("#park_print").prop("checked",false);
	
	//贴标打印时机 ADD BY CPQ
	var tagPrintTiming = 0;
	var tagJson = localStorage.getItem("PRINTER_TAG");
	if(tagJson){
		tagJson = JSON.parse(tagJson);
		tagPrintTiming = tagJson.print_timing;
	}
	
	var tagPrintCheck = tagPrintTiming == 1;
	$("#park_tag_print").prop("checked",tagPrintCheck);
	$("#park_tag_print").prop("checked", tagPrintCheck);
	
	//桌号启用， 没有设置桌号时，提示用户 ADD BY CPQ
	var suffix = $("#desk_no_suffix").val();
	var desk_no = $("#desk_no").val();
	
	if(getSetting('Industry') == '1003' && getSetting("desk_no_enabled") == 1
		&& (!suffix || !desk_no) && !$("#select_desk_no").hasClass("hidden")){
		message("您没有设置桌号.");
	}
}

// 挂单
function park() {
	
	console.log("----------------- execute park() -----------------");
	
	// if($("#total_qty").val()==0||$("#total_qty").val()=="0"){//这个条件可能有问题,如果是赠品呢?需要判断tbody有没有行存在
	// alert($("#cart tbody").children("tr"));
	if ($("#cart tbody").children("tr").length == 0) {
		//alert("没有需要挂单的商品!");
		return;
	}
	
	var saleOrderNo = ((new Date()).valueOf()).toString();// 用时间戳作为单号
	var saleDate = parseDate(new Date(),"yyyy/MM/dd hh:mm:ss");
	
	var parkRemark = $("#park_remark").val();

	var uId = $("#auth_id").val();
	var username = $("#auth_username").val();
	
	var empExsit = typeof($("#employee_id").val())!='undefined'&&$("#employee_id").val()!=null&&$("#employee_id").val()!=''; 
	var employeeId = empExsit?$("#employee_id").val():0;
	var employeeName = empExsit?$("#employee_name").val():"";
	console.log("----------------- 导购员 @park() -----------------"+employeeId+"/"+employeeName);
	var saleType = $("#customer_sale_type").val()==''?-1:$("#customer_sale_type").val();//如果出现空异常,设为默认值-1
	
	//奶咖版桌号选择 ADD BY CPQ 20161216 START
	var suffix = $("#desk_no_suffix").val();
	var desk_no = $("#desk_no").val();
	var deskNo = suffix && desk_no ? (suffix + "_" + desk_no) : "";
	//奶咖版桌号选择 ADD BY CPQ 20161216 END
	
	db.transaction(function(tx) {
		//取得流水号 ADD BY CPQ
		var sequence = getCateringSeq();
		
		// 插入销售单头;
		console.log("----------------- 插入销售单头 @park() -----------------");
		tx.executeSql('INSERT INTO SALEORDERS (sale_order_no, company_id, outlet_id, username, employee_id, employee_name, customer_code, sale_type, total_amount, total_qty, total_points, total_commission, pay, changex, payment, sale_date, status, user_id, remark,desk_no,sequence) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', 
				[ saleOrderNo, companyId, outletId, username, employeeId, employeeName, $("#customer_no").val(), saleType, $("#total_price").val(), $("#total_qty").val(), $("#total_points").val(), $("#total_commission").val(), "0", "0", "", saleDate, 0, uId, parkRemark ,deskNo,sequence],

		function(tx, results) {
			// alert(results.insertId);

			var sale_order_id = results.insertId;

			tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? ORDER BY IFNULL(parent_seq,id) DESC,id ASC", [outletId], function(tx, results) {
				if (results.rows.length > 0) {// 如果购物车中有商品
					// alert("购物车中存在商品!");
					// 插入销售明细;
					var len = results.rows.length, i;
					var parentSeq;
					for (i = 0; i < len; i++) {
						// alert(results.rows.item(i));
						var p = results.rows.item(i);
						
						if(!p.parent_seq){
							parentSeq = i+1;
						}
						
						var insertParentSeq = p.parent_seq ? parentSeq : 0;
						var _discount = isNumber(p.discount) && p.discount!='' && p.discount!=null && p.discount!='null'?p.discount:0;//防止null出现
						
						console.log("----------------- 插入销售明细("+i+")  @park() -----------------");
						tx.executeSql(
								'INSERT INTO SALEORDERITEMS (sale_order_no, company_id, outlet_id, sale_order_id, category_id , category_name, brand_id , brand_name, supplier_id , supplier_name, product_id,product_name, barcode, size, cust_props, unit, supply_price,  price, wholesale_price,vip_price, discount_enabled, vip_discount_type, discount, sale_price, qty, subtotal_price,  point_enabled, point_rate,subtotal_points , subtotal_commission,  refund_flag, commission_type, commission_rate, commission_amount,tastes,remark,employee_id,employee_name,seq,parent_seq, gift_enabled, gift_flag) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', 
								[saleOrderNo, companyId, outletId, sale_order_id, p.category_id, p.category_name, p.brand_id, p.brand_name, p.supplier_id, p.supplier_name, p.product_id, p.product_name, p.barcode, p.size, p.cust_props, p.unit, p.supply_price, p.price, p.wholesale_price, p.vip_price, p.discount_enabled, p.vip_discount_type, _discount, p.sale_price, p.qty, p.subtotal, p.point_enabled, p.point_rate,p.subtotal_points , p.subtotal_commission,  p.refund_flag, p.commission_type, p.commission_rate, p.commission_amount ,p.tastes,p.remark,p.employee_id || 0,p.employee_name,i+1,insertParentSeq, p.gift_enabled, p.gift_flag], 
								function(tx, res) {
							//挂单成功@item
						}, function(tx, error) {
							alert('挂单失败: ' + error.message);
						});
						
						
						///////////////
						//迭代到最后一个时,execute 后续操作,4-9
						if(i == len-1){
							console.log("----------------- 挂单成功后操作 @park() -----------------");
							
							$("#park_remark").val("");

							clearCart();// 清空购物车
							// alert("挂单成功");
							$("#cart tbody").empty();// 再次清理销售单表格,否则会多一个空行,不知道是什么原因,12-20

							// 清空会员信息,并删除COOKIE
							clearCustomerInfo();
							
							// 挂单成功后,计算挂单数量
							initParkCount();
							
							// 清空导购员选项
							removeEmployee(0);
							
							//桌号的处理 ADD BY CPQ
							removeDeskNo(1);
							
							//预打挂单小票
							//var parkRemarkEnabled = getSetting("cParkRemark");
							//console.log("--------------------- parkRemarkEnabled ->"+parkRemarkEnabled);
							
							//if($("#park_print").prop("checked")){
							console.log("----------------- 打印小票CHECKBOX STATE @park() ->"+$("#park_print").prop('checked'));
							if($("#park_print").prop('checked') 
									|| $("#park_tag_print").prop('checked') 
									|| $("#park_kitchen_print").prop('checked')){
								console.log("----------------- 打印小票  @park() -----------------");
								isNotPark = false;
								doPrint(saleOrderNo, 1);//调用打印方法
								
							}
						}
						///////////////

					}
				}
			}, function(tx, error) {
				alert('挂单失败: ' + error.message);
			});

		}, function(tx, error) {
			alert('挂单失败: ' + error.message);
		});
	});

}

//取得所有挂单的单,使用web sql db
function getParkList2() {
	var industry = getSetting("Industry");
	
	//增加桌号启用条件 ADD BY CPQ
	if(industry == "1003" && getSetting("desk_no_enabled") == 1){
		$("#wishlistModal .desk_no_th").removeClass('hidden');
	}
	db.transaction(function(tx,rst) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE outlet_id = ? AND status = 0 order by sale_date desc", [outletId], function(tx, results) {
			// alert(results.rows.length);
			wishlistsize=results.rows.length;
			if (wishlistsize == 0){return;} else {// 存在挂单
				//去掉只有一个挂单时直接取出,无论多少挂单都弹出挂单列表窗口
				/*if (results.rows.length == 1) {
					var so = results.rows.item(0);
					retrieveSale(so.id);
					return;
				}*/
				$("#pCount").html("共有" + results.rows.length + "个挂单");

				$("#btnClearParkList").removeAttr("disabled");

				// 装入wishlist表格
				var len = results.rows.length, i;
				for (i = 0; i < len; i++) {
					// alert(results.rows.item(i));
					// alert("载入第"+(i+1)+"个挂单");
					var so = results.rows.item(i);

					var date = new Date(so.sale_date);
					var _year = date.getFullYear();
					var _month = date.getMonth() + 1;
					if (_month < 10) {
						_month = "0" + _month;
					}
					var _day = date.getDate();// 注意getDay()是获得星期
					var _hours = date.getHours();
					var _min = date.getMinutes();
					var _sec = date.getSeconds();
					// alert(_year+"-"+_month+"-"+_day+"
					// "+_hours+":"+_min+":"+_sec);
					var sale_date = _year + "-" + _month + "-" + _day + " " + _hours + ":" + _min;
					var remarkString = so.remark.length>10?so.remark.substring(0, 10)+"...":so.remark;
					
					var deskNoArray = so.desk_no ? so.desk_no.split("_") : ["",""];
					var desk_no_td = industry == '1003' && getSetting("desk_no_enabled") == 1 ? "<td class='v-m'>"+(deskNoArray.length> 1 ? deskNoArray[1] : "")+"</td>" : '';
					//下行:sale_date>so.sale_date
					var row_tr = "<tr onclick='c_wishlistsel(this)'><td class='v-m'>" + (i + 1) + "</td>"+desk_no_td+"<td class='v-m'>" + so.sale_date + "</td><td class='v-m'>" + so.sale_order_no + "</td><td class='v-m'>" + so.total_qty + "</td><td class='v-m'>" + doDecimal(so.total_amount) 
					+ "</td><td class='v-m'>" + so.customer_code 
					+ "</td><td class='v-m'>" + so.employee_name 
					+ "</td><td class='v-m'><span title='"+so.remark+"'>" + remarkString + "</span></td><td>" 
					+ "<span class='retrieve_sale btn btn-md btn-primary' onclick='retrieveSale(\"" + so.id + "\")'><i class=' glyphicon glyphicon-folder-open'></i> 取单</span>" 					
					//+" <span class=\"btn btn-xs black\" onclick='printReceiptPre(\"" + so.id + "\")'><i class=\"glyphicon glyphicon-print white\"></i> 预打小票</span>"
					+ " <span class=\"del_park btn btn-md btn-danger\" onclick='delPark(\"" + so.id + "\")'><i class=\"glyphicon glyphicon-trash\"></i></span>"
					+"</td></tr>";
					
					//console.log(row_tr);
					$("#wishlist tbody").append(row_tr);
				}
				$('#wishlist tbody tr:first').addClass('wishlistModalHover');
			}
		}, null);
	});
}

// 取得所有挂单的单,使用web sql db//作废
function getParkList() {
	
	db.transaction(function(tx,rst) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE outlet_id = ? AND status = 0 ", [outletId], function(tx, results) {
			// alert(results.rows.length);
			if (results.rows.length > 0){// 存在挂单
				$("#pCount").html("共有" + results.rows.length + "个挂单");

				$("#btnClearParkList").removeAttr("disabled");

				// 装入wishlist表格
				var len = results.rows.length, i;
				for (i = 0; i < len; i++) {
					// alert(results.rows.item(i));
					// alert("载入第"+(i+1)+"个挂单");
					var so = results.rows.item(i);

					var date = new Date(so.sale_date);
					var _year = date.getFullYear();
					var _month = date.getMonth() + 1;
					if (_month < 10) {
						_month = "0" + _month;
					}
					var _day = date.getDate();// 注意getDay()是获得星期
					var _hours = date.getHours();
					var _min = date.getMinutes();
					var _sec = date.getSeconds();
					// alert(_year+"-"+_month+"-"+_day+"
					// "+_hours+":"+_min+":"+_sec);
					var sale_date = _year + "-" + _month + "-" + _day + " " + _hours + ":" + _min;
					
					//下行:sale_date>so.sale_date
					var row_tr = "<tr><td>" + (i + 1) + "</td><td>" + so.sale_date + "</td><td>" + so.sale_order_no + "</td><td>" + so.total_qty + "</td><td>" + so.total_amount + "</td><td>" + so.customer_code + "</td><td>" + "<button class='btn btn-xs' onclick='retrieveSale(\"" + so.id + "\")'><i class=' glyphicon glyphicon-edit'></i> 取单</button> " 
					+ "<span class=\"btn btn-xs red\" onclick='delPark(\"" + so.id 
					+ "\")'><i class=\"glyphicon glyphicon-remove white\"></i></span>" + "</td></tr>";
					
					//console.log(row_tr);
					$("#wishlist tbody").append(row_tr);
				}

			}
		}, null);
	});
}

// 取单
function retrieveSale(id) {
	// 如果购物车有内容,先挂起,然后清空购物车
	// alert($("#total_qty").val());
	// alert($("#cart tbody").children("tr").length);
	if ($("#cart tbody").children("tr").length > 0) {

		park();
		// alert("请先将当前的销售单挂单后,再取单!");

	}

	// 取得数据：从SALEORDERS和SALEORDERITEMS取得相应的的数据
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE id = ? ", [ id ], function(tx, results) {
			// alert(results.rows.length);
			if (results.rows.length > 0) {// 存在挂单
				// alert(results.rows.length);
				var so = results.rows.item(0);
				var customerCode = so.customer_code;
				var employeeId = so.employee_id;
				var employeeName = so.employee_name;
				var saleType = so.sale_type;//add 6-16
				var desk_no = so.desk_no;
				
				//选中桌号列表的桌号，收银时，不再选择桌号 ADD BY CPQ
				$("#desk_no_div .desk_no[value='"+so.desk_no+"']").prop("checked",true);
				
				//设置流水号,收银时,不重新取流水号
				$("#sequence").val(so.sequence);
				
				// 取得明细
				db.transaction(function(tx) {
					tx.executeSql("SELECT * FROM SALEORDERITEMS WHERE sale_order_id = ?  ORDER BY id", [so.id ], function(tx, results) {
						// alert(results.rows.length);
						if (results.rows.length > 0) {// 存在明细
							// alert("execute 取单动作");
							var len = results.rows.length, i;
							var isCatering = getSetting("Industry") == "1003";
							
							if(isCatering){//轻餐饮版时，特别处理 BY CPQ
								tx.executeSql("SELECT seq FROM sqlite_sequence WHERE name=?",['SHOPPINGCARTS'],function(tx,seqResult){
									var seq = 1;
									if(seqResult.rows.length > 0){
										seq = parseInt(seqResult.rows.item(0).seq) + 1;
									}
									
									addSaleOrderItemToCart(tx,results,id,seq,desk_no,saleType,customerCode,employeeId,employeeName);
								})
							}else{
								for (i = 0; i < len; i++) {
									// alert("第"+i+"个明细");
									// alert(results.rows.length);
									var soi = results.rows.item(i);
									
									//单品导购员
									var productEmployeeId = soi.employee_id || 0;
									var productEmployeeName = soi.employee_name || "";
									
									// 装载数据：把取得的数据插入SHOPPINGCARTS。
									tx.executeSql('INSERT INTO SHOPPINGCARTS (outlet_id, category_id , category_name, brand_id , brand_name, supplier_id , supplier_name, product_id, product_name, barcode, size, cust_props,  unit, supply_price, price, wholesale_price, vip_price, discount_enabled, vip_discount_type, commission_type, commission_rate, commission_amount, discount,  sale_price, qty, subtotal, point_enabled, point_rate, subtotal_points, subtotal_commission, refund_flag, update_date,tastes,remark,employee_id,employee_name,parent_seq, gift_enabled, gift_flag) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
											[outletId, soi.category_id, soi.category_name, soi.brand_id, soi.brand_name, soi.supplier_id, soi.supplier_name, soi.product_id, soi.product_name, soi.barcode, soi.size, soi.cust_props, soi.unit, soi.supply_price, soi.price, soi.wholesale_price, soi.vip_price, soi.discount_enabled, soi.vip_discount_type, soi.commission_type, soi.commission_rate, soi.commission_amount, soi.discount, soi.sale_price, soi.qty, soi.subtotal_price, soi.point_enabled, soi.point_rate, soi.subtotal_points, soi.subtotal_commission, soi.refund_flag, parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S") ,soi.tastes,soi.remark,productEmployeeId,productEmployeeName,soi.parent_seq, soi.gift_enabled, soi.gift_flag]);
	
									if (i == len - 1) {// 最后一条execute 完后,删除SALEORDERS和SALEORDERITEMS相关的的数据
										
										//删除前，设置桌号 这样删除时不会再设置 BY CPQ,
										if(desk_no){
											var strs = desk_no.split("_");
											if(strs.length == 2){
												var suffix = strs[0];
												var deskNo = strs[1];
												
												setDeskNo(deskNo,suffix);
												setDeskNoUsed(0)
											}
										}
										
										delPark(id);
										
										// 会员处理,1-6
										if (customerCode) {	
											initCustomerInfo(saleType,customerCode);
										}
										
										// 导购员处理
										
										//单品导购设置为最后一个商品的导购员 ADD BY CPQ
										$("#product_employee_id").val(productEmployeeId);
										$("#product_employee_name").val(productEmployeeName);
										
										if(employeeId!=null && employeeId!=''){
											setEmployee(employeeId,employeeName,0,1);
										}
									}
								}
							}

							$('#wishlistModal').modal('hide');
						} else {
							alert('取单失败,ERROR CODE:00: 没有明细');
						}
					}, function(tx, error) {
						alert('取单失败,ERROR CODE:02: ' + error.message);
					});
				});
			}
		}, function(tx, error) {
			alert('取单失败,ERROR CODE:01: ' + error.message);
		});
	},null,function(){
		// 载入购物车
		loadCart();
	});
}

//取单时将明显插入购物车,轻餐饮用 ADD BY CPQ
function addSaleOrderItemToCart(tx,results,id,seq,desk_no,saleType,customerCode,employeeId,employeeName){
	var len = results.rows.length,i;
	var parentSeqMap = {};
	for(i = 0; i < len; i++){
		var soi = results.rows.item(i) || results.rows[i];
		if(!soi.parent_seq){
			parentSeqMap[soi.seq] = seq+i;
		}
	}
	
	for(i = 0; i < len; i++){
		var soi = results.rows.item(i) || results.rows[i];
		//单品导购员
		var productEmployeeId = soi.employee_id || 0;
		var productEmployeeName = soi.employee_name || "";
		var parentSeq = parentSeqMap[soi.parent_seq] || null;
		
		// 装载数据：把取得的数据插入SHOPPINGCARTS。
		tx.executeSql('INSERT INTO SHOPPINGCARTS (id,outlet_id, category_id , category_name, brand_id , brand_name, supplier_id , supplier_name, product_id, product_name, barcode, size, cust_props,  unit, supply_price, price, wholesale_price, vip_price, discount_enabled, vip_discount_type, commission_type, commission_rate, commission_amount, discount,  sale_price, qty, subtotal, point_enabled, point_rate, subtotal_points, subtotal_commission, refund_flag, update_date,tastes,remark,employee_id,employee_name,parent_seq, gift_enabled, gift_flag) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
				[seq,outletId, soi.category_id, soi.category_name, soi.brand_id, soi.brand_name, soi.supplier_id, soi.supplier_name, soi.product_id, soi.product_name, soi.barcode, soi.size, soi.cust_props, soi.unit, soi.supply_price, soi.price, soi.wholesale_price, soi.vip_price, soi.discount_enabled, soi.vip_discount_type, soi.commission_type, soi.commission_rate, soi.commission_amount, soi.discount, soi.sale_price, soi.qty, soi.subtotal_price, soi.point_enabled, soi.point_rate, soi.subtotal_points, soi.subtotal_commission, soi.refund_flag, parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S") ,soi.tastes,soi.remark,productEmployeeId,productEmployeeName,parentSeq, soi.gift_enabled, soi.gift_flag]);
		
		seq++;
		
		if (i == len - 1) {// 最后一条execute 完后,删除SALEORDERS和SALEORDERITEMS相关的的数据
			
			//删除前，设置桌号 这样删除时不会再设置 BY CPQ,
			if(desk_no){
				var strs = desk_no.split("_");
				if(strs.length == 2){
					var suffix = strs[0];
					var deskNo = strs[1];
					
					setDeskNo(deskNo,suffix);
					setDeskNoUsed(0)
				}
			}
			
			delPark(id);
			
			// 会员处理,1-6
			if (customerCode) {	
				initCustomerInfo(saleType,customerCode);
			}
			
			// 导购员处理
			
			//单品导购设置为最后一个商品的导购员 ADD BY CPQ
			$("#product_employee_id").val(productEmployeeId);
			$("#product_employee_name").val(productEmployeeName);
			
			if(employeeId!=null && employeeId!=''){
				setEmployee(employeeId,employeeName,0,1);
			}
		}
	}
}

//取单 点击选中
function c_wishlistsel(ele){
	if($(ele).hasClass('wishlistModalHover'))return;
	$(ele).siblings().each((i,e)=>{
		$(e).removeClass('wishlistModalHover')
	});
	$(ele).addClass('wishlistModalHover');
}

// 删除挂单
function delPark(id) {

	// 取得数据：从SALEORDERS和SALEORDERITEMS取得相应的的数据
	// 如果存在单头与单体,则一起删除,如果只存在单头,则删除单头(一般不会出现)
	// 删除数据后,重新载入挂单列表
	id = id.toString().trim();

	// alert(id);
	var usedDeskNo = "";
	
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE id = ? ", [ id ], function(tx, results) {

			if (results.rows.length > 0) { // 存在挂单
				// alert("存在挂单");
				var so = results.rows.item(0);
				var desk_no = so.desk_no;
				if(desk_no){
					var strs = desk_no.split("_");
					if(strs.length == 2){
						usedDeskNo = strs[1];
					}
				}
				
				// 取得明细
				tx.executeSql("SELECT * FROM SALEORDERITEMS WHERE sale_order_id = ?  ORDER BY id", [ so.id ], function(tx, results) {
					// alert("存在明细,行数->"+
					// results.rows.length);
					if (results.rows.length > 0) { // 存在明细
						tx.executeSql("DELETE FROM SALEORDERITEMS WHERE sale_order_id = ? ", [ so.id ], function() {
							// alert("成功删除明细!");
							// 重新计算挂单数量
							initParkCount();
						}, function() {
							alert("删除明细失败!");
						});
						tx.executeSql("DELETE FROM SALEORDERS WHERE id = ? ", [ id ], function() {
							// alert("成功删除单头!");
						}, function() {
							alert("删除单头失败!");
						});

						$("#wishlist tbody").empty(); // 清空现在的
						getParkList2(); // 重新载入挂单列表
						// alert('删除成功!');
					} else { // 无明细
						// alert("execute 删除单头动作1");
						tx.executeSql("DELETE FROM SALEORDERS WHERE id = ? ", [ id ], null, null);

						$("#wishlist tbody").empty(); // 清空现在的
						getParkList2(); // 重新载入挂单列表
						// alert('删除成功!');
					}
				}, null);
			} else { // 无明细
				// alert("execute 删除单头动作2");
				tx.executeSql("DELETE FROM SALEORDERS WHERE id = ? ", [ id ], null, null);

				$("#wishlist tbody").empty(); // 清空现在的
				getParkList2(); // 重新载入挂单列表
				// alert('删除成功');
			}
		}, function(tx, error) {
			alert('删除失败: ' + error.message);
		});
	},null,function(){
		//取单时$("#desk_no").val() 有值，已设置过桌号状态，不再设置
		if(usedDeskNo && !$("#desk_no").val()){
			$("#desk_no").val(usedDeskNo);
			setDeskNoUsed(0);
			$("#desk_no").val("");
		}
	});
}

// 清空挂单列表
function clearParkList() {
	// 先删除明细,如果成功,再删除单头
	db.transaction(function(tx) {
		tx.executeSql("DELETE FROM SALEORDERITEMS WHERE sale_order_id IN (SELECT id FROM SALEORDERS WHERE outlet_id = ? AND status = 0) ", [outletId], function(tx, results) {
			tx.executeSql("DELETE FROM SALEORDERS WHERE outlet_id = ? AND status = 0 ", [outletId])
			$("#wishlist tbody").empty();// 清空所有行
			initParkCount();
		}, function(tx, error) {
			alert('清空失败: ' + error.message);
		});
	});
}

// 初始化挂单数量,1-24
function initParkCount() {
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE outlet_id = ? AND status = 0 ", [outletId], function(tx, results) {
			console.log("--------------- 挂单数量-> " + results.rows.length);
			if(results.rows.length>0){
				$("#wishlist_size").text(results.rows.length);
				wishlistsize = results.rows.length;
			}
			else{
				$("#wishlist_size").text('');
				wishlistsize = 0;
			}
		}, null);
	});
}


//初始化整单折扣,4-9
function initDiscountFull(){
	var totalDiscountEnabledListPrice = parseFloat($("#total_discount_enabled_list_price").val());
	if(totalDiscountEnabledListPrice==0 || totalDiscountEnabledListPrice=='0' || totalDiscountEnabledListPrice =='' || totalDiscountEnabledListPrice ==null){
		alert("销售单中没有可以折扣的商品 !");
		return;
	}
	
	var dt = getSetting("cAllDiscountType");
	
	//默认直减
	if(dt==2){
		$('#btn_discount_type_a').removeClass('btn-primary');
		$('#btn_discount_type_b').addClass('btn-primary');
		$('#discount_b').removeClass('hide');
		$('#discount_a').addClass('hide');
		$('#all_discount_type').val(2);
	}
	else{	
		$('#btn_discount_type_b').removeClass('btn-primary');
		$('#btn_discount_type_a').addClass('btn-primary');
		$('#discount_a').removeClass('hide');
		$('#discount_b').addClass('hide');
		$('#all_discount_type').val(1);	
	}
	
	var totalListPrice = $("#total_list_price").val();
	var totalPrice = $("#total_price").val();
	var totalSaving = $("#total_saving").val();
	
	//初始金额折扣与CSS
	$("#final_pay").val(totalPrice);
	$('#all_saving').val(totalSaving);	
	$('#all_discount').val(100);		
	
	$("#all_discount,#final_pay,#all_saving").next().text("").removeAttr("style");
	$("#all_discount,#final_pay,#all_saving").removeAttr("style");
	
	//$("#btnDiscountFull").attr("disabled", "disabled");
	
	$('#discountModal').modal('show');
	if(dt==1){
		$('#discountModal').one('shown.bs.modal',function(){$('#final_pay').select();});
	}
	else{
		$('#discountModal').one('shown.bs.modal',function(){$('#all_discount').select();});
	}
	
}


//初始化退货,2014-8-25
function initRefund(){
	//清空所有搜索输入
	$("#receipt_no").val("");
	$("#barcode_4_r").val("");
	$("#start_sale_date_4_r").val("");
	$("#end_sale_date_4_r").val("");

	// 清空之前查询过的数据
	$('#refund_order_header span').each(function() {
		// alert($(this).text());
		$(this).text("");
	});
	
	$('#btnRefundSelectAll').text('全选');
	
	$("#refund_order_items tbody").empty();
	$("#sale_orders_4_r tbody").empty();
	
	$("#customer_sale_type_4_refund").val('');
	$("#customer_4_refund").val('');
	$("#employee_4_refund").val('');
	
	// 隐藏销售单显示层
	$("#refund_by_order").show();
	$("#refund_by_product").hide();
	
	$('#refund_order_div').hide();
	$('#refund_order_list_div').hide();
	
	$("#btnRefundItems").attr("disabled","disabled");
	$("#btnBack4r").hide();
	$("#btnSearchReceiptBybarcode").show();
	$("#search_receipt_alert").hide();
	
	$("#search_server_flag").val(0);
	
	
	$('#refundModal').modal('show');
}

// 取得销售历史
function getSalesHistory() {
	// 清空一下
	$("#sales_history tbody").empty();
	$("#shCount").html("");
	$("#order_div").hide();
	$("#order_div span").text("");
	$("#order_items tbody").empty();
	var startDate = $("#start_sale_date").val() + " 00:00:00";
	var endDate = $("#end_sale_date").val() + " 23:59:59";
	
	var unPart = "";//暂时去掉收银员7-16

	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE outlet_id = ? AND status = 1 " + unPart + " AND sale_date between ? and ? order by sale_date desc ", [outletId, startDate, endDate ], function(tx, results) {
			// alert(results.rows.length);
			if (results.rows.length > 0) {// 存在销售单

				var totalAmount = 0;
				var totalSaleQty = 0;

				// 装入表格
				var len = results.rows.length, i;
				for (i = 0; i < len; i++) {
					// alert(results.rows.item(i));
					// alert("载入第"+(i+1)+"个销售单");
					var so = results.rows.item(i);

					var date = new Date(so.sale_date);
					var _year = date.getFullYear();
					var _month = date.getMonth() + 1;
					if (_month < 10) {
						_month = "0" + _month;
					}
					var _day = date.getDate();// 注意getDay()是获得星期
					var _hours = date.getHours();
					var _min = date.getMinutes();
					var _sec = date.getSeconds();
					// alert(_year+"-"+_month+"-"+_day+"
					// "+_hours+":"+_min+":"+_sec);
					var sale_date = _year + "-" + _month + "-" + _day + " " + _hours + ":" + _min;
					
					//下行:sale_date>so.sale_date,by fandy
					//var row_tr = "<tr data-soid='"+ so.id +"'><td>" + (i + 1) + "</td><td>" + so.sale_date + "</td><td>" + so.sale_order_no + "</td><td>" + so.total_qty + "</td><td>" + doDecimal(so.total_amount) + "</td><td>" + so.customer_code + "</td><td>" + so.payment + "</td><td>" + so.username + "</td></tr>";
					//edited by fandy AT 2015-10-28
					var row_tr = "<tr data-soid='"+ so.id +"' data-order_type='"+so.order_type+"'>"
						+"<td title='交易时间:"+so.sale_date+"'>" + so.sale_order_no + "</td>"
						+"<td>" + doDecimal(so.total_amount) + "</td>"
						+"<td>" + getPayment(so.payment) + "</td>"
						+"<td>" + so.username + "</td>"
						+"</tr>";
					
					

					// alert(row_tr);
					$("#sales_history tbody").append(row_tr);

					totalAmount += parseFloat(so.total_amount);
					totalSaleQty += getSetting("Industry") == "1001"?parseInt(so.total_qty):parseFloat(so.total_qty);
				}
				
				console.log("历史合计->",results.rows.length,doDecimal(totalAmount));
				//$("#shCount").html("共有" + results.rows.length + "个销售单,合计金额" + doDecimal(doRound(totalAmount)) + "元");
				$(".history-order-num").text(results.rows.length);
				$(".history-product-num").text(totalSaleQty);
				$(".history-order-total").text(doDecimal(totalAmount));
				
				$('#sales_history tbody tr:first').addClass('currentRow');
				openReceipt($('#sales_history .currentRow').data('soid'));
			}
			else{
				//无销售
				$(".history-order-num").text(results.rows.length);
				$(".history-product-num").text(0);
				$(".history-order-total").text(doDecimal(0.00));
			}
			resizeSalesHistoryModal();
		}, null);
	});
}

// 打开销售单(用于销售记录中),id为销售单ID
function openReceipt(id) {
	// 首先清空原有数据
	$('#order_header span').each(function() {
		// alert($(this).text());
		$(this).text("");
	});
	$("#order_items tbody").empty();
	$("#show_refund_btn").hide();

	// 搜索web sql
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE id = ? ", [ id ], function(tx, results) {
			// alert(results.rows.length);
			if (results.rows.length > 0) {

				$("#order_div").css("display", "block");

				// 处理单据头
				var so = results.rows.item(0);
				var isRefund = so.order_type == 1;
				var totalRefundQty = so.total_refund_qty || 0;
				
				//总数量大于等于已退金额并且总数量大于等于0
//				if(so.total_qty && so.total_qty >= 0
//						&& (!so.total_refund_qty || parseFloat(so.total_qty) > parseFloat(so.total_refund_qty))){
//					$("#show_refund_btn").show();
//				}
				
				$("#order_header span[name=li_receipt_no]").text(so.sale_order_no);
				$("#order_header span[name=li_cash]").text(so.sale_date);
				$("#order_header span[name=li_total]").text(doDecimal(so.total_amount));
				$("#order_header span[name=li_qty]").text(doDecimal2(so.total_qty ));
				$("#order_header span[name=li_payment]").text(getPayment(so.payment));
				$("#order_header span[name=li_customer]").text(so.customer_code);
				$("#order_header span[name=li_cashier]").text(so.username);
				$("#order_header span[name=li_guide]").text(so.employee_name);
				
				//支付金额从PR中取
				getPayRecordBySaleOrderNo(so.sale_order_no, function(prs){
					$("#order_header span[name=li_payrecord]").text(prs);
				}, isRefund);
				
				
				if(!so.remark) $(".order-remark").addClass("hide");
				else $(".order-remark").removeClass("hide");
				
				$("#order_header span[name=li_remark]").text(so.remark);//备注

				// alert(saleOrder.id);
				// 处理单据体
				// db.transaction(function(tx) {
				tx.executeSql("SELECT * FROM SALEORDERITEMS WHERE sale_order_id = ?  ORDER BY id", [ so.id ], function(tx, results) {
					// alert(results.rows.length);
					if (results.rows.length > 0) {
						var len = results.rows.length, i;
						var totalSaleQty = 0;
						for (i = 0; i < len; i++) {
							// alert("第"+i+"个明细");
							// alert(results.rows.length);
							var soi = results.rows.item(i);
							
							if(soi.qty > 0){
								totalSaleQty += soi.qty;
							}
							
							var custProps = custPropFormatted(soi.cust_props, true);
							// MODIFY BY OKHPXOK 20151110 START 
							var row_tr = "<tr><td>" + (i + 1) + "</td>" +
									"<td style='width: 190px;max-width: 190px;overflow:hidden;text-overflow:ellipsis;'><span title='"+soi.product_name+ + custProps+"'>" + soi.product_name + custProps + "</span>" + "</td>" +
									"<td><span class='text-muted-l'>" + soi.barcode + "</span></td>" +
									"<td>" + doDecimal(soi.price) + "</td>" +
									"<td>" + doDecimal(soi.discount) + "</td>" +
									"<td>" + doDecimal(soi.sale_price) + "</td>" +
									"<td>" + doDecimal2(soi.qty) + "</td>" +
									"<td>" + doDecimal(soi.subtotal_price) + "</td>" +
									"<td>" + (soi.employee_name || "") + "</td>" +
									"</tr>";

							// 载入表格
							$("#order_items tbody").append(row_tr);
							
							if(i == len-1){
								$("#btnRePrint").attr('disabled',false);
								//$("#btnRePrint").attr("onclick","doPrint('"+so.sale_order_no+"');");
								//需要设置rePrintFlag true 表示是重打小票 MODIFY BY CPQ 20161214
								$("#btnRePrint").unbind('click');
								$("#btnRePrint").click(function(){
									rePrintFlag = true;
									doPrint(so.sale_order_no, 2);
								})
							}

						}
						resizeSalesHistoryModal();
						if(totalSaleQty > 0 && (totalSaleQty > totalRefundQty || totalRefundQty == 0) ){
							$("#show_refund_btn").show();
						}
					}
				}, null);
			} else {// 找不到匹配的销售单
				//alert("找不到匹配的销售单!");
				$("#refund_order_div").css("display", "none");
			}

		}, null);
	});
}
function resizeSalesHistoryModal(){	
	$("#sales_history").parents(".card-body").outerHeight(document.body.scrollHeight-$("#salesHistoryModal .modal-header").outerHeight()-30-$("#btnRePrint").parents(".row").height()-$("#salesHistoryModal .history-order-total").parents(".card-heading").outerHeight()-41-24-2);
	$("#order_items").parents(".card-body").outerHeight($("#sales_history").parents(".card").outerHeight()-$("#order_header").outerHeight());	
}

//取得订单支付金额
function getPayRecordBySaleOrderNo(orderNo,callback, isRefund){
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM PAYRECORDS WHERE sale_order_no = ? ", [ orderNo ], function(tx, results) {
			console.log("*********PR 个数->",results.rows.length);
			var len = results.rows.length;
			if (len == 1){
				var pr = results.rows.item(0);
				callback(doDecimal(isRefund ? Math.abs(pr.amount) : pr.amount));
			}
			else if (len > 1){
				var prs = "";
				for (i = 0; i < len; i++) {
					var pr = results.rows.item(i);
					prs +=  PAYMENT_ARRAY[pr.payment]+":"+doDecimal(isRefund ? Math.abs(pr.amount) : pr.amount )+(i<len-1?', ':'')
				}
				callback(prs);
			}
			else{
				callback([]);
			}
			
		});
	});
}



//改变退货方式,2014-6-26
function changeRefundMode(m){
//	if(m==1){		
//		$("#refund_by_order").show();
//		$("#refund_by_product").hide();
//		$("#btnBack4r").hide();
//	}
//	if(m==2){		
//		$("#refund_by_order").hide();
//		$("#refund_by_product").show();
//		$("#btnBack4r").show();
//	}
	$("#refund_by_order").toggle();
	$("#refund_by_product").toggle();
	$("#btnBack4r").toggle();
	$("#btnSearchReceiptBybarcode").toggle();
	
	$('#receipt_no:visible').select();
	$('#barcode_4_r:visible').select();
}

//search receipt for refund,6-28
function searchReceipt(){
	var barcode = $("#barcode_4_r").val();
	var startDate = $("#start_sale_date_4_r").val();
	var endDate = $("#end_sale_date_4_r").val();
	
	var alertObj = $('#search_receipt_alert');
	if(!barcode){
		//setAlertMsg(alertObj,"条码不允许为空!","alert alert-danger");
		message("条码不允许为空!");
		return;
	}
	
	var regx = /^(([^\^\.<>%&',;=?$"':#@!~\]\[{}\\/`\|])*)$/g;
	if(!regx.test(barcode)){
		//setAlertMsg(alertObj,"条码不允许包含特殊字符!","alert alert-danger");
		message("条码不允许包含特殊字符!");
		return;
	}
	
	if(!startDate || !endDate){
		//setAlertMsg(alertObj,"日期不允许为空!","alert alert-danger");
		message("日期不允许为空!");
		return;
	}
	else if(new Date( isSafari()?startDate.replace(/-/g,"/"):startDate).getTime()>new Date( isSafari()?endDate.replace(/-/g,"/"):endDate ).getTime()){
		//setAlertMsg(alertObj,"结束日期不能早于开始日期!","alert alert-danger");
		message("结束日期不能早于开始日期!");
		return;
	}
	
	$('#refund_order_list_div').show();
	
	//清空原来的搜索结果
	$("#sale_orders_4_r tbody").empty();
	
	if(online){
		//search server db start
		
		$.post(apiurl+"getSaleOrdersByBarcode",{barcode:barcode, start_date:startDate, end_date:endDate},function(result){
			console.log("---------------------------- order count->"+result.length);
			var len = result.length;
			if(len==0){
				//setAlertMsg(alertObj,"没有匹配的销售单!","alert alert-danger");
				message("没有匹配的销售单!");
				$('#refund_order_div').hide();
				return;
			}
			if(len>0){
				//setAlertMsg(alertObj,"共搜索到 "+len+" 个销售单!","alert alert-success");
				
				for(var i=0; i<len; i++){
					var so = result[i];
					
					var date = new Date(so.sale_date);
					var _year = date.getFullYear();
					var _month = date.getMonth() + 1;
					if (_month < 10) {
						_month = "0" + _month;
					}
					var _day = date.getDate();// 注意getDay()是获得星期
					var _hours = date.getHours();
					var _min = date.getMinutes();
					var _sec = date.getSeconds();
					// alert(_year+"-"+_month+"-"+_day+"
					// "+_hours+":"+_min+":"+_sec);
					var sale_date = _year + "-" + _month + "-" + _day + " " + _hours + ":" + _min;
					
					//下行:sale_date>so.sale_date
					//var row_tr = "<tr><td>" + (i + 1) + "</td><td>" + so.sale_date + "</td><td>" + so.sale_order_no + "</td><td>" + so.total_qty + "</td><td>" + so.total_amount + "</td><td>" + so.customer_code + "</td><td>" + so.payment + "</td><td>" + so.username + "</td><td>" + "<button class='btn btn-success' onclick='viewReceipt(\"" + so.sale_order_no + "\");changeRefundMode(1);'><i class='glyphicon glyphicon-folder-open'></i> 打开 </button>" + " </td></tr>";
					var row_tr = "<tr><td>" + (i + 1) + "</td><td>" + so.sale_date + "</td><td>" + so.sale_order_no + "</td><td>" + so.total_amount + "</td><td>" + PAYMENT_ARRAY[so.payment] + "</td><td>" + so.customer_code + "</td><td>" + "<button class='btn btn-xs btn-primary' onclick='viewReceiptByBarcode(\""+so.sale_order_no+"\")'><i class='glyphicon glyphicon-folder-open'></i> 打开 </button>" + " </td></tr>";
					
					// alert(row_tr);
					$("#sale_orders_4_r tbody").append(row_tr);
				}
			}
			
		},"json");
		//search server db end
	}
	else{
		
		//search local db start
		// 结束日期需要加上一天
		var dtEndDate = new Date( isSafari()?endDate.replace(/-/g,"/"):endDate );
		var tmpDate = new Date();
		tmpDate.setTime(dtEndDate.setDate(dtEndDate.getDate() + 1));
		//endDate = tmpDate.Format("yyyy-MM-dd").toString();// 格式化并转为字符串
		endDate = parseDate(tmpDate,"yyyy/MM/dd");
		
		db.transaction(function(tx) {
			tx.executeSql("SELECT * FROM SALEORDERS WHERE status = 1 AND outlet_id = ? AND sale_date between ? and ? ", [outletId, startDate, endDate ], function(tx, results) {
				// alert(results.rows.length);
				if (results.rows.length > 0) {// 存在销售单

					var totalAmount = 0;

					// 装入表格
					var len = results.rows.length, i;
					for (i = 0; i < len; i++) {
						// alert(results.rows.item(i));
						// alert("载入第"+(i+1)+"个销售单");
						var so = results.rows.item(i);

						var date = new Date(so.sale_date);
						var _year = date.getFullYear();
						var _month = date.getMonth() + 1;
						if (_month < 10) {
							_month = "0" + _month;
						}
						var _day = date.getDate();// 注意getDay()是获得星期
						var _hours = date.getHours();
						var _min = date.getMinutes();
						var _sec = date.getSeconds();
						// alert(_year+"-"+_month+"-"+_day+"
						// "+_hours+":"+_min+":"+_sec);
						var sale_date = _year + "-" + _month + "-" + _day + " " + _hours + ":" + _min;

						//下行:sale_date>so.sale_date
						var row_tr = "<tr><td>" + (i + 1) + "</td><td>" + so.sale_date + "</td><td>" + so.sale_order_no + "</td><td>" + so.total_qty + "</td><td>" + so.total_amount + "</td><td>" + so.customer_code + "</td><td>" + PAYMENT_ARRAY[so.payment] + "</td><td>" + so.username + "</td><td>" + "<button class='btn btn-xs btn-primay' onclick='viewReceiptByBarcode(\""+so.sale_order_no+"\")'><i class='glyphicon glyphicon-folder-open'></i> 打开 </button>" + " </td></tr>";

						// alert(row_tr);
						$("#sale_orders_4_r tbody").append(row_tr);

						totalAmount += parseFloat(so.total_amount);
					}

					

				}
			}, null);
		});
		//search local db end
	}
	
	
}

function viewReceiptByBarcode(sno){
	//检查是否有其它销售单在退货中
	if(checkIfHasOtherRefund(sno)){
		return;
	}
	viewReceipt(sno);
	changeRefundMode(1);
}

// 查找销售单(用于退货),sn为单号//2014-3-10更新,如果本地找不到,再向服务器端查询,返回JSON
function viewReceipt(sn) {
	if (!sn || sn.length==0) {
		message("请输入单号!")
		return;
	}
	
	//检查是否有其它销售单在退货中
	if(checkIfHasOtherRefund(sn)){
		return;
	}
	
	// 首先清空原有数据
	$('#refund_order_header span').each(function() {
		// alert($(this).text());
		$(this).text("");
	});
	$("#refund_order_items tbody").empty();
	$("#refund_product_items tbody").empty();

	var receiptNo = sn.replace(/(^\s*)|(\s*$)/g, '');// 去除前后空格

	// alert(receiptNo);

	//前提:需要连线
	
	if(online){
		//向服务器查询
		$.ajax({
			url:apiurl+"getSaleOrderJson",
			type:"POST",
			dataType:"json",
			data:{sn:sn},
			success:function(result){
				//alert(result.sale_order_no);
				if(result&&result.sale_order_no==sn){
					
					//先把json保存在LocalStorage里,后续refundItems()用到
					//console.log("---------------- JSON.stringify(result)-> "+JSON.stringify(result));
					//var localStorage = window.localStorage;
					localStorage.setItem("refundJsonStr",JSON.stringify(result));
					
					//***********************//
					$("#refund_order_div").css("display", "block");

					// 处理单据头
					var so = result;
					
					var itemJsonArr = result.items;
					var hideRefundedQtyTd = false;
					var totalSaleQty = 0;
					var totalRefundQty = 0;
					var totalSalePrice = 0;
					
					//alert(itemJsonArr.length);
					for ( var i = 0; i < itemJsonArr.length; i++) {// 迭代JSON数据
						console.log(itemJsonArr[i]);
						var soi= itemJsonArr[i];
						//console.log(soi.product_name);
						
						if(soi.seq == 0 || !soi.seq){
							hideRefundedQtyTd = true;
						}
						
						totalSaleQty += soi.qty;
						totalRefundQty += soi.refund_qty
						totalSalePrice += soi.subtotal_price;
						addItem2ItemsTable(i,soi);
					}
					
					//退货单的总数量和总金额只取大于0的部分(sql取得的只有大于0的)
					if(so.order_type == 1){
						so.total_qty = totalSaleQty;
						so.total_refund_qty = totalRefundQty;
						so.total_amount = doRound(totalSalePrice);
					}
					
					initRefundOrderHeader(so);
					if(hideRefundedQtyTd){
						$(".refunded_qty_td").hide();
					}else{
						$(".refunded_qty_td").show();
					}
					
					$("#search_server_flag").val(1);//表示从server取得销售单数据
					//$('#btnRefundSelectAll').focus();
				}
				else{
					//alert("找不到匹配的销售单!");
//					message("找不到匹配的销售单!");
//					$('#receipt_no').select();
					getOfflineSaleOrder(receiptNo);
				}
				
		    },
		    error:function(XMLHttpRequest, textStatus, errorThrown){
		    	console.log("从服务端查询退货单时发生错误",textStatus,errorThrown);
		    	getOfflineSaleOrder(receiptNo);
		    }
		})
	}
	else{
		//alert("需要网络连线,才可以查询销售记录!");
//		message("需要网络连线,才可以查询销售记录!");
//		$('#receipt_no').select();
		getOfflineSaleOrder(receiptNo);
	}
	
}

//离线取得销售单用于退货
function getOfflineSaleOrder(receiptNo){
	// 搜索web sql
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE outlet_id = ? AND sale_order_no = ? "
				, [outletId, receiptNo ], function(tx, results) {
			// alert(results.rows.length);
			if (results.rows.length > 0) {

				// 处理单据头
				var so = results.rows.item(0);

				// alert(saleOrder.id);
				// 处理单据体
				// db.transaction(function(tx) {
				tx.executeSql("SELECT * FROM SALEORDERITEMS WHERE sale_order_id = ? " +
						" AND (qty+0) > 0 AND ( (qty+0) > (refund_qty+0)" +
						" OR refund_qty IS NULL OR refund_qty = 0 ) ORDER BY seq,id", [ so.id ], function(tx, results) {
					// alert(results.rows.length);
					if (results.rows.length > 0) {
						var len = results.rows.length, i;
						var hideRefundedQtyTd = false;
						
						var totalSaleQty = 0;
						var totalRefundQty = 0;
						var totalSalePrice = 0;
						for (i = 0; i < len; i++) {
							var soi = results.rows.item(i);

							if(soi.seq == 0 || !soi.seq){
								hideRefundedQtyTd = true;
							}
							
							totalSaleQty += soi.qty;
							totalRefundQty += soi.refund_qty;
							totalSalePrice += soi.subtotal_price;
							
							addItem2ItemsTable(i,soi);
						}
						
						if(hideRefundedQtyTd){
							$(".refunded_qty_td").hide();
						}else{
							$(".refunded_qty_td").show();
						}
						
						//退货单的总数量和总金额只取大于0的部分(sql取得的只有大于0的)
						if(so.order_type == 1){
							so.total_qty = totalSaleQty;
							so.total_refund_qty = totalRefundQty;
							so.total_amount = doRound(totalSalePrice);
						}
						
						initRefundOrderHeader(so);
						
						$("#refund_order_div").css("display", "block");
						$("#search_server_flag").val(0);
						
						alert("注意:离线退货无法保证退货数量的准确性,请仔细核对退货情况,以免重复退货.");
						//$('#btnRefundSelectAll').focus();
					}else{
						message("找不到匹配的销售单!");
						$('#receipt_no').select();
					}
				}, null);
			} else {// 找不到匹配的销售单
				//alert("找不到匹配的销售单!");
				//$("#refund_order_div").css("display", "none");
				message("找不到匹配的销售单!");
				$('#receipt_no').select();
				console.log("=========no sale order in local db,try to search server db ===========");
			}

		}, function(tx,error){
			console.log("查询本地退货单时发生错误！",error);
			message("获取本地退货单时发生错误！");
		});
	});
}
//初始化退货销售单(头部)
function initRefundOrderHeader(so){
	$("#li_receipt_no").text(so.sale_order_no);
	$("#li_cash").text(so.sale_date);
	$("#li_total").text(doDecimal(so.total_amount) + " / " + doDecimal(so.total_amount - (so.total_refund_amount || 0)));
	$("#li_total_qty").text(doDecimal2(so.total_qty) + " / " + doDecimal2(so.total_qty - (so.total_refund_qty || 0)));
	$("#li_payment").text(getPayment(so.payment));
	$("#li_customer").text(so.customer_code);
	$("#li_cashier").text(so.username);
	$("#li_guider").text(so.employee_name || "");
	$("#li_price_type").text(so.price_type == 1 ? "批发" :"零售");
	
	$("#customer_sale_type_4_refund").val(so.sale_type);
	$("#customer_4_refund").val(so.customer_code);
	$("#employee_id_4_refund").val(so.employee_id || 0);
	$("#employee_name_4_refund").val(so.employee_name || "");
	$("#remain_refund_qty").val(doDecimal2(so.total_qty - (so.total_refund_qty || 0)));
	$("#remain_refund_amount").val(doDecimal(so.total_amount - (so.total_refund_amount || 0)));
}

//往退货销售单表格插入数据
function addItem2ItemsTable(i,soi){
	// alert("第"+i+"个明细");
	// alert(results.rows.length);
	// 2014-2-16,处理附加属性
	//var custProps = "";
	console.log("------cust_props @ SOI->" + soi.cust_props);
	/*if (soi.cust_props != null && soi.cust_props!='') {
		var propJsonArr = eval("(" + soi.cust_props + ")");
		if (propJsonArr.length > 0) {
			for ( var j = 0; j < propJsonArr.length; j++) {
				for ( var key in propJsonArr[j]) {
					console.log(key + "=" + propJsonArr[j][key]);
					custProps += propJsonArr[j][key] + " , ";
				}
			}
		}
		custProps = custProps != "" && custProps.length > 0 ? "(" + custProps.substring(0, custProps.length - 2) + ")" : "";
	}*/
	//custProps = (soi.cust_props != null && soi.cust_props!='' && soi.cust_props != 'null'  ) ? "(" + soi.cust_props + ")" : "";
	var custProps = custPropFormatted(soi.cust_props, true);
	
	var chk = '<label class="ui-checks ui-checks-md">'
        +'<input type="checkbox" name="soi_id" value="' + soi.id + '" onclick="resetRefundButton();" class="styled" />'
        +'<i></i>'
        +'</label>';
	
	var row_tr = "<tr>" + "<td  style='text-align:center;'>"
		//+"<input onclick='resetRefundButton();' type='checkbox' name='soi_id' value='" + soi.id + "'>"
		+chk +
		"</td><td>" + (i + 1) + "</td>" +
		"<td>" + soi.product_name + custProps + "" + "<br />" + soi.barcode + "</td>" +
		"<td  class='refunded_qty_td'>" + doDecimal2(soi.refund_qty || 0) + "</td>" +
		"<td>" + "<input onchange='validateRefundQty(this," + soi.qty + ","+(soi.refund_qty || 0)+","+soi.sale_price+");' type='number'  name='qty' value='" + (soi.qty - (soi.refund_qty || 0)) + "' class='refund-qty-input' /></td>" +
		"<td>" + "<input onchange='validateRefundAmount(this," + soi.subtotal_price + ","+(soi.subtotal_refund_amount || 0)+");' type='number'  name='amount' value='" + (soi.subtotal_price - (soi.subtotal_refund_amount || 0)) + "' class='refund-amount-input' /></td>" +
		"<td>" + doDecimal(soi.price) + "</td>" +
		"<td>" + doDecimal(soi.discount) + "</td>" +
		"<td>" + doDecimal(soi.sale_price) + "</td>" +
		"<td>" + doDecimal2(soi.qty) + "</td>" +
		"<td>" + (soi.employee_name || "") + "</td>"
		
	// +"</td><td>"
	// +
	// soi.subtotal_price
	+ "</tr>";

	// 载入表格
	$("#refund_order_items tbody").append(row_tr);
}

// 全选checkbox,用于退货12-20
//type:1按单退货,2按商品退货
function selectAll() {
	$("#refund_order_items input[name='soi_id']").prop('checked',$('#btnRefundSelectAll').text()=='全选');
	$('#btnRefundSelectAll').text($('#btnRefundSelectAll').text()=='全选'?'取消':'全选');
	resetRefundButton();
}

function resetRefundButton(){
	var len = $("#refund_order_items input[name='soi_id']:checked").length;
	// alert(len);
	if(len>0){
		$("#btnRefundItems").removeAttr("disabled");
	}
	else{
		$("#btnRefundItems").attr("disabled","disabled");
	}
		
}

// 校验退货数量,必须为负整数,且退货数量不大于可退数量.
function validateRefundQty(ths, saleQty, refundQty, salePrice) {
	$("#btnRefundItems").prop("disabled",true);
	$(ths).parents("tr").find("input[name='amount']").data("invalid",true);
	
	//checkbox 选中会解除退货按钮的disabled,checkbox也disabled
	var _checkbox = $(ths).parents("tr").find("input[name='soi_id']");
	_checkbox.prop("disabled",true);
	
	var val = $(ths).val();

	var reg = /^[1-9]\d*$/;//正整数
	var r2 = /^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$/; //正浮点数
	var invalidFlag = false;
	
	//服装版，退货数量必须是整数 MODIFY BY CPQ 20170206
	if (getSetting("Industry") == '1001' && !reg.test(val)) {
		alert("退货数量必须是正整数!");
		selectRefundQty(ths)
		return;
	}
	
	if ( !( reg.test(val) || r2.test(val) ) ){
		alert("退货数量必须是数字!");
		selectRefundQty(ths);
		return;
	}
	
	if (val > saleQty - refundQty) {
		alert("退货数量不能大于可退数量!");
		selectRefundQty(ths);
		return;
	}
	
	var invalid = $(ths).data("invalid") === undefined ? false : $(ths).data("invalid");
	var isCheck = _checkbox.prop("checked");
	
	//填数量时，自动计算金额
	$(ths).parents("tr").find("input[name='amount']").val(val*salePrice)
	
	$(ths).parents("tr").find("input[name='amount']").data("invalid",false);
	$("#btnRefundItems").prop("disabled",invalid || !isCheck);
	_checkbox.prop("disabled",invalid);
}

//校验退货金额
function validateRefundAmount(ths, subtotal, refundAmount) {
	$("#btnRefundItems").prop("disabled",true);
	$(ths).parents("tr").find("input[name='qty']").data("invalid",true);
	
	//checkbox 选中会解除退货按钮的disabled,checkbox也disabled
	var _checkbox = $(ths).parents("tr").find("input[name='soi_id']");
	_checkbox.prop("disabled",true);
	
	var val = $(ths).val();

	var r2 = /^\d+(\.\d{1,2})?$/; //正浮点数,最多2位小数
	var invalidFlag = false;
	
	if ( !r2.test(val) ){
		alert("退货金额必须是数字,且最多两位小数!");
		selectRefundQty(ths);
		return;
	}
	
	var invalid = $(ths).data("invalid") === undefined ? false : $(ths).data("invalid");
	var isCheck = _checkbox.prop("checked");
	
	$(ths).parents("tr").find("input[name='qty']").data("invalid",false);
	$("#btnRefundItems").prop("disabled",invalid || !isCheck);
	_checkbox.prop("disabled",invalid);
}

function selectRefundQty(ths){
	$(ths).css("border", "2px solid #ff0000");
	$(ths).focus();
	$(ths).select();
}

// 退货(将退货的明细插入购物车)
//falg:0 refund from local db,1 refund from server
function refundItems(flag) {
	console.log("--------------------- searchServerFlag ->"+flag);
	var refundCount = 0;
	var index = 0;
	
	//校验总的退货数量
	var totalRefundQty = 0;
	var totalRefundAmount = 0;
	var remainRefundQty = parseFloat($("#remain_refund_qty").val() || 0);
	var remainRefundAmount = parseFloat($("#remain_refund_amount").val() || 0);
	
	$("#refund_order_items input[name='soi_id']:checked").each(function() {
		var refundQty = $(this).closest("tr").find("input[name='qty']").val();
		var refundAmount = $(this).closest("tr").find("input[name='amount']").val();
		
		totalRefundQty += parseFloat(refundQty || 0);
		totalRefundAmount += parseFloat(refundAmount || 0);
	})
	
	if(totalRefundQty > remainRefundQty){
		message('总退货数量不能大于总可退数量.');
		return;
	}
	
	//refund from local db start
	if(flag==0){
		
		refundCount = $("#refund_order_items input[name='soi_id']:checked").length;
		console.log("--------------------- refund item count ->"+refundCount);
	
		// 取得原销售单要退货的明细
		$("#refund_order_items input[name='soi_id']:checked").each(function(i) {
			// 逐个插入购物车
			var soiId = $(this).val();// 原销售单的明细ID
			var refundQty = $(this).closest("tr").find("input[name='qty']").val();// 从本行取得退货数量
			var refundAmount = parseFloat($(this).closest("tr").find("input[name='amount']").val() || 0);//取得退货金额
			console.log("--------------------- refundQty ->"+refundQty);
			
			// 从原销售单明细中取得购物车所需要的各项属性值
			// 为什么不从商品资料表中获取呢,因为1，退款要退是当时的销售价格，2，商品资料可能更新过
			db.transaction(function(tx) {
				console.log("--------------------- saleorderitem id ->"+soiId);
				tx.executeSql("SELECT * FROM SALEORDERITEMS WHERE id = ? ORDER BY seq,id", [ soiId ], function(tx, results) {
					// alert(results.rows.length);
					if (results.rows.length > 0) {
						var soi = results.rows.item(0);
						
						addRefundItemToCart(tx,flag,i,soi,refundQty,refundAmount);
					}
				}, null);

			},function(err){
				console.log("### transaction 错误 -> "+err,err.code,err.message);
			},function(){
				refundItemsSuccess(flag);
			});
			
			console.log("--------------------- bottom line ---------------------");
			
		});
		
		console.log("##################### 分割线 #####################");
		
	}
	//refund from local db end
	
	
	//refund from local storage start(服务器端保存至LS)
	if(flag==1){
		
		refundCount = $("#refund_order_items input[name='soi_id']:checked").length;
		console.log("--------------------- refund item count ->"+refundCount);
		
		//var localStorage = window.localStorage;
		var result = JSON.parse(localStorage.getItem("refundJsonStr"));
		
		if(result&&result.sale_order_no){
			var itemJsonArr = result.items;
			//alert(itemJsonArr.length);
			
			//必须用forEach循环进行回调,用for循环的话,web sql事务总是重复插入最后一条退货,非常重要!!!,by fandy 2014-6-17
			itemJsonArr.forEach(function(soi){
				// 取得原销售单要退货的明细
				$("#refund_order_items input[name='soi_id']:checked").each(function(i) {
					
					// 逐个插入购物车
					//if ($(this).attr("checked")) {
					var soiId = $(this).val();// 原销售单的明细ID
					
					if(soi.id==soiId){
						var refundQty = $(this).closest("tr").find("input[name='qty']").val();//从本行取得 退货数量
						var refundAmount = parseFloat($(this).closest("tr").find("input[name='amount']").val() || 0);//取得退货金额
						//console.log("--------------------- saleorderitem id A ->"+soiId);
						
						// 插入到购物车中//6-16:存在问题,事务异步
						db.transaction(function(tx) {
							console.log("--------------------- saleorderitem id ->"+soiId);
							console.log("--------------------- product id ->"+soi.product_id);
							
							addRefundItemToCart(tx,flag,i,soi,refundQty,refundAmount);
						},function(err){
							console.log("### transaction 错误 -> "+err,err.code,err.message);
						},function(){
							refundItemsSuccess(flag);
						});
						console.log("--------------------- bottom line ---------------------");
						
					}
					//}
				
				});
			});
			
			console.log("##################### 分割线 #####################");
			
			//FOR循环存在问题,因web sql事务的因素,总是最后一条重复插入,6-17
			/*for ( var i = 0; i < itemJsonArr.length; i++) {// 迭代JSON数据
				//console.log(itemJsonArr[i]);
				var soi= itemJsonArr[i];
				//console.log(soi.product_name);				
				
				// 取得原销售单要退货的明细
				$("#refund_order_items input[name='soi_id']:checked").each(function() {
					
					// 逐个插入购物车
					//if ($(this).attr("checked")) {
					var soiId = $(this).val();// 原销售单的明细ID
					
					if(soi.id==soiId){						
						var refundQty = $(this).parent("td").parent("tr").find("input[name='qty']").val();// 退货数量
						console.log("----------------- saleorderitem id A ->"+soiId);
						// 插入到购物车中//6-16:存在问题,事务异步
						db.transaction(function(tx) {
							console.log("----------------- saleorderitem id B ->"+soiId);
							console.log("----------------- product id ->"+soi.product_id);
							tx.executeSql(
									'INSERT INTO SHOPPINGCARTS (outlet_id, product_id, product_name, barcode, size, unit, supply_price, price, wholesale_price, vip_price, discount, sale_price, qty, subtotal, point_enabled,point_rate,subtotal_points, refund_flag, update_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', 
									[outletId, soi.product_id, soi.product_name, soi.barcode, soi.size, soi.unit, soi.supply_price, soi.price, soi.wholesale_price, soi.vip_price, soi.discount, soi.sale_price, refundQty * -1, doDecimal(parseFloat(soi.sale_price * refundQty * -1)),soi.point_enabled, soi.point_rate, (soi.subtotal_points=='null'?0:soi.subtotal_points) , 1, parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S") ],
									function(){
										console.log("----------------- insert ok, index ->"+index);
										index++;
									},null
							);
						});
						console.log("----------------- index ->"+index);
						
					}
					//}
				
				});
				
				
			}*/
		}
		
		
	}
	//refund from local storage end
	
	//refund from table products @ local db start	
	if(flag==2){//没有用
		refundCount = $("#refund_product_items input[name='r_p_id']:checked").length;
		console.log("--------------------- refund item count ->"+refundCount);
		
		$("#refund_product_items input[name='r_p_id']:checked").each(function() {
			var pId = $(this).val();// 商品ID
			var refundQty = $(this).parent("td").parent("tr").find("input[name='qty']").val();// 退货数量
			
			//从商品表退货
			db.transaction(function(tx) {
				console.log("--------------------- product id ->"+pId);
				tx.executeSql("SELECT * FROM PRODUCTS WHERE company_id=? AND (outlet_id=?) AND product_id = ?", [companyId, outletId, pId], function(tx, results) {
					// alert(results.rows.length);
					if (results.rows.length > 0) {
						var product = results.rows.item(0);
						console.log("--------------------- product id ->"+product.product_id);
						
						
						
						//积分处理，7-16
						var pointEnabled = product.point_enabled;
						var pointRate = product.point_rate;
						
						if(pointEnabled==null || pointEnabled=='' || pointEnabled=='null')
							pointEnabled = 0;
						
						if(pointRate==null || pointRate=='' || pointRate=='null')
							pointRate = 0;
						
						var subtotalPoints = 0;
						if(pointEnabled==1){
							subtotalPoints = product.price*refundQty*product.point_rate;
						}
						
						
						//V2:提成
						var subtotalCommission = getCommission(product,refundQty,subtotal);
						
						// 插入到购物车中//update 20150514:退货加上分类\品牌\供应商,本地,FROM PRODUCT
						tx.executeSql(
								'INSERT INTO SHOPPINGCARTS (outlet_id, category_id , category_name, brand_id , brand_name, supplier_id , supplier_name, product_id, product_name, barcode, size, cust_props, unit, supply_price, price, wholesale_price, vip_price, discount_enabled, vip_discount_type, discount, sale_price, qty, subtotal, point_enabled,point_rate,subtotal_points, subtotal_commission refund_flag, update_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', 
								[outletId, product.category_id, product.category_name, product.brand_id, product.brand_name, product.supplier_id, product.supplier_name, product.product_id, product.product_name, product.barcode, product.size, unescape(product.cust_props), product.unit, product.supply_price, product.price, product.wholesale_price, product.vip_price, 0, 0, 100, product.price, refundQty * -1, parseFloat(product.price * refundQty * -1), pointEnabled, pointRate, subtotalPoints ,subtotalCommission*-1, 1, parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S") ],
							function(tx,rst){
									/*console.log("--------------------- insert ok, index/refundCount ->"+index+"/"+refundCount);
									if(index==refundCount-1){//最后一条执行完后,载入cart和处理其它
										loadCart();
									}
									index++;*/
								},	
								function(tx,err){console.log("从商品退货",err.message)});

					}
				}, null);

			},function(err){
				console.log("### transaction 错误 -> "+err,err.code,err.message);
			},function(){
				console.log("### 退货明细插入成功(从本地product退),transaction 事务结束 ###");
				loadCart();
			});
			
			console.log("--------------------- bottom line ---------------------");
			
		});
		
		console.log("##################### 分割线 #####################");
	}
	//refund from table products @ local db end

	// alert("退货个数->" + refundCount);
	if (refundCount > 0) {
		$('#refundModal').modal('hide');
	} else {
		alert("请选择要退货的商品,并输入退货数量!");
	}

}

//退货商品插入购物车完成 ADD BY CPQ
function refundItemsSuccess(flag){
	console.log("### 退货明细插入成功(从服务器端退),transaction 事务结束 ###");
	if(flag == 1){
		localStorage.removeItem("refundJsonStr");//移除退货LS
	}
	
	loadCart();
	
	//会员与导购员处理 开始
	var saleType = $("#customer_sale_type_4_refund").val();
	var customerCode = $("#customer_4_refund").val();
	if (customerCode) {
		initCustomerInfo(saleType, customerCode);
	}
	//会员与导购员处理 结束
	
	// 设置导购员默认选项
	var employeeId = $("#employee_id_4_refund").val();
	var employeeName = $("#employee_name_4_refund").val();
	if(employeeId){
		setEmployee(employeeId,employeeName,0,1);
	}
}

//退货商品插入购物车 ADD BY CPQ
function addRefundItemToCart(tx,flag,i,soi,refundQty,refundAmount){
	console.log("--------------------- product id ->"+soi.product_id);
	
	//积分处理，7-16
	var pointEnabled = soi.point_enabled;
	var pointRate = soi.point_rate;
	
	if(pointEnabled==null || pointEnabled=='' || pointEnabled=='null')
		pointEnabled = 0;
	
	if(pointRate==null || pointRate=='' || pointRate=='null')
		pointRate = 0;
	
	var subtotalPoints = 0;
	if(pointEnabled==1){
		subtotalPoints = soi.sale_price * refundQty * pointRate;
	}
	
	var productEmployeeId = soi.employee_id || 0;
	var productEmployeeName = soi.employee_name;
	
	$("#product_employee_id").val(productEmployeeId);
	$("#product_employee_name").val(productEmployeeName);
	
	//售价与折扣处理
	var subtotal = parseFloat(soi.subtotal_price || 0);
	var salePrice = soi.sale_price;
	var discount = soi.discount;
	
	if(refundAmount != subtotal){
		subtotal = refundAmount;
		salePrice = refundQty == 0 ? 0 : ((subtotal*100)/refundQty)/100;
		discount = soi.price == 0 ? 0 : ((salePrice*100)/soi.price)/100;
		discount *= 100;
	}
	
	//重新计算提成，退货数量不一定是销售数量
	var subtotalCommission = soi.subtotal_commission / soi.qty * refundQty;
	
	var relatedSeq = soi.seq || ( (i+1)*-1 );
	var errorMsg = flag == 1 ? "从服务器端退货(LS)" : "从客户端退货";
	
	tx.executeSql("UPDATE SHOPPINGCARTS SET sale_price=?,discount=?,qty=?,subtotal=? WHERE remark=? AND related_seq=?"
			,[parseFloat(doDecimal(salePrice)),parseFloat(doDecimal(discount)), refundQty * -1, parseFloat(doDecimal(subtotal*-1)), soi.sale_order_no, relatedSeq],
			function(tx,result){
				
				if(result.rowsAffected == 0){
					// 插入到购物车中//update 20150514:退货加上分类\品牌\供应商,本地
					tx.executeSql( 'INSERT INTO SHOPPINGCARTS (outlet_id, category_id , category_name, brand_id , brand_name, supplier_id , supplier_name, product_id, product_name, barcode, size, cust_props, unit, supply_price, price, wholesale_price, vip_price, discount_enabled, vip_discount_type,  discount, sale_price, qty, subtotal, point_enabled,point_rate,subtotal_points, subtotal_commission, refund_flag, update_date,employee_id,employee_name,related_seq,remark) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', 
							[outletId, soi.category_id, soi.category_name, soi.brand_id, soi.brand_name, soi.supplier_id, soi.supplier_name, soi.product_id, soi.product_name, soi.barcode, soi.size, soi.cust_props, soi.unit, soi.supply_price, soi.price, soi.wholesale_price, soi.vip_price, 0, 0, doDecimal(discount), doDecimal(salePrice), refundQty * -1, doDecimal(subtotal*-1), pointEnabled, pointRate, subtotalPoints , subtotalCommission*-1, 1, parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S") ,productEmployeeId,productEmployeeName,relatedSeq, soi.sale_order_no],
							null, function(tx,err){
								console.log(errorMsg,"插入购物车",err.message);
							})
				}
				
			},function(tx,error){
				console.log(errorMsg,"更新购物车",error.message);
			})
}


// 继续购买,//2014/12/25:不再使用
function backToSale() {
	$('#checkoutModal').modal('hide')
	// 清空之前的收银数据
	$("#c_cash").val("");
	$("#c_card").val("");
	$("#c_coupon").val("");
	$("#c_balance").val("");
	$("#c_change").val("");
	//$("#c_cashment").val("");
}

/**
 * 收银时自动计算找零
 * @param ths 
 * @param arguments[1] 0:现金改变时  1:结账时
 * @returns
 */
function change(ths) {
	var customerDisplayFlag = 0;
	if(1 < arguments.length) {
		customerDisplayFlag = arguments[1];
	}
	
	// 输入的必须是数字,可以考虑放结算那儿校验,因为放这儿输入小数点时,会弹出错误提示,12-21
	//var ths = $("#c_cash");
	var val = $(ths).val();
	
	if (val!='' && !isNumber(val)) {
		// alert("金额必须是数字!");
		//$(ths).css("border", "2px solid #ff0000");
		$(ths).parent().css({'border':'1px solid #ff0000','border-radius': '5px'});
		$(ths).focus();
		$(ths).select();
		$("#btnPay").attr("disabled", "disabled");
		return;
	} else {
		if (val=='') {
			//$(ths).val(0);
		}
		//$(ths).css("border", "");
		$(ths).parent().css("border", "");
		
		var cash = wrapVal($("#c_cash").val());
		var card = wrapVal($("#c_card").val());
		var coupon = wrapVal($("#c_coupon").val());
		var blance = wrapVal($("#c_balance").val());
		var alipay = wrapVal($("#c_alipay").val());
		var weixin = wrapVal($("#c_weixin").val());
		
		var pay = Number(cash) + Number(card) + Number(coupon) + Number(blance) + Number(alipay) + Number(weixin);
		var recv = wrapVal($("#recv").val());
		console.log("----------------- pay/recv@change()->  " + pay+"/"+recv);
		
		if(pay - recv > 0){
			$("#c_change").val(doDecimal(pay - recv));
			$("#btnPay").removeAttr("disabled");
		}
		else{
			$("#c_change").val(0)
		}
		
		if(0 == customerDisplayFlag) {
			customDisp(3,doDecimal(pay));
			setTimeout(customDisp,1000,4,doDecimal(pay - recv));
			savePayType();//修复某些情况下，双屏没有触发计算
		}
	}
}

//NULL或空转0
function wrapVal(val){
	return (val!=null && val!='')?val:0;
}

//用下一种付款方式自动补应收金额,只用于刷卡,未使用
function autoCalPay(ths){
	var recv = $("#recv").val();
	var cash = $("#c_cash").val();
	var card = $("#c_card").val();
	var coupon = $("#c_coupon").val();
	var blance = $("#c_balance").val();
	
	if($(ths).attr("id")=='c_pay')
		$("#c_card").val(recv-cash-coupon-blance);
	
}

// 改变付款方式,//2014-3-14更新,by fandy,//FANDY 2014/12/24更新:作废,改为平铺
function changePayment(val) {

	var objPay = $("#c_cash");
	var objChange = $("#c_change");

	if (val != 'CASH') {
		objPay.val(0);
		objChange.val(0);
		objPay.attr("readonly", "readonly");
	} else {
		objPay.val("");
		objChange.val("");
		objPay.removeAttr("readonly");
	}
	
	//组合收银,3-17
	var customerNo = $("#customer_no").val();
	if(val=="COMP"){
		$("#comp_div").show();
		if(customerNo){//如果是会员
			$("#comp_balance").show();
		}
	}
	else{
		$("#comp_div").hide();
		$("#comp_cash").val("");
		$("#comp_card").val("");
		$("#comp_coupon").val("");
		$("#comp_balance").hide();
		
		$("#comp_cash").css("border", "");
		$("#comp_card").css("border", "");
		$("#comp_coupon").css("border", "");
		$("#btnPay").removeAttr("disabled");
	}
}

//#########################################################
//################### 以下为modal的初始化 ###################
//#########################################################

//商品搜索modal初始化
function initSearchProductModal(){
	clearVal($('#kw'));
	
	$('#search_product_alert').removeAttr('class').hide();
	$('#search_product_alert').find('span:first').text('');
	
	$('#search_product_results_table tbody').empty();
	$('#search_product_results_table').hide();
}

//无码商品modal初始化
function initNoBarcodeModal(){
	$('#noBarcodeModal').find('input').each(function(){
		clearVal($(this));
		$(this).next().text("").removeAttr("style");
    	$(this).removeAttr("style");
	});
/*	$('#discount_enabled_4_nb').parent().removeAttr('class');//remove .checked */
	$('#discount_enabled_4_nb').prop("checked",false);
}


//会员搜索modal初始化
function initSearchCustomerModal(){
	clearVal($('#customer_kw'));
	
	$('#search_customer_alert').removeAttr('class').hide();
	$('#search_customer_alert').find('span:first').text('');
	
	$('#customer_search_results tbody').empty();
	$('#customer_search_results').hide();
}

//会员充值modal初始化,//2015-3-30:作废
function initDepositModal(){
	$('#customer_dettail_div').addClass('hide');
	$('#deposit_form_div').addClass('hide');
	
	$('#search_customer2_alert').removeAttr('class').hide();
	$('#search_customer2_alert').find('span:first').text('');
	
	//清空所有值和恢复CSS		
	$("#customer_kw_4_deposit").val('');
	$("#customer_kw_4_deposit").removeAttr("style");
	$("#customer_kw_4_deposit").attr("placeholder",'会员卡号');
	
	$('.spn_customer_code').text('');
	$('.spn_customer_phonenumber').text('');
	$('.spn_customer_name').text('');
	$('.spn_customer_balance').text('');
	$('#bookbalance').val('');
	$('#deposit').val('');
	$('#pay4deposit').val('');
	$('#remark4deposit').val('');
	
	$("#deposit").css("border", "");
	$("#deposit").next().text("").removeAttr("style");
	$("#pay4deposit").css("border", "");
	$("#pay4deposit").next().text("").removeAttr("style");
	$("#remark4deposit").css("border", "");
	$("#remark4deposit").next().text("").removeAttr("style");
	$("#btn_confirm_deposit").removeAttr("disabled");	
}


//清空FROM ELEMENT的值
function clearVal(obj){
	$(obj).val('');
}

//设置并显示错误信息
function setAlertMsg(obj,txt,classx){
	$(obj).removeAttr('class');
	$(obj).find('span:first').text(txt);
	$(obj).addClass(classx);
	$(obj).show();
}


// ################### 分割线 ###################

// 搜索产品,用于autocomplete
function searchProducts(q, callback) {
	// var productJsonStr = "";
	db.transaction(function(tx) {
		//过滤称重商品
		//修改SQL,使之取回的是条码不重复的前10条商品,并计算同码商品的数量及平均价格；MODIFY BY CPQ > 库存独立同步后,需要左连双表查询
		tx.executeSql(
				"SELECT p.*,count(p.barcode) as sameBarcodeNum,avg(p.price) as avg_price, s.qty as stock  FROM PRODUCTS p "
				+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
				+" WHERE p.company_id=? AND p.outlet_id=? AND p.active='ON' AND p.del_flag=0 AND p.scale_flag <> 1 "
				+" AND (p.barcode LIKE '%" + q.toUpperCase() + "%' OR p.item_no LIKE '%" + q + "%' OR p.product_name LIKE '%" + q + "%' OR p.pinyin_code LIKE '%" + q + "%') "
				//+" OR (barcode LIKE '%" + q + "' OR pinyin_code LIKE '%" + q + "') "
				+" GROUP BY p.barcode limit 10", [companyId, outletId], function(tx, results) {
			if (results.rows) {
				var pj = [];
				for ( var i = 0; i < results.rows.length; i++) {
					var row = results.rows.item(i);
					if(row.stock==null) row.stock =0;
					pj.push(row);
				}
				callback(pj);
			}

		}, null);
	});

}

// 搜索产品
function search(q) {
	var alertObj = $('#search_product_alert');
	
	if(!q){
		//setAlertMsg(alertObj,"请输入搜索关键字!","alert alert-danger");
		message("请输入搜索关键字!");
		return;
	}
	
	// 首先清空原来的结果
	$("#search_product_results_table tbody").empty();
	// 搜索web sql
	// alert(q);
	//分页查询 MODIFY BY CPQ
	var pageSize = parseInt($("#pageSize").val());
	var currentPage = parseInt($("#currentPage").val()) - 1;//从0开始计数
	var start = pageSize * currentPage;
	//v21.:库存独立同步
	var sql = " FROM PRODUCTS p "
		+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
		+" WHERE p.company_id=? AND p.outlet_id=?  AND  p.del_flag=0 "
		+" AND (p.product_name LIKE '%" + q + "%' OR p.barcode LIKE '%" + q.toUpperCase() + "%' OR p.pinyin_code LIKE '%" + q + "%' OR p.item_no LIKE '%" + q + "%') ";
	
	
	db.transaction(function(tx) {
		tx.executeSql("SELECT COUNT(*) as item_count " + sql, [companyId, outletId],function(count_tx,count_results){
			var _count = (count_results.rows[0] || count_results.rows.item(0)).item_count;
			var pageCount = _count % pageSize != 0 ? Math.floor(_count / pageSize) + 1 : _count / pageSize;
			
			$("#page_count").text(pageCount);
			$("#_count").text(_count);
			
			if(pageCount == 1){//只有一页时，不能翻页
				$("#first_arrow,#pre_arrow").attr("class","btn btn-default disabled");
				$("#last_arrow,#next_arrow").attr("class","btn btn-default disabled");
			}
			
			tx.executeSql("SELECT p.*, s.qty as stock " + sql + "limit ?,?", [companyId, outletId,start,pageSize], function(tx, results) {
				var len = results.rows.length;
				
				if(len==0){
					//setAlertMsg(alertObj,"没有匹配的商品!","alert alert-danger");
					message("没有匹配的商品!");
					return;
				}	

				if (results.rows.length > 0) {
					
					$("#search_product_results_table").show();
					// 搜索结果装到表格里
					for ( var i = 0; i < results.rows.length; i++) {
						var p = results.rows.item(i);
						if(p.stock==null) p.stock = 0;
						
						var custProps = custPropFormatted(p.cust_props, false);
						// 添加表体
						var nowFontClass = JSON.parse(localStorage.getItem("theme"))? JSON.parse(localStorage.getItem("theme")).themeFontSize : "font-default"
						var gpLabelNumStyle = {
							"font-big":"4em",
							"font-default":"6em",
							"font-small":"7em"
						}
						var row_tr = "<tr>";
						if(0 >= $('#lbl_temp').parents('div.form-group:hidden').length) {
							row_tr += "<td style='text-align:center;'><label class='md-check'>"
								+ "<input type='checkbox' class='gp_p_id' value='"+p.product_id+"'><i class='indigo'></i></label></td>"
								+ "<td><div class='form-inline' style='text-align:center;'>"
								+ "<input type='number' min='0' name='gpLabelNum' class='form-control' value='"+(p.stock <= 0 ? 1 : p.stock)+"' style='max-width:"+gpLabelNumStyle[nowFontClass] + "' />"
								+ "</div></td>";
						}
						row_tr += "<td>" + (i + 1) + "</td><td>" + p.product_name + "</td><td>" + p.barcode + "</td><td>" + custProps + "</td><td>" + p.unit 
						+ "</td><td><span class='pull-right ellipsis-1'>" 
						+ p.stock 
						+ " <span class='fa fa-plus text-primary needonline' onclick='viewAllStocks(\""+p.barcode+"\");'></span>"
						+ "</span></td><td><span class='pull-right'>" + doDecimal(p.price) + "</span></td>";
						row_tr += "</tr>";

						$("#search_product_results_table tbody").append(row_tr);

						// $("#search_product_results_div").css("display","block");
					}
				}

			}, function(error){
				console.log(error);
			});
		},null);
	});
}






//搜索单个会员,用于收银台充值,20150122//2015-3030：暂时不再使用
function findCustomer4Deposit(ths) {
	//$('#deposit_form_div').addClass('hide');
	var alertObj = $('#search_customer2_alert');
	
	var customerCode = $(ths).val();
	if(customerCode==''){
		//$(ths).attr("placeholder",'会员卡号不能为空!');
		$(ths).focus();
		setAlertMsg(alertObj,"会员卡号不能为空!","alert alert-danger");
		return;
	}
	
	
	// 为什么不搜索web sql,因为本地不可靠	
	//返回JSON
	$.get(apiurl+"getCustomerJson",{no:customerCode}, function(result){
		//alert(result);
		var customer = result;
		//console.log("------------------ id / code / name ->"+customer.id +"/"customer.customer_code+"/"+customer.customer_name);
		    
		if(customer.id==undefined){//不存在   	
			setAlertMsg(alertObj,'会员('+customerCode+')不存在!',"alert alert-danger");
			$(ths).focus().select();
			$("#customer_dettail_div").addClass('hide');
			$('#deposit_form_div').addClass('hide');
			return;
	    }
	    else{//存在
	    	$("#customer_dettail_div").removeClass('hide');
	    	$('#deposit_form_div').removeClass('hide');
	    	
	    	$(alertObj).hide();
	    	
	    	$('.spn_customer_code').text(customer.customer_code);
	    	$('.spn_customer_phonenumber').text(customer.customer_phonenumber);
	    	$('.spn_customer_name').text(customer.customer_name);
	    	$('.spn_customer_balance').text(doDecimal(customer.customer_balance));
	    	$('#bookbalance').val(customer.customer_balance);
	    	$('#customer_id_4_deposit').val(customer.id);
	    	
	    	initDepositFrom();
	    	$('#deposit').select();
	    }
	},
	'json'
	);
	
}




//V2:提成
//提成规则来自product,与数量或小计金额有关
function getCommission(product,qty,subtotal){
	var subtotalCommission = 0;
	//有导购员,才有提成,否则返回0
	//var empExsit = typeof($("#employee_id").val())!='undefined'&&$("#employee_id").val()!=null&&$("#employee_id").val()!=''; 
	if(product.commission_type!=null && product.commission_type>0){//1表示使用提成金额,2,6表示使用提成率
		//subtotalCommission = product.commission_type==1?parseFloat(product.commission_amount)*qty:subtotal*product.commission_rate/100;
		switch(product.commission_type){
		case 1:
			subtotalCommission = parseFloat(product.commission_amount)*qty;
			break;
		case 2:
		case 6:
			subtotalCommission = subtotal*product.commission_rate/100;
			break;
		}
	}
	return subtotalCommission;
}



//#############################################
// ################### 分割线 ###################
// #############################################



$(function() {
	//add by JIM 201510 遮罩
	//maskWait();
	if(browser.versions.mobileIos){
		//ipad客户端下使用tinyAutocomplete
		$("#bar_code").tinyAutocomplete({
			minChars : 2,
			itemTemplate:'<li class="autocomplete-item">{{label}}</li>',
			maxItems: 10,
			showNoResults: true,
			noResultsTemplate: '<li class="autocomplete-item">没有匹配的商品 </li>',
			searchLocalDb :searchProducts,
			makeData:makeProductsAutocompletedata,
			onSelect : function(event, result) {
				$("#selected_product_id").val(result.id);
				if(window.event.keyCode != 13){
					showProductsPre(result.have_cust_prop,result.value,result.id);
				}
			}
		});
	}else{
		$("#bar_code").autocomplete({
			source : function(request, response) {
				var q = request.term;
				// alert(q);
				searchProducts(q, function(result) {
					// 处理response
					response(makeProductsAutocompletedata(result));
				});
			},
			minLength : 2,
			select : function(event, result) {
				$("#selected_product_id").val(result.item.id);
				if(window.event.keyCode != 13){
					showProductsPre(result.item.have_cust_prop,result.item.value,result.item.id);
				}
			}
		});
	}
});

function makeProductsAutocompletedata(result){
	return $.map(result, function(item, i) {
		var custProps = custPropFormatted(item.cust_props, true);
		//MODIFY BY CPQ 自动搜索结果同码整合
		var _label =  item.barcode + " [" + item.product_name + custProps + ", " + " ￥" + item.price + ", " + item.stock + item.unit +"]";
		var sameBarcodeNum = item.sameBarcodeNum;
		if(sameBarcodeNum > 1){
			_label = item.barcode + " [" + item.product_name + "] x " +sameBarcodeNum+ "(个同码商品)";
		}
		return {
			label :_label,
			value : item.barcode,
			id : item.product_id,
			have_cust_prop : item.have_cust_prop//ADD BY CPQ
			,price : item.price
		}
	})
}


//改变价格类型,1-3
//0:零售价,1：批发价,2:会员价
function switchPriceType(priceType) {
	//再次取得批发模式是否启用
	var wholesaleEnabled = getSetting("wholesale_enabled");
	if(wholesaleEnabled== 0){
		alert("批发模式未启用,无法批发销售!");
		return;
	}
	
	
	var priceTypeDesc = priceType==0?'零售':'批发';
	
	confirm("切换到"+ priceTypeDesc +"模式，并同时清空销售单?",function(cfm){
		if(cfm){
			
			setPriceType(priceType);//设置销售模式:0为零售,1为批发
			
			//******** 切换时，清空购物车 *******
			clearCart();
			return;
			//以下不执行
			//******** 切换时，清空购物车 *******
			

			// 更新购物车(如果有明细项存在),1-4
			db.transaction(function(tx) {
				tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE outlet_id = ? AND refund_flag=0", [outletId], function(tx, results) {
				//V2:增加提成
				//tx.executeSql("SELECT cart.*,p.commission_type,p.commission_rate,p.commission_amount FROM SHOPPINGCARTS cart , PRODUCTS p WHERE cart.product_id=p.product_id AND cart.outlet_id = ? AND cart.refund_flag=0", [outletId], function(tx, results) {
					console.log("切换价格模式",results.rows.length);
					if (results.rows.length > 0) {// 购物车中存在商品

						var len = results.rows.length, i;
						
						// update discount & sale price start
						for (i = 0; i < len; i++) {

							var cartItem = results.rows.item(i);
							//V2:创建prouct对象,设置提成规则
							var product = new Object();
							product.commission_type = cartItem.commission_type;
							product.commission_rate = cartItem.commission_rate;
							product.commission_amount = cartItem.commission_amount;

							// 处理售价与折扣,与价格类型有关,1-3
							var id = cartItem.id;
							var discount = 0;
							var salePrice = 0;
							var subtotal = 0;
							var qty = cartItem.qty;
							
							// 零售价 start
							if (priceType == 0) {// 零售价
								salePrice = cartItem.price;
								discount = 100;
								
								console.log("--------------------- 是否参与打折 @switchPriceType()-> " + cartItem.product_id + "/" + cartItem.discount_enabled);
								
								
								if(cartItem.discount_enabled==1){
									//传入的基础价格与基础折扣为初始的
									cartItem.sale_price = cartItem.price;
									cartItem.discount = 100;
									
									//调用 wrapCart更新item start
									wrapCartItem(cartItem, tx, function(resultx){
										console.log("### 批发>零售 - 打折商品 ");
									});	
									//调用 wrapCart更新item end
									
									
								}
								else{//不参与打折的商品,切换回零售时,恢复标价销售
									salePrice = cartItem.price;
									discount = 100;//FIXME:无码商品可能折扣不是100
									
									subtotal = salePrice * cartItem.qty;
									
									var subtotalPoints = 0;
									if(cartItem.point_enabled==1){
										subtotalPoints = subtotal*cartItem.point_rate;
									}
									
									// console.log("----------- 更新第"+i+"行 开始");
									tx.executeSql("UPDATE SHOPPINGCARTS SET sale_price = ?, discount = ?, subtotal=?, subtotal_points = ?   WHERE refund_flag=0 AND id = ?", 
											[ parseFloat(doDecimal(salePrice)), discount, parseFloat(doDecimal(subtotal)), parseFloat(doDecimal(subtotalPoints)) , id ], function(tx, r) {
										// successfully
									}, null);
									 //console.log("----------- 更新第"+i+"行 结束");
								}
								
							}
							// 零售价 end
							
							// 批发价 start
							if (priceType == 1) {// 批发价
								salePrice = cartItem.wholesale_price;
								discount = Math.round(cartItem.wholesale_price / cartItem.price * 100);
								
								subtotal = salePrice * cartItem.qty;
								
								var subtotalPoints = 0;
								if(cartItem.point_enabled==1){
									subtotalPoints = subtotal*cartItem.point_rate;
								}
								
								// console.log("----------- 更新第"+i+"行 开始");
								tx.executeSql("UPDATE SHOPPINGCARTS SET sale_price = ?, discount = ?, subtotal=?, subtotal_points = ?   WHERE refund_flag=0 AND id = ?", 
										[ parseFloat(doDecimal(salePrice)), discount, parseFloat(doDecimal(subtotal)), parseFloat(doDecimal(subtotalPoints)) , id ], function(tx, r) {
									// successfully
								}, null);
								 //console.log("----------- 更新第"+i+"行 结束");
								
							}
							// 批发价 end
											
							
						}
						// update discount & sale price end
						
					}

				}, function(tx,err){console.log("切换价格模式",err.message)});
			},null,function(){
		 		//事务结束后，调用载入购物车
		 		loadCart();
		 	});
			
			
		}
	});
	//confirm
}

//查看换班结算统计,3-17
// 20170414：delete by dph
// 方法移至settle-print.js
/*function viewSettlement() {
	//V2:交班时不能存在未完成的交易
	if ($("#cart tbody").children("tr").length> 0) {
		alert("还有未完成的交易，无法交班!");
		return;
	}
	//MODIFY BY CPQ
	db.transaction(function(tx){
		tx.executeSql("SELECT * FROM USERLOGS WHERE company_id=? AND outlet_id=?" +
				" AND user_id=? AND logout_time IS NULL ORDER BY id",
				[companyId,outletId,parseInt($("#auth_id").val())],
		function(tx,results){
			if(results.rows.length > 0){
				//按ID升序，第0个是第一次登陆的记录
				var userlogs = results.rows.item(0);
				var login_time = userlogs.login_time;
				//从服务器取得当前时间
				var servertime = new Date().Format("yyyy-MM-dd hh:mm:ss");
				
				$("#sale_time_range .sTime").text(login_time);
				$("#sale_time_range .eTime").text(servertime);
				$("#cashier").text($("#auth_username").val());
				
				tx.executeSql("SELECT * FROM PAYRECORDS WHERE company_id=? AND outlet_id=?" +
						" AND cashier_id=? AND settle_status=0 AND create_date BETWEEN ? AND ?",
						[companyId,outletId,$("#auth_id").val(),login_time,servertime],
				function(tx,results){
					if(results.rows.length > 0){
						var sale_no = [];//销售笔数
						var refund_no = [];//退货笔数
						
						var total_cash = 0;//总现金
						
						var total_sale_amount = 0;//销售额
						var total_refund_amount = 0;//退款金额
						
						var total_charge = 0;//会员充值金额
						var time_card_total_charge = 0;//次卡充值金额
						var normal_card_total_charge = 0;//普通卡充值金额
						var total_gift = 0;//会员赠送金额
						var time_card_total_gift = 0;//次卡赠送金额
						var normal_card_total_gift = 0;//普通卡赠送金额
						
						var totalSaleObj = {"CASH":0,"CARD":0,"COUPON":0,"BALANCE":0,"ALIPAY":0,"WEIXIN":0};
						var totalCustomObj = {"CASH":0,"CARD":0,"ALIPAY":0,"WEIXIN":0,"COUPON":0};
						
						for(var i=0; i<results.rows.length; i++){
							var payrecord = results.rows.item(i);
							var sale_order_no = payrecord.sale_order_no;
							var amount = parseFloat(payrecord.amount);
							var pr_type = payrecord.record_type;
							var payment = payrecord.payment;
							
							if(payment == "CASH"){
								total_cash += amount;
							}
							if(amount < 0){
								//计算退货笔数
								if(sale_order_no && refund_no.indexOf("'"+sale_order_no+"'") == -1){
									refund_no.push("'"+sale_order_no+"'");
								}
								//退货金额
								total_refund_amount += (amount * -1);
							}
							switch(pr_type){
								case 0:
								case 1://次卡消费，也是销售
									//计算销售笔数
									if(sale_order_no && sale_no.indexOf("'"+sale_order_no+"'") == -1){
										sale_no.push("'"+sale_order_no+"'");
									}
									//销售额 = 销售-退货，退货的amount为负；实际结果是销售额=销售+退货
									total_sale_amount += amount;
									//付款明细 微信和支付宝的二种付款方式合在一起算
									if(payment == "WEIXIN_1"){
										totalSaleObj["WEIXIN"] += amount;
									}else if(payment == "ALIPAY_1"){
										totalSaleObj["ALIPAY"] += amount;
									}else{
										totalSaleObj[payment] += amount;
									}
									break;
								case 10:
									normal_card_total_charge += amount;
								case 100:
									if(pr_type == 100){
										time_card_total_charge += amount;
									}
									//会员充值总额
									total_charge += amount;
									//充值明细 微信和支付宝的二种付款方式合在一起算
									if(payment == "WEIXIN_1"){
										totalCustomObj["WEIXIN"] += amount;
									}else if(payment == "ALIPAY_1"){
										totalCustomObj["ALIPAY"] += amount;
									}else{
										totalCustomObj[payment] += amount;
									}
									break;
								case 11:
									normal_card_total_gift += amount;
								case 101:
									if(pr_type == 100){
										time_card_total_gift += amount;
									}
									//总赠送金额
									total_gift += amount;
									break;
								}
						}
						
						$("#total_cash").text(total_cash.toFixed(2));
						//取得销售额
						var saleOrderNo = sale_no.concat(refund_no);
						if(saleOrderNo.length > 0){
							tx.executeSql("SELECT SUM(total_amount) as total_amount FROM SALEORDERS WHERE company_id=? AND outlet_id=?" +
									" AND user_id=? AND sale_order_no in ("+saleOrderNo.join(",")+")",[companyId,outletId,$("#auth_id").val()],
							function(tx,results){
								if(results.rows.length > 0){
									$("#total_sale_amount").text(results.rows.item(0).total_amount.toFixed(2));
								}
							})
						}
						
						$("#sell_total_amount").text(total_sale_amount.toFixed(2));
						$("#total_sale_num").text(sale_no.length);
						
						$("#settle_payment").empty();
						for(var k in totalSaleObj){
							var cloneObj = $("#payment_copy_resource").children().clone(true);
							cloneObj.find(".payment").text(PAYMENT_ARRAY[k]);
							cloneObj.find(".amount").text(totalSaleObj[k].toFixed(2));
							$("#settle_payment").append(cloneObj);
						}
						$("#settle_custom_payment").empty();
						for(var k in totalCustomObj){
							var cloneObj = $("#payment_copy_resource").children().clone(true);
							cloneObj.find(".payment").text(PAYMENT_ARRAY[k]+"(充值)");
							cloneObj.find(".amount").text(totalCustomObj[k].toFixed(2));
							$("#settle_custom_payment").append(cloneObj);
						}
						
						$("#return_num").text(refund_no.length);
						$("#return_amount").text(total_refund_amount.toFixed(2));
						
						$("#total_charge").text(total_charge.toFixed(2));
						$("#settle_normal_card_total_charge").text(normal_card_total_charge.toFixed(2));
						$("#settle_time_card_total_charge").text(time_card_total_charge.toFixed(2));
						$("#total_gift").text(total_gift.toFixed(2));
						$("#settle_normal_card_total_gift").text(normal_card_total_gift.toFixed(2));
						$("#settle_time_card_total_gift").text(time_card_total_gift.toFixed(2))
						
						$("#sell_pay_record").val(JSON.stringify(totalSaleObj));
						$("#deposit_pay_record").val(JSON.stringify(totalCustomObj));
					}
					$('#settleModal').modal('show');
					$("#todaySaleReportDialog").addClass("hidden");
					$("#sellteDialog").removeClass("hidden");
				});
			}else{
				confirm("没有找到未换班的登录日志,无法换班，直接退出?",function(ans){
					if(ans){
						logout();
					}
				});
			}
		},function(tx,error){
			console.log(error.message);
			confirm("查找未换班的登录日志时出错,无法换班，直接退出?",function(ans){
				if(ans){
					logout();
				}
			});
		})
	})
}*/

// 换班结算//update 3-17
function settle(_this) {
//	confirm("确定换班结算?",function(c){
//		if (c) {}
//	});
	//MODIFY BY CPQ
	var shift_no = ((new Date()).valueOf()).toString()+getRandomNumber(10001,99999);//时间戳+5位随机数
	var now = parseDate(new Date(), "yyyy/MM/dd hh:mm:ss");
	
	var start_time = $("#sale_time_range .sTime").data("full_time");
	var end_time = $("#sale_time_range .eTime").data("full_time");
	
	var user_id = parseInt($("#auth_id").val());
	var username = $("#auth_username").val();
	var name = $("#auth_name").val();
	
	var total_cash =$("#total_cash").text();
	var sale_amount = $("#total_sale_amount").text();
	var sell_pay_record = $("#sell_pay_record").val();
	
	var deposit_amount = $("#total_charge").text();
	var gift_amount = $("#total_gift").val() || 0;
	var deposit_pay_record = $("#deposit_pay_record").val();
	
	//非营业现金收支 ADD BY CPQ
	var roe_cash = $("#roe_cash").val();
	var pretty_cash = $("#pretty_cash").val();
	
	var sendObj = {"shift_no":shift_no,"start_time":start_time,"end_time":end_time,
			"total_cash":total_cash,"sale_amount":sale_amount,"sell_pay_record":sell_pay_record,
			"deposit_amount":deposit_amount,"gift_amount":gift_amount,"deposit_pay_record":deposit_pay_record,
			"roe_cash":roe_cash,"pretty_cash":pretty_cash};
	
	$(_this).prop("disabled",true);//防止重复交班
	
	var flag = false;
	var shiftRecordInsertId = 0;
	var existsPrId = [];
	db.transaction(function(tx){
		//更新交班记录，在线时提交到服务端更新，离线时更新本地DB
		//放在这里是为了保证在Logout之前可以完成以下动作；
		if(online){
			$.ajax({async:false,
				url:apiurl+"saveShiftRecord",
				type:"POST",
				data:sendObj,
				success:function(result){
					if(result != '' && /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(result)){
						//使用服务器返回的时间，保证三张表的create_date或update_date一致
						now = result;
						flag = true;
					}
				}
			});
		}
		
		//if(!online || !flag){
			tx.executeSql("INSERT INTO SHIFTRECORDS(company_id,outlet_id,shift_no,start_time,end_time,user_id," +
					"username,name,total_cash,sale_amount,sell_pay_record,deposit_amount,gift_amount," +
					"deposit_pay_record,create_date,roe_cash,pretty_cash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
					[companyId,outletId,shift_no,start_time,end_time,user_id,username,name,total_cash,sale_amount,
					 sell_pay_record,deposit_amount,gift_amount,deposit_pay_record,now,roe_cash,pretty_cash],
					 function(tx,result){shiftRecordInsertId = result.insertId;},
					 function(tx,error){console.log("SHIFTRECORDS"+error.message)});
		//}
		
		
		//更新登录日志
		tx.executeSql("UPDATE USERLOGS SET logout_time=?,shift_no=?,shift_flag=1,update_date=?" +
				" WHERE company_id=? AND outlet_id=? AND user_id=? AND logout_time IS NULL",
				[now,shift_no,now,companyId,outletId,user_id],null,function(tx,error){console.log("USERLOGS"+error.message)});
		
		//取得已在new_elem中的PR ID;
		tx.executeSql("SELECT * FROM new_elem WHERE table_name='payrecords'",null,function(tx,result){
			for(var i=0; i<result.rows.length; i++){
				var item = result.rows[i] || result.rows.item(i);
				var id = item.id;
				if(existsPrId.indexOf(id) == -1){
					existsPrId.push[item.id];
				}
			}
		})
		
		//更新PR
		tx.executeSql("UPDATE PAYRECORDS SET settle_status=1,shift_flag=1,shift_time=? WHERE company_id=? AND outlet_id=?" +
				" AND cashier_id=? AND settle_status=0 AND create_date BETWEEN ? AND ?",
				[now,companyId,outletId,user_id,start_time,end_time],function(tx,result){
			if(result){}
		},function(tx,error){console.log("PAYRECORDS"+error.message)});
	},function(){
		$(_this).prop("disabled",false);
	},function(){
		/*
		 * 已经直接添加到服务端的数据库，无需再同步,
		 * 删除 new_elem中的对应记录，
		 * 在插入 SHIFTRECORDS 的成功回调中,
		 * new_elem 尚未插入数据,所以要这边删除
		 * BY CPQ
		 */
		if(flag){
			db.transaction(function(tx){
				tx.executeSql(" DELETE FROM new_elem WHERE table_name='shiftrecords' AND id=?",[shiftRecordInsertId+""]);
				//existsPrId 中是交班update payrecords 前已经存在的new_elem，不能删除；
				//不在existsPrId的是交班update payrecords后生成的new_elem，应该删除;
				//new_elem 中 重复的记录，同步到后台并不会重复;
				//BY CPQ 20170915
				var prPart = "";
				if(existsPrId.length > 0){
					prPart = " AND id not in ("+existsPrId.join(",")+")";
				}
				tx.executeSql(" DELETE FROM new_elem WHERE table_name='payrecords'" + prPart,[]);
			},null,function(){
				//交班完成，退出系统
				logout();
			})
		}else{
			//交班完成，退出系统
			logout();
		}
	})
}

//查看今日销售统计
function viewTodaySaleReport(){

	//MODIFY BY CPQ
	db.transaction(function(tx){
		$("#todaySaleReport_cashier").text($("#auth_username").val());
		var now = parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S");
		//今日零点
		var todayZero = parseDate(new Date(), "yyyy/MM/dd") + " 00:00:00";
		//var todayZero = "2016-04-18" + " 00:00:00";
		tx.executeSql("SELECT * FROM PAYRECORDS WHERE company_id=? AND outlet_id=?" +
				" AND cashier_id=? AND create_date BETWEEN ? AND ?",
				[companyId,outletId,$("#auth_id").val(),todayZero,now],
		function(tx,results){
			if(results.rows.length > 0){
				var sale_no = [];//销售笔数（包括退货）
				
				var total_cash = 0;//总现金
				
				var total_sale_amount = 0;//销售额
				var total_refund_amount = 0;//退款金额
				
				var total_charge = 0;//会员充值金额
				var total_gift = 0;//会员赠送金额
				
				var totalSaleObj = {"CASH":0,"CARD":0,"COUPON":0,"BALANCE":0,"ALIPAY":0,"WEIXIN":0};
				
				for(var i=0; i<results.rows.length; i++){
					var payrecord = results.rows.item(i);
					var sale_order_no = payrecord.sale_order_no;
					var amount = parseFloat(payrecord.amount);
					var pr_type = payrecord.record_type;
					var payment = payrecord.payment;
					
					if(payment == "CASH"){
						total_cash += amount;
					}
					
					switch(pr_type){
					case 0:
					case 1:
						//计算销售笔数
						if(sale_order_no && sale_no.indexOf("'"+sale_order_no+"'") == -1){
							sale_no.push("'"+sale_order_no+"'");
						}
						//销售额 = 销售-退货，退货的amount为负；实际结果是销售额=销售+退货
						total_sale_amount += amount;
						//付款明细 微信和支付宝的二种付款方式合在一起算
						if(payment == "WEIXIN_1"){
							totalSaleObj["WEIXIN"] += amount;
						}else if(payment == "ALIPAY_1"){
							totalSaleObj["ALIPAY"] += amount;
						}else{
							totalSaleObj[payment] += amount;
						}
						break;
					case 10:
						//会员充值总额
						total_charge += amount;
						break;
					case 11:
						//总赠送金额
						total_gift += amount;
						break;
					}
				}
				//取得销售额
				if(sale_no.length > 0){
					tx.executeSql("SELECT SUM(total_amount) as total_amount FROM SALEORDERS WHERE company_id=? AND outlet_id=?" +
							" AND user_id=? AND sale_order_no in ("+sale_no.join(",")+")",[companyId,outletId,$("#auth_id").val()],
					function(tx,results){
						if(results.rows.length > 0){
							$("#todaySaleReport_total_sale_amount").text(results.rows.item(0).total_amount.toFixed(2));
						}
					})
				}
				$("#todaySaleReport_total_cash").text(total_cash.toFixed(2));
				$("#todaySaleReport_total_sale_num").text(sale_no.length);
				
				$("#todaySaleReport_sale_detail").empty();
				for(var k in totalSaleObj){
					var cloneObj = $("#todaySaleReport_payment_copy_resource").children().clone(true);
					cloneObj.find(".payment").text(PAYMENT_ARRAY[k]+"收银：");
					cloneObj.find(".amount").text(totalSaleObj[k].toFixed(2));
					$("#todaySaleReport_sale_detail").append(cloneObj);
				}
				var cloneObj = $("#todaySaleReport_payment_copy_resource").children().clone(true);
				cloneObj.find(".payment").text("合计收银：");
				cloneObj.find(".amount").parent().addClass('text-danger');
				cloneObj.find(".amount").text(total_sale_amount.toFixed(2));
				$("#todaySaleReport_sale_detail").append(cloneObj);
				
				//占位，使销售和会员分开
				cloneObj = $("#todaySaleReport_payment_copy_resource").children().clone(true);
				cloneObj.empty().outerHeight(20);
				$("#todaySaleReport_sale_detail").append(cloneObj);
				
				cloneObj = $("#todaySaleReport_payment_copy_resource").children().clone(true);
				cloneObj.find(".payment").text("会员充值金额：");
				cloneObj.find(".amount").text(total_charge.toFixed(2));
				$("#todaySaleReport_sale_detail").append(cloneObj);
				
				cloneObj = $("#todaySaleReport_payment_copy_resource").children().clone(true);
				cloneObj.find(".payment").text("会员赠送金额：");
				cloneObj.find(".amount").text(total_gift.toFixed(2));
				$("#todaySaleReport_sale_detail").append(cloneObj);
				
			}
			$("#todaySaleReportDialog").removeClass("hidden");
			$("#sellteDialog").addClass("hidden");
		});
	})

}



//初始化导购员,//2015-10-26:select>table row,by fandy
//productEmpFlag 是否单品导购 0,1(取单时的整单导购) 否; 2 是 by CPQ
//单品导购时传入employeeId
function initEmployees(employeeId,cartId,productEmpFlag){
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM EMPLOYEES WHERE company_id=? AND (outlet_id=? OR shared=1) AND enabled=1 AND del_flag=0  ORDER BY employee_code ", [companyId, outletId], function(tx, results) {
			var len = results.rows.length, i;
			console.log("--------------- 初始化导购员列表 , len-> " +len);
			
			if(len>0){
				$("#employee-list").empty();
				
				for (i = 0; i < len; i++) {
					var item = results.rows.item(i);
					//console.log("---------------------" + item.employee_id + " = " + item.employee_name);		

					var elem = '<a data-employee_code="'+item.employee_code+'" data-employee_name="'+item.employee_name+'" class=" col-xs-4 employee_selector m-v-sm show" onclick="setEmployee('+item.employee_id+',\''+item.employee_name+'\','+cartId+','+productEmpFlag+');">'
					+'<label class="btn btn-primary text-ellipsis w-full" style="padding-left:0px;"><input type="radio"  value="'+item.employee_id+'" name="r_employee_id" style="opacity:0;"><i></i>'
					+'<input type="hidden"  value="'+item.employee_name+'" name="r_employee_name" />'
					+item.employee_name+' [ '+item.employee_code+' ]'
					+'</label></a>';
					$("#employee-list").append(elem);
					
					/*var tr = '<tr onclick="setEmployee('+item.employee_id+',\''+item.employee_name+'\');"><td style="padding:8px 8px 0 8px;">'+item.employee_name+'</td><td style="padding:0 8px;">'
						+'<div class="radio radio-primary pull-right" >'
							+'<input type="radio"  value="'+item.employee_id+'" name="r_employee_id" />'
						+'<label></label></div>'
						
						+'</td></tr>';
					//console.log("--------------------- 导购员行"+tr);
					$("#employee_table tbody").append(tr);*/
					
					//在最后一个设置默认导购员
			        //整单导购时设置，ADD BY CPQ
					if(i == len-1 && productEmpFlag != 2){
						setDefaultEmployee();
					}else{
						$("input[name=r_employee_id]").each(function(){//迭代每个radio
					        if($(this).val()==employeeId){ 
					        	$(this).prop("checked",true).parents(".btn").addClass("active").parents("a").addClass("checked"); //设置导购员默认选项
								$(this).next("i").addClass("glyphicon glyphicon-ok");
								//给主页按钮赋值
								$(".guide_name").html(item.employee_name)
								$(".guide_id").html(item.employee_code).show()
								// 修改按钮颜色
								$("#guideBtn").removeClass("btn-primary").addClass("bg-primary")
					        }
					    });
					}
				}
				//$("#employee_table").show();
				
				if(productEmpFlag != 2){
					$("input[type=radio][name='r_employee_id'][value='"+employeeId+"']").prop("checked",true);
				}
				//console.log("--------------------- 导购员初始化完成 ---------------------");
			}
			else{
				console.log("--------------------- remove all employees ---------------------");
//				$("#employee_table tbody").empty();
//				$("#employee_table").hide();
				$("#employee-list").empty().html("<h5 class='text-center'>没有导购员,请在云后台添加!</h5>");
			}
		}, function(tx, error) {
			console.log("init employee,Error : " + error.message);
		});
		
	});
}

//设置导购员默认选项,5-4//2015-10-25:更新 by fandy
function setDefaultEmployee(){
	var employee = JSON.parse(localStorage.getItem("SALEORDER_EMP"));//从LS取得导购员,并转为JSON对象
	console.log("--------------- 设置默认导购员 , employee-> "+employee);;
	if(employee!=null){
		//console.log("------------------------- employeeId  @ setDefaultEmployee() -> " + employee.employee_id );
		let employeeId = employee.employee_id;
		let employeeCode = employee.employee_code;
		let employeeName = employee.employee_name;
		$("input[name=r_employee_id]").each(function(){//迭代每个radio
	        if($(this).val()==employeeId){ 
	        	$(this).prop("checked",true).parents(".btn").addClass("active"); //设置导购员默认选项
						$(this).next("i").addClass("glyphicon glyphicon-ok");
						//给主页按钮赋值
						$(".guide_name").html(employeeName)
						$(".guide_id").html(employeeCode).show()
						// 修改按钮颜色
						$("#guideBtn").removeClass("btn-primary").addClass("bg-primary")
						//设置导购员input
						$("#employee_id").val(employeeId);
						$("#employee_name").val(employeeName);
						$("#btnGuide").html('<i class="glyphicon glyphicon-remove"></i>');
	        }
	    });
	}
}

//设置导购员选项,added by fandy AT 2015-10-26
//productEmpFlag 是否单品导购 0,1(取单/退货时的整单导购) 否; 2 是 by CPQ
function setEmployee(employeeId,employeeName,cartId,productEmpFlag){
	//$(ths).find("input[name=r_employee_id]:first").prop("checked",true);
//	var employeeId = $(ths).find("input[name=r_employee_id]:first").val();
//	var employeeName = $(ths).find("input[name=r_employee_name]:first").val();//取得导购员名	 
	console.log(employeeId,employeeName);
	
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM EMPLOYEES WHERE employee_id = ?", [employeeId], function(tx, result) {
			let len = result.rows.length;
			if(0 < len) {
				let item = result.rows.item(0);
				let saleOrder = {
					employee_id: employeeId,
					employee_code: item.employee_code,
					employee_name: employeeName
				};

				//整单导购时
				if(productEmpFlag != 2) {
					localStorage.setItem("SALEORDER_EMP", JSON.stringify(saleOrder));

					//设置导购员input
					$("#employee_id").val(employeeId);
					$("#employee_name").val(employeeName);
					$("#btnGuide").html('<i class="glyphicon glyphicon-remove"></i>');
				}
				else {
					//单品导购时，清除整单导购的数据
					localStorage.removeItem("SALEORDER_EMP");
					$("#employee_id").val("");
					$("#employee_name").val("");
					$("#btnGuide").html('<i class="glyphicon glyphicon-option-horizontal"></i>');
				}

				//非取单的整单导购，或单品导购时
				if(productEmpFlag != 1) {
					/*
					 * 整单导购时，单品导购和整单导购一样;
					 * 所有，整单和单品导购都要设置单品导购
					 */
					$("#product_employee_id").val(employeeId);
					$("#product_employee_name").val(employeeName);

					//整单时，更新所有商品导购为同一个导购
					var idPart = productEmpFlag == 2 && cartId ? "WHERE id = " + cartId : "";

					db.transaction(function(tx){
						tx.executeSql("UPDATE SHOPPINGCARTS SET employee_id = ?,employee_name = ?" + idPart,[employeeId,employeeName],function(tx,result){
							if(result.rowsAffected > 0){
								loadCart();// 加载购物车
							}
						});
					})
				}

				//给主页按钮赋值
				$(".guide_name").html(employeeName);
				$(".guide_id").html(saleOrder.employee_code).show();
				// 修改按钮颜色
				$("#guideBtn").removeClass("btn-primary").addClass("bg-primary");

			}
			$('#guideModal').modal('hide');
		});
	});
	
	
	
	
}


//清除导购员,edited by fandy AT 2015-10-26
function removeEmployee(cartId){
	//单品导购 ADD BY CPQ START
	//清除单品导购
	$("#product_employee_id").val(cartId != 0 ? ($(".employee_tr :eq(0)").data("employee_id") || "") : "");
	$("#product_employee_name").val(cartId != 0 ? ($(".employee_tr :eq(0)").data("employee_name") || "") : "");
	
	//整单时，移除所有商品导购(更新employee_id = 0;employee_name="")
	var idPart = cartId != 0 ? "WHERE id = " + cartId : "";
	
	db.transaction(function(tx){
		tx.executeSql("UPDATE SHOPPINGCARTS SET employee_id = ?,employee_name = ?" + idPart,[0,""],function(){
			loadCart();// 加载购物车
		});
	})
	
	//单品导购时,移除整单导购信息
	if(cartId != 0 && $("#employee_id").val() != ""){
		$("#employee_id").val("");
		$("#employee_name").val("");
		$("#btnGuide").html('<i class="glyphicon glyphicon-option-horizontal"></i>');
	}
	//单品导购 ADD BY CPQ END
	
	if(!$("#employee_id").val()) return; //如果没有导购员,无需清理

	$("#employee_id option:first").attr("selected","selected");
	localStorage.removeItem("cEmployeeId");
	
	$("#employee_id").val('');
	$("#employee_name").val('');
	$("#btnGuide").html('<i class="glyphicon glyphicon-option-horizontal"></i>');

	localStorage.removeItem("SALEORDER_EMP");
	
	$("input[name=r_employee_id]:checked").prop("checked",false);
}


//###################################################################################
//###################################### 分割线 ######################################
//###################################################################################

//生成小票JSON(供打印用)
function genReceiptPrintJson(sn, parkFlag){
	
	console.log("----------------- execute genReceiptPrintJson() ------------------------");
	
	if(!sn)
		return;
	
	//var localStorage = window.localStorage;
	var rpJsonStr = "{}";
	//localStorage.setItem("receiptPrintJsonStr",rpJsonStr);
	
	var rJsonStr = localStorage.getItem("receiptTemplateJsonStr");	
	if(rJsonStr!=null&&rJsonStr!=''){		
		rpJsonStr = rJsonStr;
	}			
	var rpJson = JSON.parse(rpJsonStr);
	
	//设置receipt_body JSON,从SALEORDRS,SALEORDERITEMS取值
	//var receiptNo = sn.toString().replace(/(^\s*)|(\s*$)/g, '');// 去除前后空格
	var receiptNo = sn;
	
	//用来判断是否取得了SALEORDER ADD BY CPQ 20161203
	var orderExists = false;
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM SALEORDERS WHERE sale_order_no = ? ", [ receiptNo ], function(tx, results) {
			// alert(results.rows.length);
			if (results.rows.length > 0) {
				orderExists = true;
				// 处理单据头
				var so = results.rows.item(0);
				//console.log("----------------- set desc json @ genReceiptPrintJson() --------------------");
				//设置receipt_desc JSON,从hidden取值,必须保证hidden有值
				
				//桌号 ADD BY CPQ
				var deskNoArray = so.desk_no ? so.desk_no.split("_") : ["",""];
				var descJsonObj = {
			        "sale_order_no": so.sale_order_no,
			        "sale_date": so.sale_date,
			        "total_amount": doDecimal(so.total_amount),
			        "payment": so.payment,
			        "pay": doDecimal(so.pay),
			        "changex": doDecimal(so.changex),
			        "customer_no": so.customer_code,
			        "total_points": doDecimal(so.total_points),
			        "cashier": so.username,
			        "guide": so.employee_name,
			        "total_qty" : doDecimal2(so.total_qty),
			        "desk_no" : (deskNoArray.length> 1 ? deskNoArray[1] : ""),
			        "sequence" : so.sequence
			    }
				rpJson.receipt_desc = descJsonObj;
				
				//取得会员信息,5-6
				var customerCode = so.customer_code;
				var customer_sale_type = so.sale_type;
				if(customerCode!=null&&customerCode!=''){//取得CUSTOMERCHANGES以取得本次扣款和本次积分 MODIFY BY CPQ 20161201
					tx.executeSql("SELECT * FROM CUSTOMERS c LEFT OUTER JOIN CUSTOMERCHANGES cc" +
							//" ON c.customer_code = cc.customer_code" +
							" ON c.customer_id = cc.customer_id" +
							" AND c.company_id = cc.company_id" +
							//" AND c.outlet_id = cc.outlet_id" +//使用他店共享会员时,会导致取不到cc表的数据,移除,不影响SQL执行结果
							" AND cc.sale_order_no = ?"+ 
							" WHERE c.company_id=? AND (c.outlet_id=? OR c.shared=1)" +
							" AND c.del_flag=0" +
							" AND c.customer_code =? ",
							[receiptNo,companyId, outletId, customerCode], function(tx, results) {
						//alert(results.rows.length);
						if (results.rows.length > 0) {
							var customer = results.rows.item(0);
							var customerJson = {
								"customer_name": customer.customer_name,
					            "customer_code": customerCode,
					            "customer_phone": customer.phone_number,
					            "customer_address": customer.address,
								"phone_number":customer.phone_number,
								"address":customer.address,
					            "customer_point": doDecimal(customer.point),
					            "customer_balance": doDecimal(customer.balance),
					            //上次余额 ADD BY CPQ
					            "customer_last_balance":$("#_current_balance").text(),
					            //本次扣款 ADD BY CPQ
					            "customer_pay":doDecimal(customer.increment_balance),
					            //本次积分 ADD BY CPQ
					            "total_points":((customer_sale_type == 0 || customer_sale_type == 1) ? doDecimal(customer.increment_point) : "0.00"),
					            //次卡次数 ADD BY CPQ
					            "times":$("#sum_times").val(),
								"used_times":$("#sum_used_times").val()
					        }
							
							rpJson["receipt_customer"] = customerJson;
						}
					},function(tx, error){
						console.error(error)
					});
				}
				
				/*//设置 receipt_remark JSON,用于挂单
				var parkRemarkStr = so.remark;
				//console.log("----------------- set remark @ genReceiptPrintJson() ->"+parkRemarkStr);
				if(parkRemarkStr){
					rpJson.receipt_remark = parkRemarkStr;
				}*/
				
				//都需要备注,5-6
				rpJson.receipt_remark = so.remark;
				
				
				//设置付款记录,added by fandy AT 20151010 START 
				//注:挂单没有此项
				tx.executeSql("SELECT * FROM PAYRECORDS WHERE sale_order_no = ? ", [ receiptNo ], function(tx, results)  {
					//console.log(receiptNo+"的付款方式->"+results.rows.length);
					if (results.rows.length > 0) {
						var items = [];
						var len = results.rows.length, i;
						//实收 ADD BY CPQ
						var real_pay = so.pay;
						for (i = 0; i < len; i++) {
							// alert("第"+i+"个PR");
							// alert(results.rows.length);
							var pr = results.rows.item(i);
							
							//if(pr.amount==0) continue; //REMARK:零不能过滤,在checkout()时,无意义的零pr不会插入,by fandy
							
							var prJson = {
								"payment": pr.payment,
					            "amount": doDecimal(parseFloat(pr.amount).toFixed(2))
					        }
							//real_pay += parseFloat(pr.amount);
							items.push(prJson);
						}
						//console.log("----------------- set body json @ genReceiptPrintJson() --------------------");
						rpJson["payrecords"] = items ;
						//实收 ADD BY CPQ
						rpJson["real_pay"] = doDecimal(real_pay);
					}
				});
				//设置付款记录,added by fandy AT 20151010 END
				
				// alert(saleOrder.id);
				// 处理单据体
				// db.transaction(function(tx) {
				tx.executeSql("SELECT * FROM SALEORDERITEMS WHERE sale_order_id = ?  ORDER BY id", [ so.id ], function(tx, results) {
					// alert(results.rows.length);
					if (results.rows.length > 0) {
						var items = [];
						var len = results.rows.length, i;
						var _totalListPrice = 0;//原价合计 SPRT专用

						for (i = 0; i < len; i++) {
							// alert("第"+i+"个明细");
							// alert(results.rows.length);
							var soi = results.rows.item(i);

							// 2014-2-16,处理附加属性
							//var custProps = "";
							//console.log("------cust_props @ SOI->" + soi.cust_props);
							/*if (soi.cust_props != null && soi.cust_props != '') {
								var propJsonArr = eval("(" + soi.cust_props + ")");
								if (propJsonArr.length > 0) {
									for ( var j = 0; j < propJsonArr.length; j++) {
										for ( var key in propJsonArr[j]) {
											//console.log(key + "=" + propJsonArr[j][key]);
											custProps += propJsonArr[j][key] + ",";
										}
									}
								}
								custProps = custProps != "" && custProps.length > 0 ? "(" + custProps.substring(0, custProps.length - 1) + ")" : "";
							}*/
							//custProps = (soi.cust_props != null && soi.cust_props!='' && soi.cust_props != 'null'  ) ? "(" + soi.cust_props + ")" : "";
							var custProps = custPropFormatted(soi.cust_props, true);
							//console.log("----------------- set body item @ genReceiptPrintJson() --------------------");
							var itemJson = {
					            "product_name": soi.product_name,
					            "cust_props": soi.cust_props,
					            "barcode": soi.barcode,
					            "unit": soi.unit,
					            "price": doDecimal(soi.price),
					            "qty": doDecimal2(soi.qty),
					            "discount": doDecimal(soi.discount),
					            "sale_price": doDecimal(soi.sale_price),
					            "subtotal": doDecimal(soi.subtotal_price),
					            "tastes": soi.tastes || "",
					            "item_no": soi.item_no || "",
					            "tag_remark": soi.remark || "",
					            "parent_seq": soi.parent_seq,
					            "seq":soi.seq
					        }
							
							items.push(itemJson);
							
							_totalListPrice += soi.price * soi.qty;
						}
						//console.log("----------------- set body json @ genReceiptPrintJson() --------------------");
						rpJson["receipt_body"] = items ;
						rpJson.receipt_desc["total_listprice"] = doDecimal(_totalListPrice);
						
						/*
						 * 为保证小票打印开始时rpJson确实已组装完成
						 * SALEORDERITEMS 的 if (results.rows.length > 0)内，
						 *此行后的打印小票逻辑移动到事务完成后，MODIFY BY CPQ 20161203
						 */
					}//if end
				}, null);
				
				//item end
			} 
		}, null);
	},null,function(){
		//打印小票逻辑移动到事务完成后，MODIFY BY CPQ 20161203
		if(orderExists == true){//sale order存在
			rpJsonStr = JSON.stringify(rpJson);	
			//console.log("----------------- set receiptPrintJsonStr @ genReceiptPrintJson() --------------------");
			localStorage.setItem("receiptPrintJsonStr",rpJsonStr);

			/*
			 * parkFlag = 0 : 普通收银
			 * parkFlag = 1 : 挂单打印
			 * parkFlag = 2 : 重打小票
			 * parkFlag = 3 : 次卡
			 * EDIT BY CPQ
			 */
			
			if(( parkFlag == 0 && $("#save_print").prop('checked') ) 
					|| (parkFlag == 1 && $("#park_print").prop('checked') )
					|| (parkFlag == 3 && $("#print_tc_consume_receipt").prop('checked') )
					|| parkFlag == 2) { //
				//取得小票宽度 ADD BY CPQ START
				var receiptJson = localStorage.getItem("PRINTER_RCP");
				var receiptWidth = 58;//默认为58
				var receiptType = null;
				if(receiptJson && receiptJson != "{}"){
					receiptObj = JSON.parse(receiptJson);
					if(receiptObj.receipt_template){
						if(receiptObj.receipt_template.width){
							receiptWidth = receiptObj.receipt_template.width;
						}
					}else if(receiptObj.printer){
						receiptType = receiptObj.printer.receipt_type
						switch(receiptType){
						case "0":
							receiptWidth = 58;
							break;
						case "1":
							receiptWidth = 80;
							break;
						case "9":
							receiptWidth = 100;
							break;
						default:
							receiptWidth = 58;
							break;
						}
					}
				}
				//取得小票宽度 ADD BY CPQ END
	//			if(getSetting("cReceiptType")==0)
				if(receiptWidth == 58)
					loadReceipt();//载入58小票
	//			if(getSetting("cReceiptType")==1)
				if(receiptWidth == 80)
					loadReceipt_1();//载入80小票
				if(receiptWidth == 76)
					loadReceipt_2();//载入80小票
	//			if(getSetting("cReceiptType")==9)
				if(receiptWidth == 100)
					loadBigReceipt();//载入大票
	//			if(getSetting("cReceiptType")==7)
				if(receiptType==7)
					loadReceipt_1_en();//载入英文小票
				if(receiptWidth == 99)//fandy 202012
					loadReceipt_sprt();//载入SPRT 100小票
			}
			
			//贴标打印
			if(( parkFlag == 0 && $("#tag_print").prop('checked') ) 
					|| (parkFlag == 1 && $("#park_tag_print").prop('checked') ) ){
				doTagPrint();
			}
			
			// 厨打
			if(( parkFlag == 0 && $("#kitchen_print").prop('checked') ) 
					|| (parkFlag == 1 && $("#park_kitchen_print").prop('checked')) ){
				kpPrinter.doKPPrint && kpPrinter.doKPPrint();
			}
		}else{//sale order不存在
			//console.log("----------------- set receiptPrintJsonStr / at no sale order @ genReceiptPrintJson() --------------------");
			localStorage.setItem("receiptPrintJsonStr",rpJsonStr);
		}
	});
}

//小票SPRT:适用于100mm的 SPRT打印机
function loadReceipt_sprt(){
	console.log("----------------- execute loadReceipt_sprt() -----------------");
	
	//var localStorage = window.localStorage;
	
	//MODIFY BY CPQ_PAGE 取得小票设置
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}
	//MODIFY BY CPQ_PAGE END
	//console.log("----------------- receipt header & footer -> " + JSON.stringify(receiptSetting));
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {	
		//载入desc,body
		var saleorderdetails = JSON.parse(localStorage.getItem("receiptPrintJsonStr"));//取得小票的销售单内容
		//旧用户没有模板宽度和类型 设置默认值 ADD BY CPQ
		if(!receiptSetting.receipt_template){
			receiptSetting.receipt_template = {width:99,template:"99-1"};
		}
		//加入定制 MODIFY BY CPQ START
		var msgBuff = setCustomedPrint(saleorderdetails,receiptSetting);
		console.error("--- msgBuff->\n",msgBuff);
		//加入定制 MODIFY BY CPQ END
		//打印开始
		//console.log("----------------- navigator.userAgent @doPrint() -> "+navigator.userAgent);
		var ua = navigator.userAgent.toLowerCase();
//		
//		if(ua.indexOf('chrome')>-1){//浏览器
//			console.log("----------------- 浏览器打印  @doPrint() ---------------");
//			$("#receipt_print_area").printArea(); // 使用Jquery.printArea插件打印局部
//		}
		
		if(ua.indexOf('windows_posbox')>-1){//windows壳
			console.log("----------------- windows打印   @doPrint() ---------------");
			//var localStorage = window.localStorage;
			var receiptJsonStr = localStorage.getItem("receiptPrintJsonStr");
			
			//输出JSON
			app.print(receiptJsonStr);
		}else
		if (pc){
			rawPrintReceipt(msgBuff);
		//MODIFY BY CPQ 安卓打印
		} else if (browser.versions.mobileAndroid){//Android壳
			androidPrintReceipt(msgBuff);
		} else if (browser.versions.mobileIos){//iOS壳
			mobilePrintReceipt(msgBuff);
		} else{
			for(var i = 0; i < msgBuff.length; i++){
				if(msgBuff[i] == "{logo}"){
					//载入Logo
					if(!isValidBase64(receiptSetting.header_logo)){
						receiptSetting.header_logo = "";
					}else{
						var logo = '<img id="logo_new" src="'+receiptSetting.header_logo+'">';
						$("#receipt_print_area_new .receipt_body_new").append(logo);
					}
				}else if(msgBuff[i] == "{qr_code}"){
					//载入二维码 ADD BY CPQ
					if(!isValidBase64(receiptSetting.QR_code)){
						receiptSetting.QR_code = "";
					}else{
						var QR_code = '<img id="qr_code_new" src="'+receiptSetting.QR_code+'">';
						$("#receipt_print_area_new .receipt_body_new").append(QR_code);
					}
				}else{
					var msg = msgBuff[i];
					if(typeof msg.replace == "function"){
						msg = msg.replace("!0 ","<font style='font-size:2em;'> ");
						msg = msg.replace(" !"," </font>");
						msg = msg.replace(/(@)|(!0)|(!)|()|(@)/g,"");
					}
					$("#receipt_print_area_new .receipt_body_new").append(msg);
				}
			}
			//图片渲染完成再打印 ADD BY CPQ
			if($("#receipt_print_area_new .receipt_body_new:eq(0)").find("img").length == 2){
				$("#receipt_print_area_new .receipt_body_new:eq(0)").find("img")[1].onload=function(){
					var imgWidth = $(this).width();
					var imgHeight = $(this).height();
					if(imgWidth > 200 || imgHeight > 200){
						$(this).attr({"width":imgWidth*200/360,"height":imgHeight*200/360});
					}
					
					$("#receipt_print_area_new").printArea();
				}
			}else if($("#receipt_print_area_new .receipt_body_new:eq(0)").find("img").length == 1){
				$("#receipt_print_area_new .receipt_body_new:eq(0)").find("img")[0].onload=function(){
					var imgWidth = $(this).width();
					var imgHeight = $(this).height();
					if(imgWidth > 200 || imgHeight > 200){
						$(this).attr({"width":imgWidth*200/360,"height":imgHeight*200/360});
					}
					
					$("#receipt_print_area_new").printArea();
				}
			}else{
				$("#receipt_print_area_new").printArea();
			}
		}
		//打印结束
		
	}
}

//小票0:适用于58mm小票打印机
function loadReceipt(){//采用新方法打印小票 MODIFY BY CPQ 20160407
	console.log("----------------- execute loadReceipt() -----------------");
	//var localStorage = window.localStorage;
	//MODIFY BY CPQ_PAGE 取得小票设置
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}
	//MODIFY BY CPQ_PAGE END
	//console.log("----------------- receipt header & footer -> " + JSON.stringify(receiptSetting));
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {
		//setReceiptCSS(receiptSetting.receipt_style.font_size,0);//set receipt print style
		//setReceiptCSS(3,0);//set receipt print style
		var saleorderdetails = JSON.parse(localStorage.getItem("receiptPrintJsonStr"));//取得小票的销售单内容
		//旧用户没有模板宽度和类型 设置默认值 ADD BY CPQ
		if(!receiptSetting.receipt_template){
			receiptSetting.receipt_template = {width:58,template:"58-1"};
		}
		//加入定制 MODIFY BY CPQ START
		var msgBuff = setCustomedPrint(saleorderdetails,receiptSetting);
		//加入定制 MODIFY BY CPQ END
		
		//打印开始
		//console.log("----------------- navigator.userAgent @doPrint() -> "+navigator.userAgent);
		var ua = navigator.userAgent.toLowerCase();
		if(ua.indexOf('windows_posbox')>-1){//windows壳
			console.log("----------------- windows打印   @doPrint() ---------------");
			//var localStorage = window.localStorage;
			var receiptJsonStr = localStorage.getItem("receiptPrintJsonStr");
			//输出JSON
			app.print(receiptJsonStr);
		}else
		if (pc){
			console.log("----------------- msgBuff:\n",msgBuff);
			rawPrintReceipt(msgBuff);
		//MODIFY BY CPQ 安卓打印
		} else if (browser.versions.mobileAndroid){//Android壳
			androidPrintReceipt(msgBuff);
		} else if (browser.versions.mobileIos){//iOS壳
			mobilePrintReceipt(msgBuff);
		} else {
			for(var i = 0; i < msgBuff.length; i++){
				if(msgBuff[i] == "{logo}"){
					//载入Logo
					if(isValidBase64(receiptSetting.header_logo)){
						var logo = '<img id="logo_new" src="'+receiptSetting.header_logo+'">';
						$("#receipt_print_area_new .receipt_body_new").append(logo);
					}
					else{
						receiptSetting.header_logo = "";
					}
					
				}else if(msgBuff[i] == "{qr_code}"){
					//载入二维码 ADD BY CPQ
					if(isValidBase64(receiptSetting.QR_code)){
						var QR_code = '<img id="qr_code_new" src="'+receiptSetting.QR_code+'">';
						$("#receipt_print_area_new .receipt_body_new").append(QR_code);
					}
					else{
						receiptSetting.QR_code = "";
					}
					
				}else{
					var msg = msgBuff[i];
					if(typeof msg != "undefined" && typeof msg.replace == "function"){
						msg = msg.replace("!0","<font style='font-size:2em;'>");
						msg = msg.replace("!","</font>");
						msg = msg.replace("@","");
						msg = msg.replace(/(@)|(!0)|(!)|()/g,"");
					}
					$("#receipt_print_area_new .receipt_body_new").append(msg);
				}
			}
			//图片渲染完成再打印 ADD BY CPQ
			if($("#receipt_print_area_new .receipt_body_new:eq(0)").find("img").length == 2){
				$("#receipt_print_area_new .receipt_body_new:eq(0)").find("img")[1].onload=function(){
					var imgWidth = $(this).width();
					var imgHeight = $(this).height();
					if(imgWidth > 200 || imgHeight > 200){
						$(this).attr({"width":imgWidth*200/360,"height":imgHeight*200/360});
					}
					
					$("#receipt_print_area_new").printArea();
				}
			}else if($("#receipt_print_area_new .receipt_body_new:eq(0)").find("img").length == 1){
				$("#receipt_print_area_new .receipt_body_new:eq(0)").find("img")[0].onload=function(){
					var imgWidth = $(this).width();
					var imgHeight = $(this).height();
					if(imgWidth > 200 || imgHeight > 200){
						$(this).attr({"width":imgWidth*200/360,"height":imgHeight*200/360});
					}
					
					$("#receipt_print_area_new").printArea();
				}
			}else{
				$("#receipt_print_area_new").printArea();
			}
		}
		//打印结束
		
	}
}

//小票1:适用于80mm小票打印机
function loadReceipt_1(){
	console.log("----------------- execute loadReceipt() -----------------");
	
	//var localStorage = window.localStorage;
	
	//MODIFY BY CPQ_PAGE 取得小票设置
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}
	//MODIFY BY CPQ_PAGE END
	//console.log("----------------- receipt header & footer -> " + JSON.stringify(receiptSetting));
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {	
		//载入desc,body
		var saleorderdetails = JSON.parse(localStorage.getItem("receiptPrintJsonStr"));//取得小票的销售单内容
		//旧用户没有模板宽度和类型 设置默认值 ADD BY CPQ
		if(!receiptSetting.receipt_template){
			receiptSetting.receipt_template = {width:80,template:"80-1"};
		}
		//加入定制 MODIFY BY CPQ START
		var msgBuff = setCustomedPrint(saleorderdetails,receiptSetting);
		//加入定制 MODIFY BY CPQ END
		//打印开始
		//console.log("----------------- navigator.userAgent @doPrint() -> "+navigator.userAgent);
		var ua = navigator.userAgent.toLowerCase();
//		
//		if(ua.indexOf('chrome')>-1){//浏览器
//			console.log("----------------- 浏览器打印  @doPrint() ---------------");
//			$("#receipt_print_area").printArea(); // 使用Jquery.printArea插件打印局部
//		}
		
		if(ua.indexOf('windows_posbox')>-1){//windows壳
			console.log("----------------- windows打印   @doPrint() ---------------");
			//var localStorage = window.localStorage;
			var receiptJsonStr = localStorage.getItem("receiptPrintJsonStr");
			
			//输出JSON
			app.print(receiptJsonStr);
		}else
		if (pc){
			rawPrintReceipt(msgBuff);
		//MODIFY BY CPQ 安卓打印
		} else if (browser.versions.mobileAndroid){//Android壳
			androidPrintReceipt(msgBuff);
		} else if (browser.versions.mobileIos){//iOS壳
			mobilePrintReceipt(msgBuff);
		} else{
			for(var i = 0; i < msgBuff.length; i++){
				if(msgBuff[i] == "{logo}"){
					//载入Logo
					if(!isValidBase64(receiptSetting.header_logo)){
						receiptSetting.header_logo = "";
					}else{
						var logo = '<img id="logo_new" src="'+receiptSetting.header_logo+'">';
						$("#receipt_print_area_new .receipt_body_new").append(logo);
					}
				}else if(msgBuff[i] == "{qr_code}"){
					//载入二维码 ADD BY CPQ
					if(!isValidBase64(receiptSetting.QR_code)){
						receiptSetting.QR_code = "";
					}else{
						var QR_code = '<img id="qr_code_new" src="'+receiptSetting.QR_code+'">';
						$("#receipt_print_area_new .receipt_body_new").append(QR_code);
					}
				}else{
					var msg = msgBuff[i];
					if(typeof msg.replace == "function"){
						msg = msg.replace("!0 ","<font style='font-size:2em;'> ");
						msg = msg.replace(" !"," </font>");
						msg = msg.replace(/(@)|(!0)|(!)|()|(@)/g,"");
					}
					$("#receipt_print_area_new .receipt_body_new").append(msg);
				}
			}
			//图片渲染完成再打印 ADD BY CPQ
			if($("#receipt_print_area_new .receipt_body_new:eq(0)").find("img").length == 2){
				$("#receipt_print_area_new .receipt_body_new:eq(0)").find("img")[1].onload=function(){
					var imgWidth = $(this).width();
					var imgHeight = $(this).height();
					if(imgWidth > 200 || imgHeight > 200){
						$(this).attr({"width":imgWidth*200/360,"height":imgHeight*200/360});
					}
					
					$("#receipt_print_area_new").printArea();
				}
			}else if($("#receipt_print_area_new .receipt_body_new:eq(0)").find("img").length == 1){
				$("#receipt_print_area_new .receipt_body_new:eq(0)").find("img")[0].onload=function(){
					var imgWidth = $(this).width();
					var imgHeight = $(this).height();
					if(imgWidth > 200 || imgHeight > 200){
						$(this).attr({"width":imgWidth*200/360,"height":imgHeight*200/360});
					}
					
					$("#receipt_print_area_new").printArea();
				}
			}else{
				$("#receipt_print_area_new").printArea();
			}
		}
		//打印结束
		
	}
}

//小票2:适用于76mm小票打印机
function loadReceipt_2(){
	console.log("----------------- execute loadReceipt() -----------------");
	
	//var localStorage = window.localStorage;
	
	//MODIFY BY CPQ_PAGE 取得小票设置
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}
	//MODIFY BY CPQ_PAGE END
	//console.log("----------------- receipt header & footer -> " + JSON.stringify(receiptSetting));
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {	
		//载入desc,body
		var saleorderdetails = JSON.parse(localStorage.getItem("receiptPrintJsonStr"));//取得小票的销售单内容
		//旧用户没有模板宽度和类型 设置默认值 ADD BY CPQ
		if(!receiptSetting.receipt_template){
			receiptSetting.receipt_template = {width:76,template:"76-1"};
		}
		//加入定制 MODIFY BY CPQ START
		var msgBuff = setCustomedPrint(saleorderdetails,receiptSetting);
		//加入定制 MODIFY BY CPQ END
		//打印开始
		//console.log("----------------- navigator.userAgent @doPrint() -> "+navigator.userAgent);
		var ua = navigator.userAgent.toLowerCase();
//		
//		if(ua.indexOf('chrome')>-1){//浏览器
//			console.log("----------------- 浏览器打印  @doPrint() ---------------");
//			$("#receipt_print_area").printArea(); // 使用Jquery.printArea插件打印局部
//		}
		
		if(ua.indexOf('windows_posbox')>-1){//windows壳
			console.log("----------------- windows打印   @doPrint() ---------------");
			//var localStorage = window.localStorage;
			var receiptJsonStr = localStorage.getItem("receiptPrintJsonStr");
			
			//输出JSON
			app.print(receiptJsonStr);
		}else
		if (pc){
			rawPrintReceipt(msgBuff);
		//MODIFY BY CPQ 安卓打印
		} else if (browser.versions.mobileAndroid){//Android壳
			androidPrintReceipt(msgBuff);
		} else if (browser.versions.mobileIos){//iOS壳
			mobilePrintReceipt(msgBuff);
		} else{
			for(var i = 0; i < msgBuff.length; i++){
				if(msgBuff[i] == "{logo}"){
					//载入Logo
					if(!isValidBase64(receiptSetting.header_logo)){
						receiptSetting.header_logo = "";
					}else{
						var logo = '<img id="logo_new" src="'+receiptSetting.header_logo+'">';
						$("#receipt_print_area_new .receipt_body_new").append(logo);
					}
				}else if(msgBuff[i] == "{qr_code}"){
					//载入二维码 ADD BY CPQ
					if(!isValidBase64(receiptSetting.QR_code)){
						receiptSetting.QR_code = "";
					}else{
						var QR_code = '<img id="qr_code_new" src="'+receiptSetting.QR_code+'">';
						$("#receipt_print_area_new .receipt_body_new").append(QR_code);
					}
				}else{
					var msg = msgBuff[i];
					if(typeof msg.replace == "function"){
						var preCode = "\x1b\x21\x31\n\x1c\x57\x01";
						var lastCode = "\x1b\x21\x01\n\x1c\x57\x00";
						msg = msg.replace(preCode,"<font style='font-size:2em;'>");
						msg = msg.replace(lastCode,"</font>");
						msg = msg.replace("@","");
						msg = msg.replace("@","");
					}
					$("#receipt_print_area_new .receipt_body_new").append(msg);
				}
			}
			//图片渲染完成再打印 ADD BY CPQ
			if($("#receipt_print_area_new .receipt_body_new:eq(0)").find("img").length == 2){
				$("#receipt_print_area_new .receipt_body_new:eq(0)").find("img")[1].onload=function(){
					var imgWidth = $(this).width();
					var imgHeight = $(this).height();
					if(imgWidth > 200 || imgHeight > 200){
						$(this).attr({"width":imgWidth*200/360,"height":imgHeight*200/360});
					}
					
					$("#receipt_print_area_new").printArea();
				}
			}else if($("#receipt_print_area_new .receipt_body_new:eq(0)").find("img").length == 1){
				$("#receipt_print_area_new .receipt_body_new:eq(0)").find("img")[0].onload=function(){
					var imgWidth = $(this).width();
					var imgHeight = $(this).height();
					if(imgWidth > 200 || imgHeight > 200){
						$(this).attr({"width":imgWidth*200/360,"height":imgHeight*200/360});
					}
					
					$("#receipt_print_area_new").printArea();
				}
			}else{
				$("#receipt_print_area_new").printArea();
			}
		}
		//打印结束
		
	}
}

//小票1,英文,7-14
function loadReceipt_1_en(){
	console.log("----------------- execute loadReceipt() -----------------");
	$(".receipt_body table tbody").empty();
	$(".receipt_body table tfoot").empty();
	$(".receipt_desc").html("");	
	$(".receipt_remark").html("");	
	
	//var localStorage = window.localStorage;
	//MODIFY BY CPQ_PAGE 取得小票设置
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}
	//MODIFY BY CPQ_PAGE END
	//console.log("----------------- receipt header & footer -> " + JSON.stringify(receiptSetting));
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {	
		//setReceiptCSS(receiptSetting.receipt_style.font_size,0);//set receipt print style
		setReceiptCSS(3,0);//set receipt print style
		
		//载入header,footer
		var logo = receiptSetting.header_logo!=''?'<img src="'+receiptSetting.header_logo+'"><br />':'';
//		$(".receipt_header").html(logo+decodeURIComponent(receiptSetting.header_text));
//		$(".receipt_footer").html(decodeURIComponent(receiptSetting.footer_text));
		$(".receipt_header").html(logo+removeCR(decodeURIComponent(receiptSetting.header_text)));
		$(".receipt_footer").html(removeCR(decodeURIComponent(receiptSetting.footer_text)));
		
		//载入desc,body
		var saleorderdetails = JSON.parse(localStorage.getItem("receiptPrintJsonStr"));//取得小票的销售单内容
		var desc = saleorderdetails.receipt_desc;
		var payment = desc.payment;//付款方式
		
		var descHtml = "<br />NO:" + desc.sale_order_no + "<br />" 
			+ "DATE:" + desc.sale_date + "<br />" 
			+ "TOTAL:" + desc.total_amount  + "<br />" 
			+ "PAYMENT:" + payment + "<br />" 
			+ "CASHIER:" + desc.cashier  + "<br />" 
			+ "ASST:" + desc.guide + "<br />";
		//console.log("---------------------------- desc->"+descHtml);
		
		//会员信息,6-4
		var customerInfo = saleorderdetails.receipt_customer;
		if(customerInfo!=null){
			descHtml += "<br />MEMBER:" + customerInfo.customer_code  + "<br />"
				//上次余额 ADD BY CPQ
				+ "LAST BALANCE:" + customerInfo.customer_last_balance
				+ "BALANCE:" + customerInfo.customer_balance  + "<br />"
				//+ "  POINT:" + desc.total_points + "<br />"
				+ "  TOTAL POINTS:" + customerInfo.customer_point + "<br />";
		}
		
		$(".receipt_desc").html(descHtml);
		
		
		var items = saleorderdetails.receipt_body;
		/*for(var i=0; i<items.length;i++){
			console.log("--------- item->"+items[i].product_name);
		}*/
		var len = items.length, i;
		
		//明细抬头,6-4
		/*var row_tr_title = "<tr><td>#</td><td>LIST PRICE</td><td>DISCOUNT</td><td>PRICE</td><td>QTY</td><td>SUBTOTAL</td></tr>";
		$(".receipt_body table tbody").append(row_tr_title);*/

		var totalQty = 0;
		var totalPrice = 0;
		// console.log("载入开始行");
		for (i = 0; i < len; i++) {
			// console.log("载入第" + (i + 1) + "行");
			var p = items[i];
			
			// 2014-2-16,处理附加属性,未使用
			//var custProps = "";
			/*if(p.cust_props!=null && p.cust_props!=''){
				var propJsonArr = eval("(" + p.cust_props + ")");
				if (propJsonArr.length > 0) {
					for ( var j = 0; j < propJsonArr.length; j++) {
						for ( var key in propJsonArr[j]) {
							console.log(key + "=" + propJsonArr[j][key]);
							custProps += propJsonArr[j][key] + ",";
						}
					}
				}
				custProps = custProps != "" && custProps.length > 0 ? "( " + custProps.substring(0, custProps.length - 1) + ")" : "";
			}*/
			//custProps = (p.cust_props != null && p.cust_props!='' && p.cust_props != 'null'  ) ? "(" + p.cust_props + ")" : "";
			var custProps = custPropFormatted(p.cust_props, true);
			var row_tr = "<tr><td colspan='4'>" + p.product_name + custProps +"<br />" + p.barcode + "</td></tr>"
				+"<tr class='splt'><td>" + p.sale_price + "</td><td> x </td><td>" + p.qty + "</td><td style='text-align:right;'>" + p.subtotal + "</td></tr>";

			$(".receipt_body table tbody").append(row_tr);

			totalQty += parseInt(p.qty);
			totalPrice += parseFloat(p.subtotal);// 使用转成浮点
		}

		totalPrice = doRound(totalPrice);

		// 合计与付款记录 START
		if ($(".receipt_body table tbody").children("tr").length > 0) {		
//			var row_tr_total = "<tfoot>"
//				+"<tr><td>TOTAL:</td><td colspan='3' style='text-align:right;'>"+_currency+""+ totalPrice + "</td></tr>"
//				+"<tr><td>PAY:</td><td colspan='3' style='text-align:right;'>"+_currency+""+ desc.pay+"</td></tr>"
//				+"<tr><td>CHANGE:</td><td colspan='3' style='text-align:right;'>"+_currency+""+ desc.changex+"</td></tr>"
//				+"</tfoot>";
			
			
			
			//用什么付款方式,就显示该付款方式及金额
			var row_tr_total = "<tfoot>"
				+"<tr><td colspan='3'>TOTAL:</td><td colspan='3' style='text-align:right;'>"+_currency+""+ totalPrice + "</td></tr>";
			
			//销售单付款记录 START
			if(payment!=null && payment!='' && payment !='undefined'){
				//现金:
//				if(payment=='CASH'){
//					row_tr_total = row_tr_total+"<tr><td colspan='2'>PAY:</td><td colspan='3' style='text-align:right;'>"+_currency+""+ desc.pay+"</td></tr>"
//					+"<tr><td colspan='3'>CHANGE:</td><td colspan='3' style='text-align:right;'>"+_currency+""+ desc.changex+"</td></tr>";
//				}
				
				//取得付款记录
				var payrecords = saleorderdetails.payrecords;
				
				//非组合付款
				if(payment!='COMP'){
					row_tr_total = row_tr_total
					+"<tr><td colspan='3'>"+payrecords[0].payment+":</td><td colspan='3' style='text-align:right;'>"+_currency+""+ payrecords[0].amount+"</td></tr>";
				}
				else{
					//组合付款
					for(var i=0; i<payrecords.length;i++){
						//console.log("--------- pr->"+payrecords[i].payment);					
						row_tr_total = row_tr_total
						+"<tr><td colspan='3'>"+payrecords[i].payment+":</td><td colspan='3' style='text-align:right;'>"+_currency+""+ payrecords[i].amount+"</td></tr>";
					}
				}	
				
				row_tr_total = row_tr_total
				+"<tr><td colspan='3'>CHANGE:</td><td colspan='3' style='text-align:right;'>"+_currency+""+ desc.changex+"</td></tr>";
			}
			//销售单付款记录 END
				
			row_tr_total = row_tr_total+"</tfoot>";			
			$(".receipt_body table").append(row_tr_total);	
		}
		// 合计与付款记录 END
		
		
		//载入remark,如果有
		var remark =  saleorderdetails.receipt_remark;
		if(remark!=null&&remark!=''){
			$(".receipt_remark").html(remark);
		}
		
		//打印开始
		//console.log("----------------- navigator.userAgent @doPrint() -> "+navigator.userAgent);
		var ua = navigator.userAgent.toLowerCase();
		
//		if(ua.indexOf('chrome')>-1){//浏览器
//			console.log("----------------- 浏览器打印  @doPrint() ---------------");
//			$("#receipt_print_area").printArea(); // 使用Jquery.printArea插件打印局部
//		}
		
		if(ua.indexOf('windows_posbox')>-1){//windows壳
			console.log("----------------- windows打印   @doPrint() ---------------");
			//var localStorage = window.localStorage;
			var receiptJsonStr = localStorage.getItem("receiptPrintJsonStr");
			
			//输出JSON
			app.print(receiptJsonStr);
		}else
		if (pc){
			rawPrintReceipt();
		}else{
			$("#receipt_print_area").printArea(); // 使用Jquery.printArea插件打印局部
		}
		//打印结束
		
	}
}

//大票
function loadBigReceipt(){
	console.log("----------------- execute loadBigReceipt() -----------------");
	$(".receipt_body table tbody").empty();
	$(".receipt_body table tfoot").empty();
	$(".receipt_desc").html("");	
	$(".receipt_remark").html("");	
	
	//var localStorage = window.localStorage;
	//MODIFY BY CPQ_PAGE 取得小票设置
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}

	//MODIFY BY CPQ_PAGE END
	//console.log("----------------- receipt header & footer -> " + JSON.stringify(receiptSetting));
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {	
		//setReceiptCSS(receiptSetting.receipt_style.font_size,0);//set receipt print style
		var customSettings = receiptSetting.customSettings;
		var printAreaId;
		if(!customSettings){
			printAreaId = "receipt_print_area";
			loadOldBigReceipt(receiptSetting);
		} else {
			printAreaId = "receipt_print_area_big";
			loadCustomedBigReceipt(receiptSetting);
		}

		//打印开始
		//console.log("----------------- navigator.userAgent @doPrint() -> "+navigator.userAgent);
		var ua = navigator.userAgent.toLowerCase();
		
		if(ua.indexOf('windows_posbox')>-1){//windows壳
			console.log("----------------- windows打印   @doPrint() ---------------");
			//var localStorage = window.localStorage;
			var receiptJsonStr = localStorage.getItem("receiptPrintJsonStr");
			
			//输出JSON
			app.print(receiptJsonStr);
		}
		
		$("#" + printAreaId).show();//要show才能打印
		$("#" + printAreaId).printArea(); // 使用Jquery.printArea插件打印局部
		$("#" + printAreaId).hide();
		
		if(pc){//nw会弹出alert(true),需要关闭
			$(".bootbox-alert").modal('hide');
		}
		//打印结束
	}
}

function loadOldBigReceipt(receiptSetting){
	setReceiptCSS(3,0);//set receipt print style
		
	//载入header,footer
	var logo = receiptSetting.header_logo!=''?'<img width="150" height="150" src="'+receiptSetting.header_logo+'"><br />':'';
	//$(".receipt_header").html(logo+decodeURIComponent(receiptSetting.header_text));
	
	//店铺名称 ADD BY CPQ
	var outletNameHtml = "";
	var fontStyle = "";
	if(receiptSetting.bigOutletName){
		fontStyle = " style='font-size:2em;'"
	}
	outletNameHtml = "<p"+fontStyle+">"+receiptSetting.outlet_name+ "</p>"
	
	$(".receipt_header").html(logo+outletNameHtml+removeCR(decodeURIComponent(receiptSetting.header_text)));
	
	//载入desc,body
	var saleorderdetails = JSON.parse(localStorage.getItem("receiptPrintJsonStr"));//取得小票的销售单内容
	var desc = saleorderdetails.receipt_desc;
	/*var descHtml = "单号:" + desc.sale_order_no + "<br />" 
		+ "交易时间:" + desc.sale_date + "<br />" 
		+ "总金额:" + desc.total_amount + "  付款方式:" + desc.payment + "<br />" 
		+ "收银员:" + desc.cashier + "  会员号:" + desc.customer_no + "<br />";*/
	
	
	var descHtml ="<table><tr>"
		+"<td>单号:</td><td colspan='2'>"+desc.sale_order_no+"</td>"
		+"<td>日期:</td><td colspan='2'>"+desc.sale_date+"</td>"
		+"</tr>"
		+"<tr>"
		+"<td>客户名称:</td><td>&nbsp;</td>"
		+"<td>客户编号:</td><td>&nbsp;</td>"
		+"<td>联系电话:</td><td>&nbsp;</td>"
		+"</tr>"
		+"<tr>"
		+"<td>地址:</td><td  colspan='5'>&nbsp;</td>"
		+"</tr></table>";
	
	var customer = saleorderdetails.receipt_customer;
	//console.log("---------------------------- customer in receiptJson ->"+customer+"/"+typeof(customer));
	if(typeof(customer)!='undefined'){//override descHtml for sale to customer
		descHtml ="<table><tr>"
			+"<td>单号:</td><td colspan='2'>"+desc.sale_order_no+"</td>"
			+"<td>日期:</td><td colspan='2'>"+desc.sale_date+"</td>"
			+"</tr>"
			+"<tr>"
			+"<td>客户名称:</td><td>"+customer.customer_name+"</td>"
			+"<td>客户编号:</td><td>"+customer.customer_code+"</td>"
			+"<td>联系电话:</td><td>"+customer.customer_phone+"</td>"
			+"</tr>"
			+"<tr>"
			+"<td>地址:</td><td  colspan='5'>"+customer.customer_address+"</td>"
			+"</tr></table>";
	}
	
	//console.log("---------------------------- desc->"+descHtml);
	$(".receipt_desc").html(descHtml);
	
	var industry = getSetting("Industry");
	var showCustprop = industry == "1001" || industry == "1002";
	var custpropTh = showCustprop ? "<th>颜色尺码</th>" : "";
	
	var row_th="<thead><tr>"
		+"<th>序号</th><th>条码</th><th>品名</th>"+custpropTh+"<th>单位</th><th>原价</th><th>售价</th><th>数量</th><th>小计</th>"
		+"</tr></thead>"
	$(".receipt_body table tbody").append(row_th);
	
	var items = saleorderdetails.receipt_body;
	/*for(var i=0; i<items.length;i++){
		console.log("--------- item->"+items[i].product_name);
	}*/
	var len = items.length, i;

	var totalQty = 0;
	var totalPrice = 0;
	// console.log("载入开始行");
	for (i = 0; i < len; i++) {
		// console.log("载入第" + (i + 1) + "行");
		var p = items[i];
		var custProps = custPropFormatted(p.cust_props, false);
		var custPropTd = showCustprop ? "<td>" + custProps+ "</td>" : "";
		var row_tr = "<tr><td style='text-align:center;'>" + (i + 1) + "</td>" +
				"<td>" + p.barcode + "</td>" +
				"<td>" + p.product_name+ "</td>" +
				custPropTd +
				"<td  style='text-align:center;'>" + p.unit +"</td>" +
				"<td style='text-align:right;'>" + p.price + "</td>" +
				"<td style='text-align:right;'>" + p.sale_price + "</td>" +
				"<td style='text-align:center;'>" + p.qty + "</td>" +
				"<td style='text-align:right;'>" + p.subtotal + "</td></tr>";

		$(".receipt_body table tbody").append(row_tr);

		totalQty += parseInt(p.qty);
		totalPrice += parseFloat(p.subtotal);// 使用转成浮点
	}

	var calc = totalPrice >= 0 ? 1 : -1;
	var calcZhCn = totalPrice >= 0 ? "" : "负";
	
	//抹零时用正数抹零，在取符号  BY CPQ
	totalPrice = doRound(Math.abs(totalPrice)) * calc;
	//console.log("---------------------------- 合计大写->"+convertCurrency(totalPrice));
	// 有内容,才载入合计行
	if ($(".receipt_body table tbody").children("tr").length > 0) {
		var row_tr_total = "<tfoot><tr><td colspan='"+(showCustprop ? 7 : 6)+"'>合计:</td>"
		+"<td style='text-align:center;'>"+doDecimal2(totalQty) + "</td>"
		+"<td style='text-align:right;'>"+_currency + doDecimal(totalPrice) + "</td></tr>"
		+"<tr><td colspan='"+(showCustprop ? 9 : 8)+"' style='text-align:right;'>"+convertCurrency(totalPrice)+"</td></tr>"
		+"</tfoot>";
		
		$(".receipt_body table").append(row_tr_total);	
	}
	// console.log("载入结束行");
	
	
	var footerHtml ="<table><tr>"
		+"<td width='10%'>业务员:</td><td width='12%'>"+desc.guide+"</td>"
		+"<td width='10%'>制单者:</td><td width='13%'>"+desc.cashier+"</td>"
		+"<td width='10%'>送货人:</td><td width='12%'>&nbsp;</td>"
		+"<td width='10%'>签收人:</td><td width='13%'>&nbsp;</td>"
		+"</tr></table>";
	$(".receipt_footer").html(footerHtml);
	$(".receipt_foot").html(removeCR(receiptSetting.footer_text));
	
	
	//载入remark,如果有
	var remark =  saleorderdetails.receipt_remark;
	//20151028:Modify by Dingph
	//if(remark!=null&&remark!=''){
	if(remark && remark != ''){
	//20151028:Modify by Dingph
		$(".receipt_remark").html(remark);
	}
}

function loadCustomedBigReceipt(receiptSetting){
	var customSettings = receiptSetting.customSettings;
	if(!customSettings.customed){
		customSettings = gen100Template1();
	}

	$("#receipt_print_area_big").html("<table cellspacing='0' cellpadding='0'></table>");

	//取得小票的销售单内容
	var saleorderdetails = JSON.parse(localStorage.getItem("receiptPrintJsonStr"));
	//载入desc,receiptbody
	var desc = saleorderdetails.receipt_desc;
	var payment = desc.payment;//付款方式
	var PAYMENT_MAP = customSettings.paymentName;

	var template_type = receiptSetting.receipt_template.template;
	var currency = "";
	if(receiptSetting.currencySymbol && receiptSetting.showCurrencySymbol){
		currency = receiptSetting.currencySymbol;
		if(currency == "other"){
			currency = receiptSetting.otherCurrency;
		}
	}

	var colspan = 0;
	$.each(customSettings.lines,function(i,line){
		//普通项目 一个项目是 标题+值 = 2列
		var len = line.length.length * 2;
		$.each(line,function(j,col){
			var field = col.field;
			
			if(field == "product_list"){
				len = getProductListFields(template_type).length;
			}else if(field == "customer_info"){
				len = Object.keys(customSettings.customerTitle).length * 2;
			}
		});

		if(len > colspan){
			colspan = len;
		}
	});

	var _table = $("#receipt_print_area_big table");
	var imgStyle = " style='margin: 2em 0;'";
	var headerStyle = "white-space: pre-wrap; font-size: 14pt;font-weight: bold; margin: 2em 0;"
	$.each(customSettings.lines,function(i,line){
		var len = line.length;
		
		if(len > 0){
			var _tr = $("<tr>");
			var titleColspan = 1;
			var allValueColspan = colspan - titleColspan * len;
			var avgValueColspan = parseInt(allValueColspan / len);
			var remindColspan = allValueColspan % len;

			$.each(line,function(j,col){
				var title = col.title;
				var field = col.field;
				
				if(title) title += ":";
				
				if(field == "logo"){
					if(isValidBase64(receiptSetting.header_logo)) {
						_tr.append("<td align='center' colspan='"+colspan+"'>"
						+ "<img "+imgStyle+" src='"+receiptSetting.header_logo+"'>" + "</td>");

						_table.append(_tr);
					}
				}else if(field == "outlet_name"){
					var outlet_name = receiptSetting.outlet_name || getSetting("oName");
					//大字打印店铺名
					var bigOutletName = true;
					if(receiptSetting.bigOutletName){
						bigOutletName = receiptSetting.bigOutletName;
					} 
					
					var fontStyle = " style='" + headerStyle;
					if($("#receipt_big_outletName").prop("checked")){
						fontStyle += "font-size:2em;"
					}
					fontStyle += "'";
					_tr.append("<td align='center'"+fontStyle+" colspan='"+colspan+"'>"
							+ outlet_name + "</td>");

					_table.append(_tr);
				}else if(field == "header_text"){
					_tr.append("<td "+" style='" + headerStyle + "'"
							+" align='center' colspan='"+colspan+"'>"
							+ receiptSetting.header_text + "</td>");
					
					_table.append(_tr);
				}else if(field == "footer_text"){
					_tr.append("<td align='center' colspan='"+colspan+"'>"
							+ receiptSetting.footer_text + "</td>");
					
					_table.append(_tr);
				
					//插入广告
					if(getSetting("free") == 1){
						_tr = $("<tr>").append("<td align='center' colspan='"+colspan+"'>"
							+ advertisement + "</td>");
						
						_table.append(_tr);
					}
				}else if(field == "qr_code"){
					if(isValidBase64(receiptSetting.QR_code)) {
						_tr.append("<td align='center' colspan='"+colspan+"'>"
								+ "<img "+imgStyle+" src='"+receiptSetting.QR_code+"'>" + "</td>");
						
						_table.append(_tr);
					}
				}else if(field == "payment_detail"){
					//付款方式
					if (isNotPark) {
						//销售单付款记录 START
						if(payment!=null && payment!='' && payment !='undefined'){
							//取得付款记录
							var payrecords = saleorderdetails.payrecords;
							for(var i = 0; i < payrecords.length; i++){
								var payrecord = payrecords[i];
								var _payment = PAYMENT_MAP[payrecord.payment];
								var amount = payrecord.amount;
								_tr.append("<td align='left' colspan='" + parseInt(colspan / 2) + "'>" + _payment + "</td>"
									+"<td align='right' colspan='" + (parseInt(colspan / 2) + colspan % 2) + "'>"+amount+"</td>");
								
								_table.append(_tr);
		
								_tr = $("<tr>");
							}
						}
					}
				}else if(field == "product_list"){
					var items = saleorderdetails.receipt_body;
					var titleMap = customSettings.productTitle;
					
					printBigProductInfo(_table, colspan, items, titleMap, template_type);
				}else if(field == "customer_info"){
					var customer = saleorderdetails.receipt_customer;
					var titleMap = customSettings.customerTitle;
					
					printBigCustomerInfo(_table, colspan, titleMap, customer);
				}else if(field == "space_line"){
					_tr.append("<td align='center' colspan='"+colspan+"'>&nbsp;</td>");
					_table.append(_tr);
				}else if(field == "totalPrice"){// 应收金额（合计）
					var value = currency + desc["total_amount"];
					var totalQty = desc['total_qty'];
					
					printBigTotalPrice(_table, colspan, title, totalQty, value, template_type);
				}else if(field == "remark"){
					var remark =  saleorderdetails.receipt_remark;
					
					_tr.append("<td align='left' colspan='"+ colspan +"'>"
						+ title + remark + "</td>");
					_table.append(_tr);
				}else if(field == "seq"){
					if(getSetting("seq_enabled") == 1){
						var num = getSetting("seq_num") || 0;
						var cateringSeq = getSetting("seq_suffix") || "";
						var seq = desc.sequence;
						
						var seqLen = (seq+"").length
						if(num > seqLen){
							for(var i = 0; i < num - seqLen; i++){
								cateringSeq += "0";
							}
						}
						
						cateringSeq += seq;
						
						_tr.append("<td align='center' colspan='"+ colspan +"'>"
							+ title + cateringSeq + "</td>");
						_table.append(_tr);
					}
				}else if(field == "upper_CNY") {

					printUpperCNY(_table, colspan, title, desc["total_amount"], template_type);
				}else{
					var realpay = saleorderdetails.real_pay;
					var value = desc[field];
					
					if(field == "real_pay"){
						value = currency + realpay;
					}else if(field == "changex"){
						value =  currency + value;
					}else if(field == "payment"){
						value = (payment!=null && payment!='' && payment !='undefined'? PAYMENT_MAP[payment] : "");
					}else if(field == "preferential_amount"){// 优惠金额
						value = currency + getPreferentialAmount(saleorderdetails.receipt_body);
					}else if(field == "desk_no"){
						//桌号关闭时，不打印桌号
						if(getSetting("desk_no_enabled") == 0){
							return;
						}
					}else if(field == "leave_a_word"){
						value = "";
					}
					
					_tr.append("<td colspan='"+titleColspan+"' nowrap>"+title+"</td>")
						.append("<td colspan='"+(avgValueColspan + ((j >= len - remindColspan) ? 1 : 0))+"'>"+value+"</td>");

					_table.append(_tr);
				}
			});
		}
	});
}

//打印小票
function doPrint(sn, parkFlag) {
	console.log("----------------- execute doPrint() -----------------");
	genReceiptPrintJson(sn, parkFlag);
}

//标签打印
function doTagPrint() {
	var tagJson = localStorage.getItem("PRINTER_TAG");
	if(tagJson){
		tagJson = JSON.parse(tagJson);
		var saleorderdetails = JSON.parse(localStorage.getItem("receiptPrintJsonStr"));//取得小票的销售单内容	
		var lines =  tagJson['lines'] || [["desk_no","product_name"],["tastes"],["sale_price"],["sale_date"]];
		//console.log("########## 标签打印lines:"+lines);
		//每个商品打印一次
		var desc = saleorderdetails.receipt_desc;
		var products = saleorderdetails.receipt_body;
		var desk_no = desc.desk_no || "";
		var sale_date = desc.sale_date;
		
		console.log("########## receipt_desc:"+JSON.stringify(desc));
		console.log("########## receipt_body:"+JSON.stringify(products));
		
		var tastesMap = {};
		var tastesAmountMap = {};
		for(var i in products){
			var product = products[i];
			if(product.parent_seq ){
				var taste = tastesMap[product.parent_seq] || "";
				var tasteAmount = tastesAmountMap[product.parent_seq] || 0;
				var qtyStr = product.qty > 1 ? ("X"+parseFloat(product.qty)) : "";
				tastesMap[product.parent_seq] = taste + (taste ? "," : "") + product.product_name+qtyStr;
				tastesAmountMap[product.parent_seq] = tasteAmount*1 + product.price*1;
			}
		}
		
		for(var i in products){
			var msgBuff = [];
			var product = products[i];
			
			if(product.parent_seq) continue;
			
			var tastes = product.tastes || "";
			var tastes2 = tastesMap[product.seq] || "";
			var tastesAmount = tastesAmountMap[product.seq] || 0;
			
			product.tastes = tastes + (tastes2 ? ((tastes ? "," : "") +  tastes2) : "");
			
			for(var j in lines){
				var line = lines[j];
				
				for(var k in line){
					var field = line[k];
					//console.log("########## 标签打印字段"+field+"="+product[field]);
					if(field == "desk_no"){
						if(desk_no!='') msgBuff.push("桌号:"+desk_no+"\n");
					}
					else if(field == "sale_date"){
						msgBuff.push(sale_date+"\n");
					}
					else{
						var value = product[field];
						if(field=='sale_price'){
							value = "￥" + doDecimal(value*1 + tastesAmount*1);
						}
						msgBuff.push(value!=''?value+"\n":"");
					}
				}
				
//				if(j != lines.length - 1){
//					msgBuff.push("\n");
//				}
			}
			console.log("########## 标签打印内容:",msgBuff);
			if(pc) {
				pc.printTag && pc.printTag(tagJson,msgBuff);
			} else if(browser.versions.mobileAndroid){
				tagJson["print_data"] = msgBuff.join("");
				PBAPrinter.printTag && PBAPrinter.printTag(JSON.stringify(tagJson));
		    }
			else if(browser.versions.mobileIos) {
				var printBuff = [];
		  		var CODE_MAP = {
		  				"CODE128" : "EAN128",
		  				"CODE39" : "39",
		  				"EAN13" : "EAN13"
		  		};

		  		var printData = msgBuff.join("").split('\n');

		  		var dots = 8,
				lineSpacing = 28;;
				var labelWidth = tagJson["label_width"] || 40,
		        labelHeight = tagJson["label_height"] || 30;// from driver setting skip here
				var gapHeight = "2",
		        gapOffset = "0.1";

				var margin_top = (tagJson["v_offset"] || 2) * dots, //1mm default
		        margin_left = (tagJson["h_offset"] || 1) * dots;
				var bar_height = tagJson["bar_height"] || 30;
				var barcode_height_dots = Math.round(bar_height * labelHeight * dots / 100);
				var barcode = tagJson['barcode'];
				var type = CODE_MAP[(tagJson["type"] || "EAN13").toUpperCase()];

				var direction = 1;

				printBuff.push('SIZE ' + labelWidth + ' mm,' + labelHeight + ' mm\n');
				printBuff.push('GAP ' + gapHeight + ' mm,' + gapOffset + ' mm\n');
				printBuff.push('DIRECTION ' + direction + '\n');
				printBuff.push('CLS\n');

				var isBarcode = false;
				for(var j = 0, index = 0; j < printData.length; j++, index++){
					var data = printData[j];

					if(data == "{separator}"){
						printBuff.push('BAR 0,' + (margin_top + index * lineSpacing + (isBarcode ? barcode_height_dots : 0)) + ',3000,2\n');
					}else if(data == "{barcode}"){
						if(!barcode) {
							index--;
							continue;
						}
						printBuff.push('BARCODE ' + (margin_left + dots) + ',' + (margin_top + index * lineSpacing) + ',\"' + type + '\",' + barcode_height_dots + ',1,0,2,4,\"' + barcode + '\"\n');
						isBarcode = true;
					}else {
						printBuff.push('TEXT ' + margin_left + ',' + (margin_top + index * lineSpacing + (isBarcode ? barcode_height_dots : 0)) + ',\"' + labelLanguage + '\",0,1,1,\"' + data + '\"\n');
					}
				}

				printBuff.push('PRINT 1\n');

				var printer = '';
				if('bt' === tagJson['printer']['default_printer_ios']) {
					printer = tagJson['printer']['mac'];
				}
				else if('wifi' === tagJson['printer']['default_printer_ios']) {
					printer = tagJson['printer']['ip'];
				}

				var job = {
					printerAddr : printer,
					content : printBuff.join(''),
					keepAlive : true,
					copyNum : 1
				};
				var taskList = [];
				taskList.push(job);

				var obj = {};
				obj['taskList'] = taskList;

				if(printer)
					api.require('posPrinter').printOnSpecifiedPrinters(obj);
			}
		}
	}
}

//设置小票样式
var inlineMediaStyle = null;
function setReceiptCSS(fSize,_margin){
	$("#settle_style,#deposit_style,#kp_sale_style").remove();
	//var fSize = $("#receipt_font_size").val();
	//var fSize = $(".receipt_font_size:checked").val();
	//var _margin = $(".receipt_font_size").val();
	
    var head = document.getElementsByTagName('head')[0];
    var newStyle = document.createElement('style');
    newStyle.setAttribute('type', 'text/css');
    newStyle.setAttribute('media', 'print');
    newStyle.setAttribute('id', 'sale_style');
    
    newStyle.appendChild(document.createTextNode('body{display: block; margin:0; padding:0; font-size: 9pt; font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;}'));
    newStyle.appendChild(document.createTextNode('img{margin-bottom:2pt;}'));
    newStyle.appendChild(document.createTextNode('table{width:100%;margin:0;padding:0;font-size: 9pt;}'));
    newStyle.appendChild(document.createTextNode('table tbody tr{ border-bottom:1pt solid #666;border-padding: 2pt;}'));
    //取得receiptType,width ADD BY CPQ
    var receiptJson = localStorage.getItem("PRINTER_RCP");
    var receiptWidth = 58;//默认为58
	var receiptType = null;
	if(receiptJson && receiptJson != "{}"){
		receiptObj = JSON.parse(receiptJson);
		if(receiptObj.receipt_template){
			receiptWidth = receiptObj.receipt_template.width;
		}else if(receiptObj.printer){
			receiptType = receiptObj.printer.receipt_type
		}
	}
//    if(getSetting("cReceiptType")==9){//big receipt MODIFY BY CPQ
	if(receiptWidth == 100 || receiptType == 9){
    	newStyle.appendChild(document.createTextNode('.receipt_body table{ border-width:1pt ;border-color: #666; border-collapse:collapse;}'));
    	newStyle.appendChild(document.createTextNode('.receipt_body table th,.receipt_body table td{ border:1pt solid #666; padding: 2pt;}'));
        
    }
    else{
    	newStyle.appendChild(document.createTextNode('.receipt_body table tbody tr.splt td{ border-bottom:1pt solid #666 ;border-padding: 2pt;}'));
    }
    
    if (inlineMediaStyle != null)
    {
        head.replaceChild(newStyle, inlineMediaStyle)
    }
    else
    {
        head.appendChild(newStyle);
    }
    inlineMediaStyle = newStyle;
}

//设置交班结算小票样式
var inlineMediaStyle3 = null;
function setSettleReceiptStyle(){
	$("#sale_style,#deposit_style,#kp_sale_style").remove();
	
    var head = document.getElementsByTagName('head')[0];
    var newStyle = document.createElement('style');
    newStyle.setAttribute('type', 'text/css');
    newStyle.setAttribute('media', 'print');
    newStyle.setAttribute('id', 'settle_style');
    
    newStyle.appendChild(document.createTextNode('body{display: block; margin:0; padding:0; font-size: 9pt; font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;}'));
    newStyle.appendChild(document.createTextNode('img{margin-bottom:2pt;}'));
    newStyle.appendChild(document.createTextNode('table{margin: 0;padding: 0;width: 100%;font-size: 9pt;}'));
    newStyle.appendChild(document.createTextNode('table tbody tr,table tbody tr td {border-bottom: 1pt solid #666;border-padding: 2pt;}'));
    
    if (inlineMediaStyle3 != null)
    {
        head.replaceChild(newStyle, inlineMediaStyle3)
    }
    else
    {
        head.appendChild(newStyle);
    }
    inlineMediaStyle3 = newStyle;
}

//设置充值小票样式
var inlineMediaStyle2 = null;
function setDepositReceiptStyle(){
	$("#sale_style,#settle_style,#kp_sale_style").remove();
    var head = document.getElementsByTagName('head')[0];
    var newStyle = document.createElement('style');
    newStyle.setAttribute('type', 'text/css');
    newStyle.setAttribute('media', 'print');
    newStyle.setAttribute('id', 'deposit_style');
    
    newStyle.appendChild(document.createTextNode('body{display: block; margin:0; padding:0; font-size: 9pt; font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;}'));
    newStyle.appendChild(document.createTextNode('.deposit_receipt_title {margin-top: 10px;text-align: center;font-size: 12pt !important;font-weight: bold;text-align: center;}'));
    newStyle.appendChild(document.createTextNode('.deposit_receipt_header {margin-top: 5pt;text-align: center;font-size: 9pt;border-bottom: 1px dotted #000;}'));
    newStyle.appendChild(document.createTextNode('img{margin-bottom:2pt;}'));
    newStyle.appendChild(document.createTextNode('table{margin: 0;padding: 0;width: 100%;font-size: 9pt;}'));
    newStyle.appendChild(document.createTextNode('table tr td{white-space:nowrap;}'));//中文强制不换行
    
    if (inlineMediaStyle2 != null)
    {
        head.replaceChild(newStyle, inlineMediaStyle2)
    }
    else
    {
        head.appendChild(newStyle);
    }
    inlineMediaStyle2 = newStyle;
}


//格式化附加属性
function custPropFormatted(cust_props,bkt){
	if(bkt){//带括号
		return (cust_props != null && cust_props!='' && cust_props != 'null' && cust_props != 'undefined'  ) ? "(" + cust_props + ")" : "";
	}else{
		return (cust_props != null && cust_props!='' && cust_props != 'null' && cust_props != 'undefined'  ) ? cust_props : "";
	}
}

//###################################################################################
//###################################### 分割线 ######################################
//###################################################################################

//各种click,keyup,onchange,onblur动作
$(document).ready(function(){
	// 整单折扣方式
	//直减
	$("#btn_discount_type_a").click(function() {
		$('#btn_discount_type_b').removeClass('btn-primary');
		$('#btn_discount_type_a').addClass('btn-primary');
		$('#discount_a').removeClass('hide');
		$('#discount_b').addClass('hide');
		$('#all_discount_type').val(1);
		//$("#btnDiscountFull").attr("disabled","disabled");
		$("#final_pay").focus().select();
	});
	
	//整折
	$("#btn_discount_type_b").click(function() {
		$('#btn_discount_type_a').removeClass('btn-primary');
		$('#btn_discount_type_b').addClass('btn-primary');
		$('#discount_b').removeClass('hide');
		$('#discount_a').addClass('hide');
		$('#all_discount_type').val(2);
		//$("#btnDiscountFull").removeAttr("disabled");
		$("#all_discount").focus().select();
	});
	

	//弹出搜索modal
	$("#btnSearch").click(function() {
		initSearchProductModal();
		$('#searchModal').one('shown.bs.modal',function(){
			$('#kw').select();
			$("#cat_list_cardBody").outerHeight($("#product_list_cardBody").outerHeight() + $("#product_list_pageCard").outerHeight());
			//分类列表 ADD BY CPQ
			initCategoryList();
		});
		$('#searchModal').modal('show');
	});

	// 弹出整单折扣modal
	$("#btnDiscount").click(function() {
		if ($("#cart tbody").children("tr").length == 0) {
			//alert("销售单为空!");
			return;
		}
		//$('#discountModal').one('shown.bs.modal',function(){$('#all_discount').select();});
		initDiscountFull();
	});

	// 弹出选择导购员modal
	$(".openGuideModal").click(function() {
		initEmployees(0,0,0);
		
		initRemoveEmployeeBtnEvent($("#employee_id").val(),0);
		if(!browser.versions.mobileAndroid){
		$('#guideModal').one("shown.bs.modal",function(){
			$(this).find("input[type='text']").val("").focus().select();
			searchEmployee("");
		});
		}
		var guidmargin=parseInt($("#guideModal .modal-dialog").css("margin-top"))*2;
		var employeeListHeight=$(window).height()-110-$("#employeekeyword").outerHeight()-guidmargin;
		var employeeListsHeight=$(window).height()*0.5;
		$("#employee-list").outerHeight(employeeListHeight);
		
		if(employeeListHeight>=employeeListsHeight){
			$("#employee-list").outerHeight(employeeListsHeight);
		}
		$('#guideModal').modal('show');	
	});
	
	$("#btnGuide").click(function() {
		//alert($(this).find("i:first").attr("class"));
		var iclass = $(this).find("i:first").attr("class");
		console.log("###################i class->"+iclass+"/"+$(this).find("i:first").hasClass('glyphicon-option-horizontal'));
		if($(this).find("i:first").hasClass('glyphicon-option-horizontal')){
			$(".openGuideModal").click();
		}
		if($(this).find("i:first").hasClass('glyphicon-remove')){
			removeEmployee(0);
		}
	});
	


	// 弹出挂单列表modal
	$("#btnRetrieve").click(function() {
		console.log("---------------------- wishlistsize 1->"+wishlistsize);
		$("#wishlist tbody").empty();
		getParkList2();
		console.log("---------------------- wishlistsize 2 ->"+wishlistsize);
		if (wishlistsize>0)
			$('#wishlistModal').modal('show');
	});

	// 取得销售记录
	$("#btnGetSalesHistory").click(function() {
		//$('#current_sale_panel').hide();
		var today = new Date().Format("yyyy-MM-dd");
		$("#start_sale_date").val(today);
		$("#end_sale_date").val(today);
		
		getSalesHistory();

		//$('#sales_history_panel').show();
		$('#salesHistoryModal').modal('show');
		$("#btnGetSalesHistory").blur();
	});

	// 返回当前销售
	$("#btnGetCurrentSale").click(function() {
		$('#current_sale_panel').show();
		$('#sales_history_panel').hide();
	});

	// 弹出退货MODAL
	$("#btnReturns").click(function() {
		initRefund();
		$('#refundModal').one('shown.bs.modal',function(){
			$('#receipt_no').select();
		});
		//退货独立 BY CPQ
//		location.href = "refund.html?online="+(online ? 1 : 0)
	});


	// 弹出换班结算MODAL
	// 20170414：delete by dph
	// 方法移至settle-print.js
	/*$("#btnSettle").click(function() {
		viewSettlement();
	});*/
	// 20170414：delete by dph

	// 无码商品MODAL
	$("#btnNoBarcode").click(function() {
		initNoBarcodeModal();
		$('#noBarcodeModal').one("shown.bs.modal",function(){
			setTimeout(function(){
				$('#product_name_4_nb').select();
			},500)
		})
		$('#noBarcodeModal').modal('show');
	});
	
	
	// 弹出员工登录密码修改MODAL
	$("#btnUserPassword").click(function() {
		if(!online) return;
		$('#userPasswordModal').modal('show');
	});
	
	
	$("#final_pay").keyup(function(){
		var totalListPrice = parseFloat($("#total_list_price").val());
		console.log("--------------------- totalListPrice  ->"+totalListPrice);
		var saving = $("#all_saving").val();
		var finalPay = $("#final_pay").val();
		
		var reg = /^[+-]?\d+\.?\d*$/;// 任意整数或小数
		//console.log("----------------- 付现格式校验@change()->  " + reg.test(cPay));
		
		if (!reg.test(finalPay)) {
			$("#final_pay").next().text("折扣金额必须是数字!").css({"color":"#ff0000","font-weight":"bold"});
			$("#final_pay").css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$("#final_pay").next().text("").removeAttr("style");
			$("#final_pay").removeAttr("style");
			
			$("#all_saving").val(doDecimal(totalListPrice - finalPay));
		}
	});
	
	$("#all_saving").keyup(function(){
		var totalListPrice = parseFloat($("#total_list_price").val());
		console.log("--------------------- totalListPrice  ->"+totalListPrice);
		var saving = $("#all_saving").val();
		var finalPay = $("#final_pay").val();
		
		
		var reg = /^[+-]?\d+\.?\d*$/;// 任意整数或小数
		//console.log("----------------- 付现格式校验@change()->  " + reg.test(cPay));
		
		if (!reg.test(saving)) {
			$("#all_saving").next().text("实收金额必须是数字!").css({"color":"#ff0000","font-weight":"bold"});
			$("#all_saving").css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$("#all_saving").next().text("").removeAttr("style");
			$("#all_saving").removeAttr("style");
			
			$("#final_pay").val(doDecimal(totalListPrice - saving));
		}
	});
	
	
	$("#all_discount").keyup(function(){
		var ths = $("#all_discount");
		var val = $("#all_discount").val();
		
		// 校验折扣
		var reg = /^(?:1|[1-9][0-9]?|100)$/;
		if (!reg.test(val)) {
			$("#all_discount").next().text("请输入折扣,1~100的整数!").css({"color":"#ff0000","font-weight":"bold"});
			$("#all_discount").css("border", "1px solid #ff0000").focus().select();
			return;
		}
		else{
			$("#all_discount").next().text("").removeAttr("style");
			$("#all_discount").removeAttr("style");
		}
		
		//收银员折扣检查放提交中
	});
	
	$("#btnShiftRecordSearch").click(function(){
		$("#searchShiftRecordModal").one("shown.bs.modal",initShiftRecordModal);
		$('#searchShiftRecordModal').modal('show');
	})
});
// ###################################################################################
// ################################# 以下是通用的方法 ##################################
// ###################################################################################

/**
 *  数字格式化通用方法 added by fandy AT 2016-06-10
 *  
 * @param val 需要格式化的数值
 * @param precision 精度,即小数点保留位数
 * @param roundtype 最后一位取值方式,ROUND为四舍五入,CEIL为上整,FLOOR为选择后面位数
 * @param zeroFixed 补零,是否前后补零(默认不补零),true补零,false不补零, 如保留两位小数,补零时 .3 >0.30 
 * @return result 返回值 字符型 
 * 
 */

function fmtNumber(val, precision, roundType, zeroFixed){
  //数字校验
  //isNaN(x):如果 x 是特殊的非数字值 NaN（或者能被转换为这样的值），返回的值就是 true。如果 x 是其他值,则返回 false。
  if(isNaN(val)){
    console.log(val+" 不是一个数字");
    val = 0;//非数字的,设为0
  } 

  var result = Number(val);

  //处理取值方式与精度,处理后是数字型
  if (roundType == 'CEIL') {
    with (Math) {
      result = ceil(val * pow(10, precision)) / pow(10, precision);
    }
  } else if (roundType == 'FLOOR') {
    with (Math) {
      result = floor(val * pow(10, precision)) / pow(10, precision);
    }
  } else {// cRound == 'ROUND',defualt
    with (Math) {
      result = round(val * pow(10, precision)) / pow(10, precision);
    }
  }
  //console.log(result, "result type:", typeof result);

  //处理补零
  if(zeroFixed){
    console.log("Fix 0");
    result = result.toFixed(precision);//toFixed后会变成String类型,FIXME:必须是数字型
    //console.log(result, "after fix0, result type:", typeof result);
  }
  else{
    result = result.toString();
  }

  //console.log("result type:", typeof result);

  return result;
}


//校验不通过时设置错误信息提醒,并改变STYLE
function setErrorStyle(obj,errText,clearVal){
	if(clearVal)
		$(obj).val('');
	
	$(obj).closest(".form-group").addClass("has-error");
	$(obj).css({"color":"red","font-weight":"bold"});
	$(obj).next().addClass("help-block").text(errText);
	$(obj).focus().select();
}

function setSuccessStyle(obj){
	$(obj).closest(".form-group").removeClass("has-error").addClass("has-success");
	$(obj).removeAttr("style");
	$(obj).next().text("");
}

function removeStyle(obj){
	$(obj).closest(".form-group").removeClass("has-error").removeClass("has-success");
	$(obj).removeAttr("style");
	$(obj).next().text("");
	$(obj).val('');
}


//对Date的扩展，将 Date 转化为指定格式的String
//月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
//年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
//例子：
//(new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
//(new Date()).Format("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function(fmt) { // author: meizz
	var o = {
		"M+" : this.getMonth() + 1, // 月份
		"d+" : this.getDate(), // 日
		"h+" : this.getHours(), // 小时
		"m+" : this.getMinutes(), // 分
		"s+" : this.getSeconds(), // 秒
		"q+" : Math.floor((this.getMonth() + 3) / 3), // 季度
		"S" : this.getMilliseconds()
	// 毫秒
	};
	if (/(y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for ( var k in o)
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
}

//日期格式化,date为日期,fmt为格式,转出string型,如果有"/"转换为"-",苹果系统下不支持"-",added by fandy At 2015-10-19
function parseDate(date,fmt){
	var dateStr = (date.Format(fmt)).toString();
	if(dateStr.indexOf("/")>0)
		return dateStr.replace(/\//g,"-");//"/"转换为"-"
	else
		return dateStr;
}

function alert_pay(msg){
	$('#checkout_error_msg').text(msg);
	$('#checkout_error').show();
	//收银时需要密码时的余额不足提示 ADD BY CPQ
	$('#checkout_checkpassword_error_msg').text(msg);
	$("#checkout_checkpassword_error").show();
}

function alert_pay_for_on_account(msg){
	$("#on_account_msg").text(msg);
	$("#onAccountModal").modal("show");
}


function rawPrintReceipt(msgBuff){
	//MODIFY BY CPQ_PAGE
	var print_json=JSON.parse(window.localStorage.getItem("PRINTER_RCP"));
	if(!isValidBase64(print_json["header_logo"])){
		print_json["header_logo"] = "";
	}
	//MODIFY BY CPQ_PAGE END
	
	/*
	 * 76小票时(76小票只有210个像素点，宽高都不能超过200
	 * ，保存的图片最大为360*360，图片宽或高超过200时，按200/360缩放)
	 * 缩放图片（logo和二维码）ADD BY CPQ 20161118
	 */
	if(print_json.receipt_template.width == 76){
		if(isValidBase64(print_json["header_logo"])){
			var min_header_logo = localStorage.getItem("MIN_HEADER_LOGO");
			if(!isValidBase64(min_header_logo)){
				$("#min_logo").attr("src",print_json["header_logo"]);
				min_header_logo = resizeImage($("#min_logo")[0],200, 200/360);
				localStorage.setItem("MIN_HEADER_LOGO",min_header_logo);
			}
			print_json["header_logo"] = min_header_logo
		}
		
		if(isValidBase64(print_json["QR_code"])){
			var min_QR_code = localStorage.getItem("MIN_QR_CODE");
			if(!isValidBase64(min_QR_code)){
				$("#min_QR_code").attr("src",print_json["QR_code"]);
				
				min_QR_code = resizeImage($("#min_QR_code")[0],200, 200/360);
				localStorage.setItem("MIN_QR_CODE",min_QR_code);
			}
			print_json["QR_code"] = min_QR_code;
		}
	}
	
	var json=JSON.parse(window.localStorage.getItem("receiptPrintJsonStr"));
	pj(print_json);
	var target=$.extend({},print_json,json);
	//console.dir(target);
	isNotPark = true;
	
	//20180316::对钱箱进行添加 Add by dph
	var cPopCashBox = localStorage.getItem("popCashBox");;
	if(cPopCashBox == "1" && $("#_payment").val().indexOf('CASH')>-1){
		msgBuff = ['\x1b\x70\x00\x10\x99\x1b\x40\x0d\x0a'].concat(msgBuff);
	}
	
	pc.print(print_json,msgBuff);
}
//ADD BY CPQ_PAGE 安卓打印
function androidPrintReceipt(msgBuff){
	console.log("----------------- Android打印   @doPrint() ---------------");
	var print_json=JSON.parse(window.localStorage.getItem("PRINTER_RCP"));
	if(!isValidBase64(print_json["header_logo"])){
		print_json["header_logo"] = "";
	}
	var json=JSON.parse(window.localStorage.getItem("receiptPrintJsonStr"));
	pj(print_json);
	var target=$.extend({},print_json,json);
	
	//20180316::对钱箱进行添加 Add by dph
	var cPopCashBox = localStorage.getItem("popCashBox");;
	if(cPopCashBox == "1" && $("#_payment").val().indexOf('CASH')>-1){
		msgBuff = ['\x1b\x70\x00\x10\x99\x1b\x40\x0d\x0a'].concat(msgBuff);
	}

	//20161111:增加打印数据格式 Add by Dingph
	target["print_data"] = msgBuff.join("");
	//20161111:增加打印数据格式 Add by Dingph

	var receiptJsonStr = JSON.stringify(target);
	//alert(receiptJsonStr)
	//输出JSON

	//20161111:增加打印数据格式 Modify by Dingph
	//AndroidPrinter.print(receiptJsonStr);
    PBAPrinter.print(receiptJsonStr);
    //20161111:增加打印数据格式 Modify by Dingph
}

//20180424:增加新框架打印（Android移植过来后，也可直接使用，暂时只有IOS使用）
function mobilePrintReceipt(msgBuff) {
	console.log("----------------- Android打印   @doPrint() ---------------");
	var print_json=JSON.parse(window.localStorage.getItem("PRINTER_RCP"));
	if(!isValidBase64(print_json["header_logo"])){
		print_json["header_logo"] = "";
	}
	var json=JSON.parse(window.localStorage.getItem("receiptPrintJsonStr"));
	pj(print_json);
	var target=$.extend({},print_json,json);
	
	//20180316::对钱箱进行添加 Add by dph
	var cPopCashBox = localStorage.getItem("popCashBox");;
	if(cPopCashBox == "1" && $("#_payment").val().indexOf('CASH')>-1){
		msgBuff = ['\x1b\x70\x00\x10\x99\x1b\x40\x0d\x0a'].concat(msgBuff);
	}

	var settings = target;
	var printData = msgBuff.join(""),
	logo = settings['header_logo'].replace('data:image/png;base64,', ''),
	qr = settings['QR_code'].replace('data:image/png;base64,', '');
	printData = printData
	.replace('{logo}', !logo ? '' : '<C><BASE64>' + logo + '</BASE64></C>')
	.replace('{qr_code}', !qr ? '' :'<C><BASE64>' + qr + '</BASE64></C>');
	if(settings['printer']['paper_cut']) {
		printData += '<CUT><BR>'
	}
	var printerInterface = settings['printer']['default_printer_ios'];
	var printer;
	if('wifi' == printerInterface) {
		printer = settings['printer']['ip'];
	}
	else if('bt' == printerInterface) {
		printer = settings['printer']['mac'];
	}
	var param = {
			taskList : [
				{
		            printerAddr: printer,
		            content: printData, 
		            keepAlive:true,
		            copyNum: settings['printer']['print_copy']
		        }
			]
	};

	if(printer)
		api.require('posPrinter').printOnSpecifiedPrinters(param);
}

//ADD BY CPQ_PAGE 判断LOGO是否有效的BASE64
function isValidBase64(logo){
	if(!logo || logo.indexOf("base64") == -1 || logo.length <= 10){
		return false;
	}
	return true;
}
function pj(pjson){
	pjson['header_text']=pjson['header_text'].replace(/[^\\](\\n)/g,'\n');
	pjson['footer_text']=pjson['footer_text'].replace(/[^\\](\\n)/g,'\n');
}

function popCashBox(){
	console.log("弹出钱箱");
	if (pc){
		//ADD BY CPQ_PAGE
		var rcpJson = window.localStorage.getItem("PRINTER_RCP");
		var json = null;
		if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
			json = JSON.parse(rcpJson);
		}
		if(!json || !json.printer
			|| (browser.platform.win && !json.printer.default_printer)
			|| (browser.platform.osx && !json.printer.default_printer_mac)) {
			return;
		}
		//ADD BY CPQ_PAGE END
		pc.popCashBox(json);
	}

	//20170804:Add by dph
	else if(browser.versions.mobileAndroid && PBAPrinter.popCashBox) {
		var rcpJson = window.localStorage.getItem("PRINTER_RCP");
		var json = null;
		if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
			json = JSON.parse(rcpJson);
		}
		if(!json || !json.printer || !json.printer.default_printer_android) return;
		PBAPrinter.popCashBox(rcpJson);
	}
	//20170804:Add by dph
	
	else if(browser.versions.mobileIos) {
		var rcpJson = window.localStorage.getItem("PRINTER_RCP");
		var json = null;
		if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
			json = JSON.parse(rcpJson);
		}
		if(!json || !json.printer || !json.printer.default_printer_ios) return;
		var printer;
		if('wifi' == json.printer.default_printer_ios) {
			printer = json['printer']['ip'];
		}
		else if('bt' == json.printer.default_printer_ios) {
			printer = json['printer']['mac'];
		}
		if(printer)
			api.require('posPrinter').printOnSpecifiedPrinters({
				taskList : [
					{
			            printerAddr: printer,
			            content: ['\x1b\x70\x00\x10\x99\x1b\x40\x0d\x0a'].join(""), 
			            keepAlive:true,
			            copyNum: 1
			        }
				]
			});
	}
	
	else 
		$("#blank_receipt").printArea();
}

function removeCR(src){
	src = src || '';
	return src.replace(/[^\\](\\n)/g,'<br/>');
}

//生成随机数
function getRandomNumber(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}

function isSafari(){
	return (navigator.userAgent.indexOf("Safari") > -1);
}

//显示同码商品 ADD BY CPQ
function showProductsPre(have_cust_prop,barcode,id){
	//console.log(have_cust_prop,barcode,id,subtotal)
	if(have_cust_prop == 1){
		showProducts(barcode);
	}else{
		addCart(id, 1);
	}
}


//商品附加属性矩阵 ADD BY CPQ
function showProducts(barcode){
	getProductsByBarcode(barcode,function(items){
		if(items.length == 1){
			addCart(items[0].product_id, 1);
			return;
		}
		if(0 === items.length) {
			alert("没有找到与 "+barcode+" 相关或有多个相同货号的商品，请在后台进行确认。", () => {
				$("#bar_code").val('');
			});
			return;
		}
		$("#cp_name").text(items[0].product_name);
		$("#cp_barcode").text(items[0].barcode);
		$("#prop_table").empty();
		var products = [];//商品价格
		var props1 = [];//属性1
		var props2 = [];//属性2
		var stockArr = [];//库存,added by fandy AT 2016-01-22
		for(var k in items){
			var item = items[k];
			//var cust_props = item.cust_props.split(",");
			var cust_props = item.cust_props!=null?item.cust_props.split(","):[];//防止同码无颜色尺码的商品发生异常
			var len = cust_props.length;
			switch(len){
				case 1:
					if(!products[cust_props[0]]){
						products[cust_props[0]] = [];
					}
					products[cust_props[0]].push(item.price);
					products[cust_props[0]].push(item.product_id);
					
					if(!props1[cust_props[0]]){
						props1[cust_props[0]] = cust_props[0];
					}
					
					stockArr[cust_props[0]] = item.stock+""+item.unit;
					break;
				case 2:
					if(!products[cust_props[0]] ){
						products[cust_props[0]] = [];
						stockArr[cust_props[0]] = [];
					}
					if(!products[cust_props[0]][cust_props[1]]){
						products[cust_props[0]][cust_props[1]] = [];
						stockArr[cust_props[0]][cust_props[1]] = [];
					}
					products[cust_props[0]][cust_props[1]].push(item.price);
					products[cust_props[0]][cust_props[1]].push(item.product_id);
					stockArr[cust_props[0]][cust_props[1]].push(item.stock+""+item.unit);
					
					if(!props1[cust_props[0]]){
						props1[cust_props[0]] = cust_props[0];
					}
					if(!props2[cust_props[1]]){
						props2[cust_props[1]] = cust_props[1];
					}
					
					
					break;
			}
		}
		var tableHtml = "<thead><tr >";
		if(!$.isEmptyObject(props2)){
			tableHtml += "<th class='fixedTitleRow'>&nbsp</th>"
			for(var k in props2){
				tableHtml += "<th class='fixedTitleRow' style='text-align:center;'>"+props2[k]+"</th>"
			}
			tableHtml += "</tr></thead>";
			for(var k in props1){
				tableHtml += "<tr>";
				tableHtml += "<th class='fixedTitleColumn' style='text-align:center;'>"+ props1[k] +"</th>";
				for(var j in props2){
					if(products[k][j]){
						//console.log("2维价格=",products[k][j][0]);
						tableHtml += '<td class="no-padding">'
						+ '<a class="btn btn-primary w-full" '
						+'onclick="addCart('+products[k][j][1]+', 1);$(\'#custPropModal\').modal(\'hide\') ">￥'
						+ products[k][j][0]
						+'('+stockArr[k][j][0]+')'
						+ '</a>'
						+ '</td>';
					}else{
						tableHtml += '<td class="active">&nbsp;</td>';
					}
				}
				tableHtml += "</tr>";
			}
		}else{
			for(var k in props1){
				tableHtml += "<th style='text-align:center;'>"+props1[k]+"</th>"
			}
			tableHtml += "</tr></thead>";
			tableHtml += "<tr>";
			for(var k in props1){
				if(products[k]){
					//console.log("1维价格=",products[k][0]);
					tableHtml += '<td class="no-padding">'
					+ '<a class="btn btn-primary w-full" '
					+'onclick="addCart('+products[k][1]+', 1);$(\'#custPropModal\').modal(\'hide\') ">￥'
					+ products[k][0]
					+'('+stockArr[k]+')'
					+ '</a>'
					+ '</td>';
				}else{
					tableHtml += '<td class="active">&nbsp;</td>';
				}
			}
			tableHtml += "</tr>";
		}
		$("#prop_table").append(tableHtml);
		$("#custPropModal").modal("show");
		//固定第一行及第一列
		$("#prop_table").parent().scroll(function(){
			$(".fixedTitleRow").css("top",$("#prop_table").parent().scrollTop());
			$(".fixedTitleColumn").css("left",$("#prop_table").parent().scrollLeft());
		})
	})
}



/**
 * 根据条码从本地数据库取得商品 ADD BY CPQ
 * 
 * @param barcode
 * @param callback
 */
function getProductsByBarcode(barcode,callback){
	//var db = openDatabase('QUICK_POS', '1.0', 'QuickPOS DB', 5 * 1024 * 1024);
	var data = [];
	db.transaction(function (context) {
		var companyId = getSetting("cId");
		var outletId = getSetting("oId");
		context.executeSql(
				"SELECT p.*, s.qty as stock  FROM PRODUCTS p "
				+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
				+" WHERE p.company_id = ? AND p.outlet_id = ? AND p.barcode = ? AND p.active = 'ON' AND p.del_flag = 0  AND p.scale_flag <> 1 ", 
		[companyId,outletId,barcode.toUpperCase()], 
		function (context, results) {
			for(var i = 0; i < results.rows.length; i++){
				var line = $.extend({}, results.rows.item(i));
				if(line.stock==null) line.stock = 0;
				data.push(line);
			}
			
			if (typeof(callback) == 'function')
				callback(data);
		},
		function (context, error) {
			console.log('查询失败: ' + error.message);
		});
	});
}


//根据定制内容打印小票 ADD BY CPQ
function setCustomedPrint(saleorderdetails,receiptSetting){
	var customSettings = receiptSetting.customSettings;
	if(!customSettings || !customSettings.customed){
		customSettings = gen58Template1();
	}
	//重置receipt_body
	$("#receipt_print_area_new .receipt_body_new").empty();
	//载入desc,receiptbody
	var desc = saleorderdetails.receipt_desc;
	var payment = desc.payment;//付款方式
	
	var msgBuff = ["\x1b\x40"];
	
	var template_type = receiptSetting.receipt_template.template;
	var receiptWidth = receiptSetting.receipt_template.width;
	var max_len = getLineLength(receiptWidth);
	
	var PAYMENT_MAP = customSettings.paymentName;
	if(!PAYMENT_MAP){
		PAYMENT_MAP = PAYMENT_ARRAY;
	}
	
	var currency = "";
	if(receiptSetting.currencySymbol && receiptSetting.showCurrencySymbol){
		currency = receiptSetting.currencySymbol;
		if(currency == "other"){
			currency = receiptSetting.otherCurrency;
		}
	}

	//SPRT lines处理
	var isSprt = receiptWidth==99 && !customSettings.customed;
	if(isSprt){
		customSettings.lines = customSettings.sprtlines;
		customSettings.customerTitle = customSettings.sprtHeaderTitle;
	}

	// 西文倍高
	var startCommandDH = "\x1b\x21\x10";
	var endCommandDH = "\x1b\x21\x00";
	// 中文倍高倍宽
	var startCommandCN = "\x1c\x57\x01";
	var endCommandCN = "\x1c\x57\x00";

	var placeholderIndex = -1, index = -1, totalIndex = customSettings.lines.length - 1;
	$.each(customSettings.lines,function(i,line){
		var col_len = line.length;
		var has_value = false;
		var ii = i;
		
		var startCommand = receiptWidth == 76 ? "\x1b\x21\x31\n\x1c\x57\x01" : "\x1b\x21\x30";
		var endCommand = receiptWidth == 76 ? "\x1b\x21\x01\n\x1c\x57\x00" : "\x1b\x21\x00";
		
		$.each(line,function(j,col){
			var title = col.title + ":";
			var field = col.field;
			if(field == "logo"){
				if(isValidBase64(receiptSetting.header_logo)) {
					msgBuff.push("{logo}");
					has_value = true;
				}
			}else if(field == "outlet_name"){
				var outlet_name = receiptSetting.outlet_name || getSetting("oName");
				//大字打印店铺名 ADD BY CPQ
				var bigOutletName = true;
				if(typeof receiptSetting.bigOutletName != "undefined") bigOutletName = receiptSetting.bigOutletName;
				
				if(bigOutletName){
					msgBuff.push(startCommand+genCenter(outlet_name,receiptWidth,true)+endCommand);
				}else{
					msgBuff.push(genCenter(outlet_name,receiptWidth));
				}
				has_value = true;
			}else if(field == "header_text"){
				var header_text = receiptSetting.header_text;
				header_text = splitText2Lines(header_text,receiptWidth);
				
				var str = header_text.split("\n");
				for(var i = 0; i < str.length; i++){
					msgBuff.push(genCenter(str[i],receiptWidth)+(i == str.length - 1 ? "" : "\n"));
				}
				has_value = true;
			}else if(field == "footer_text"){
				var footer_text = receiptSetting.footer_text;
				footer_text = splitText2Lines(footer_text,receiptWidth);
				
				str = footer_text.split("\n");
				for(var i = 0; i < str.length; i++){
//					msgBuff.push(str[i]);
//					
//					genWhiteSpace(msgBuff,max_len - getStringLength(str[i]))
//					if(i < str.length - 1){
//						msgBuff.push("\n");
//					}
					//以上代码会造成页脚跳行,原因getStringLength()计算长度不准确，全角标点符号会算成1个字节，这样就会补上一个空格,by fandy AT 20170403
					msgBuff.push(str[i]+(i == str.length - 1 ? "" : "\n"));
				}
				
				//插入广告 ADD BY CPQ
				if(getSetting("free") == 1){
					advertisement = splitText2Lines(advertisement,receiptWidth);
					
					msgBuff.push("\n\n");
					
					str = advertisement.split("\n");
					for(var i = 0; i < str.length; i++){
						msgBuff.push(genCenter(str[i],receiptWidth)+(i == str.length - 1 ? "" : "\n"));
					}
				}
				
				has_value = true;
			}else if(field == "qr_code"){
				if(isValidBase64(receiptSetting.QR_code)) {
					msgBuff.push("{qr_code}");
					has_value = true;
				}
			}else if(field == "payment_title"){//"支付方式"，固定文本，SPRT专用
				msgBuff.push(startCommandCN + title + endCommandCN+ "\n");
			}else if(field == "payment_detail"){
				//注:挂单没有付款方式
				if (isNotPark) {
					//销售单付款记录 START
					if(payment!=null && payment!='' && payment !='undefined'){
						//取得付款记录
						var payrecords = saleorderdetails.payrecords;
						for(var i = 0; i < payrecords.length; i++){
							var paymentrecord = payrecords[i];
							var _payment = PAYMENT_MAP[paymentrecord.payment];
							var amount = paymentrecord.amount;
							
							if(receiptWidth==99){//SPRT
								msgBuff.push(startCommandCN + _payment + endCommandCN);
								genWhiteSpace(msgBuff,max_len - getStringLength(_payment)*2 - (amount+"").length);
								msgBuff.push(startCommandDH + amount + endCommandDH + (i == payrecords.length - 1 ? "" : "\n"));
							}
							else{
								msgBuff.push(" " + _payment);
								genWhiteSpace(msgBuff,max_len - getStringLength(_payment) - 1 - (amount+"").length);
								msgBuff.push(amount + (i == payrecords.length - 1 ? "" : "\n"));
							}
						}
						has_value = true;
					}
					//销售单付款记录 END
				}
			}else if(field == "product_list"){
				var items = saleorderdetails.receipt_body;
				var titleMap = customSettings.productTitle;
				
				printProductInfo(msgBuff,items,titleMap,template_type);
				
				has_value = true;
			}else if(field == "customer_info"){
				//会员信息
				var customer = saleorderdetails.receipt_customer;
				if(customer!=null){
					var customer_code = customer.customer_code;
					var balance = customer.customer_balance;
					var customer_point = customer.customer_point;
					var total_points = customer.total_points;
					var customer_pay = customer.customer_pay;
					var used_times = customer.used_times;
					var balance_times = customer.times;
					
					var titleMap = customSettings.customerTitle;
					
					msgBuff.push(titleMap.customer_code+":");
					var titleLen = getStringLength(titleMap.customer_code+":");
					genWhiteSpace(msgBuff,max_len - titleLen - (customer_code + "").length);
					msgBuff.push(customer_code);
					
					printCustomerInfo(titleMap.balance,balance,titleMap.point,customer_point,receiptWidth,msgBuff);
					printCustomerInfo(titleMap.customer_pay,customer_pay,titleMap.total_points,total_points,receiptWidth,msgBuff);
					
					if($("#isTimeCard").val() == "1"){
						printCustomerInfo(titleMap.balance_times,balance_times,titleMap.used_times,used_times,receiptWidth,msgBuff);
					}
					has_value = true;
				}
			}
			// SPRT start
			else if(isSprt && field == 'sprt_customer_name'){
				var titleMap = customSettings.customerTitle;//头部字段定义
				var customer = saleorderdetails.receipt_customer;
				// if(customer!=null){
					var _customerName = titleMap.sprt_customer_name+":"
					+(customer!=null?customer.customer_name:"");
					msgBuff.push(_customerName);
					genWhiteSpace(msgBuff,32-getStringLength(_customerName));//32为半行字数
				// }
			}
			else if(isSprt && field == 'sprt_sale_order_no'){
				var titleMap = customSettings.customerTitle;
				var _saleorder = saleorderdetails.receipt_desc;// 订单信息
				if(_saleorder!=null){
					var _text = titleMap.sprt_sale_order_no+":"+_saleorder.sale_order_no;
					msgBuff.push(_text);
					genWhiteSpace(msgBuff,32-getStringLength(_text));
					msgBuff.push("\n");//换行
				}
			}
			else if(isSprt && field == 'sprt_customer_code'){
				var titleMap = customSettings.customerTitle;
				var customer = saleorderdetails.receipt_customer;
				// if(customer!=null){
					var _customerCode = titleMap.sprt_customer_code+":"
					+(customer!=null?customer.customer_code:"");
					msgBuff.push(_customerCode);
					genWhiteSpace(msgBuff,32-getStringLength(_customerCode));
				// }
			}
			else if(isSprt && field == 'sprt_sale_date'){
				var titleMap = customSettings.customerTitle;
				var _saleorder = saleorderdetails.receipt_desc;
				if(_saleorder!=null){
					var _text = titleMap.sprt_sale_date+":"+_saleorder.sale_date;
					msgBuff.push(_text);
					genWhiteSpace(msgBuff,32-getStringLength(_text));
					msgBuff.push("\n");
				}
			}
			else if(isSprt && field == 'sprt_customer_phone'){
				var titleMap = customSettings.customerTitle;
				var customer = saleorderdetails.receipt_customer;
				// if(customer!=null){
					var _text = titleMap.sprt_customer_phone+":"
					+(customer!=null?customer.customer_phone:"");
					msgBuff.push(_text);
					genWhiteSpace(msgBuff,32-getStringLength(_text));
				// }
			}
			else if(isSprt && field == 'sprt_guide'){
				var titleMap = customSettings.customerTitle;
				var _saleorder = saleorderdetails.receipt_desc;
				if(_saleorder!=null){
					var _text = titleMap.sprt_guide+":"+_saleorder.guide;
					msgBuff.push(_text);
					genWhiteSpace(msgBuff,32-getStringLength(_text));
					msgBuff.push("\n");
				}
			}
			else if(isSprt && field == 'sprt_order_point'){//也可放在订单信息里
				var titleMap = customSettings.customerTitle;
				var customer = saleorderdetails.receipt_customer;
				// if(customer!=null){
					var _text = titleMap.sprt_order_point+":"
					+(customer!=null?customer.total_points:"");
					msgBuff.push(_text);
					genWhiteSpace(msgBuff,32-getStringLength(_text));
				// }
			}
			else if(isSprt && field == 'sprt_customer_point'){
				var titleMap = customSettings.customerTitle;
				var customer = saleorderdetails.receipt_customer;
				// if(customer!=null){
					var _text = titleMap.sprt_customer_point+":"
					+(customer!=null?customer.customer_point:"");
					msgBuff.push(_text);
					genWhiteSpace(msgBuff,32-getStringLength(_text));
					msgBuff.push("\n");
				// }
			}
			else if(isSprt && field == 'sprt_customer_pay'){
				var titleMap = customSettings.customerTitle;
				var customer = saleorderdetails.receipt_customer;
				// if(customer!=null){
					var _text = titleMap.sprt_customer_pay+":"
					+(customer!=null?customer.customer_pay:"");
					msgBuff.push(_text);
					genWhiteSpace(msgBuff,32-getStringLength(_text));
				// }
			}
			else if(isSprt && field == 'sprt_customer_balance'){
				var titleMap = customSettings.customerTitle;
				var customer = saleorderdetails.receipt_customer;
				// if(customer!=null){
					var _text = titleMap.sprt_customer_balance+":"
					+(customer!=null?customer.customer_balance:"");
					msgBuff.push(_text);
					genWhiteSpace(msgBuff,32-getStringLength(_text));
					msgBuff.push("\n");
				// }
			}
			// SPRT end
			else if(field == "space_line"){
				msgBuff.push(" ");
				has_value = true;
				if(-1 == index || 1 != ii - index) {
					placeholderIndex = msgBuff.length + 1;
				}
				index = ii;
			}else if(field == "separator"){
				if(isSprt){//SPRT分割线为直线
					for(var i = 0; i < max_len/2; i++){
						msgBuff.push("─");
					}
				}
				else{
					for(var i = 0; i < max_len; i++){
						msgBuff.push("-");
					}
				}
				has_value = true;
			}else if(field == "totalPrice"){// 应收金额（合计）
				var value = currency + desc["total_amount"];
				var totalQty = desc['total_qty'];
				var _totalListPrice = currency + desc["total_listprice"];//原价合计，SPRT专用
				printTotalPrice(msgBuff,title,totalQty,value,receiptWidth,template_type,_totalListPrice);
				has_value = true;
			}else if(field == "remark"){
				var remark =  saleorderdetails.receipt_remark;
				if(remark){
					msgBuff.push(title);
					msgBuff.push(remark);
					genWhiteSpace(msgBuff,max_len-getStringLength(title+remark));
				}
				has_value = true;
			}else if(field == "seq"){
				if(getSetting("seq_enabled") == 1){
					var num = getSetting("seq_num") || 0;
					var cateringSeq = getSetting("seq_suffix") || "";
					var seq = desc.sequence;
					
					var seqLen = (seq+"").length
					if(num > seqLen){
						for(var i = 0; i < num - seqLen; i++){
							cateringSeq += "0";
						}
					}
					
					cateringSeq += seq;
					msgBuff.push(startCommand+genCenter(title+cateringSeq,receiptWidth,true)+endCommand);
					
					has_value = true;
				}
			}else{
				var realpay = saleorderdetails.real_pay;
				var value = desc[field];
				
				if(field == "real_pay"){
					value = currency + realpay;
				}else if(field == "changex"){
					value =  currency + value;
				}else if(field == "payment"){
					value = (payment!=null && payment!='' && payment !='undefined'? PAYMENT_MAP[payment] : "");
				}else if(field == "preferential_amount"){// 优惠金额
					value = currency + getPreferentialAmount(saleorderdetails.receipt_body);
				}else if(field == "desk_no"){
					//桌号关闭时，不打印桌号
					if(getSetting("desk_no_enabled") == 0){
						return;
					}
				}
				
				switch(col_len){
				case 1:
					msgBuff.push(title);
					genWhiteSpace(msgBuff,max_len - getStringLength(title) - getStringLength(value+""));
					msgBuff.push(value);
					break;
				case 2:
					msgBuff.push(title+value);
					if(j == 0){
						var next_ele = line[j+1];
						var next_field = next_ele.field;
						var next_title = next_ele.title + ":";
						var next_value = desc[next_field];
						if(next_field == "real_pay"){
							next_value = realpay;
						}else if(next_field == "payment"){
							next_value = (payment!=null && payment!='' && payment !='undefined'? PAYMENT_MAP[payment] : "");
						}
						genWhiteSpace(msgBuff,max_len - getStringLength(title) - getStringLength(value+"") 
								- getStringLength(next_title) - getStringLength(next_value+""));
					}
					break;
				}
				has_value = true;
			}
		});
		
		if(ii == totalIndex && index != totalIndex) {
			placeholderIndex = -1;
		}
		
		if(has_value){//有输出才换行
			msgBuff.push("\n");
		}
	});
	
	if(rePrintFlag){//重打小票时，末尾加上【重打小票】
		if(-1 == placeholderIndex)
			msgBuff.push(genCenter("【重打小票】",receiptWidth));
		else {
			msgBuff.splice(placeholderIndex, 0, genCenter("【重打小票】",receiptWidth));
		}
		msgBuff.push("\r\n");
		rePrintFlag = false;
	}
	
	msgBuff.push("\x1b\x40\n\n\n\n");
	
	return msgBuff;
}

//销售历史退货 ADD BY CPQ
function showRefundModal(){
	var saleOrderNo = $("#sales_history tr.currentRow td:first").text();
	
	//检查是否有其它销售单在退货中
	if(checkIfHasOtherRefund(saleOrderNo)){
		return;
	}
	
	initRefund();
	$("#refundModal #receipt_no").val(saleOrderNo);
	$("#refundModal #receipt_no").next("div").find("span").click();
	$("#salesHistoryModal").modal("hide");
	$("#refundModal").modal("show");
	//退货独立 BY CPQ
	//location.href = "refund.html?online="+(online ? 1 : 0)+"&receipt_no="+saleOrderNo;
}

//分类库存列表初始化 ADD BY CPQ
//修改为分页取得列表 MODIFY BY CPQ 20170624
function initCategoryList(){
	var list_group = $("#searchModal").find(".list-group");
	var first_item = list_group.find("a:first").clone(true);
	list_group.empty().append(first_item);
	
	db.transaction(function (context) {
		context.executeSql(
				"SELECT SUM(s.qty) as qty FROM " + //XXX:如果s.qty==null怎么处理,会自动变0吗?
				"PRODUCTS p "
				+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
				+" WHERE p.company_id=? AND p.outlet_id=? AND p.del_flag=0 ", [companyId,outletId], 
			function (context, results) {
			var item = results.rows.item(0) || results.rows[0] || 0;
			var sum = item.qty;
			$("#all_cat_num").text(doDecimal2(sum));
		},
		function (context, error) {
			console.log('查询失败: ' + error.message);
		})
	})
	
	var page = 0;
	getCategoryStock(page);
	
	//滚动到底部后加载下一页数据
	$("#cat_list_cardBody").unbind("scroll");
	$("#cat_list_cardBody").scroll(function(){
		var contentHeight = $(this).children(".list-group").height();
		var height = $(this).height();
		if($(this).scrollTop() >= contentHeight - height){
			getCategoryStock(++page);
		}
	})
}

//分页,每页15条,取得商品库存，按类别分组
function getCategoryStock(page){
	db.transaction(function (context) {
		context.executeSql(
				"SELECT p.category_id as cat_id,p.category_name as name,SUM(s.qty) as qty FROM " + //XXX:如果s.qty==null怎么处理,会自动变0吗?
				"PRODUCTS p "
				+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
				+" WHERE p.company_id=? AND p.outlet_id=? AND p.del_flag=0 " +
				"GROUP BY p.category_id ORDER BY p.category_id LIMIT ?,15", [companyId,outletId,page*15], 
			function (context, results) {
			var _rows = results.rows;
			
			if(_rows.length == 0){//已经没有数据了，解除事件
				$("#cat_list_cardBody").unbind("scroll");
				return;
			}
			
//			var sum = 0;
			var _html = "";
			for(var i = 0; i < _rows.length; i++){
				var item = _rows[i] || _rows.item(i);
//				sum += item.qty;
				
				_html += '<a onclick="searchProductByCategoryPre('+item.cat_id+',this)" class="list-group-item b-l-5x">' +
		          '<span class="pull-right text-primary">'+doDecimal2(item.qty)+'</span>'+item.name+'</a>';
			}
			$("#searchModal").find(".list-group").append(_html);
//			$("#all_cat_num").text(doDecimal2(sum));
		},
		function (context, error) {
			console.log('查询失败: ' + error.message);
		})
	})
}

function searchProductByCategoryPre(cat_id,_this){
	$("#searchModal .list-group a.list-group-item").removeClass("active");
	$(_this).addClass("active");
	$('#search_category_id').val(cat_id);
	$("#search_type").val(1);
	goToPage4Sell(1);
}


function goToPage4Sell(pg){
	var pageCount = parseInt($("#page_count").text());
	   if(pg<=0){
		   pg = 1;
	   }else if(pg > pageCount){
		   pg = pageCount
	   }
	$("#currentPage").val(pg);
	if(pg == 1){
		$("#first_arrow,#pre_arrow").attr("class","btn btn-default disabled");
		$("#last_arrow,#next_arrow").attr("class","btn btn-primary active");
	}else if(pg == pageCount){
		$("#first_arrow,#pre_arrow").attr("class","btn btn-primary active");
		$("#last_arrow,#next_arrow").attr("class","btn btn-default disabled");
	}else{
		$("#first_arrow,#pre_arrow").attr("class","btn btn-primary active");
		$("#last_arrow,#next_arrow").attr("class","btn btn-primary active");
	}
	if($("#search_type").val() == 0){
		search($('#kw').val());
	}else{
		searchProductByCategory(parseInt($("#search_category_id").val()),null);
	}
}

// 商品与库存自适应
function reSizeMerchandiseAndInventory(){
	var themeFontSize = localStorage.getItem("theme") ? JSON.parse(localStorage.getItem("theme")).themeFontSize : "font-default";
	var productListHight = {
		'font-default':56+30+46+45+86,
		'font-big':82+30+60+45+125,
		'font-small':56+30+46+45+86,
	}
	if(window && $("#product_list_cardBody")) {
			$("#product_list_cardBody").outerHeight(window.innerHeight-productListHight[themeFontSize])
			$("#cat_list_cardBody").outerHeight($("#product_list_cardBody").outerHeight() + $("#product_list_pageCard").outerHeight());
		}
}


//按分类查询商品 ADD BY CPQ
function searchProductByCategory(cat_id){
	// 首先清空原来的结果
	$("#search_product_results_table tbody").empty();
	var sql = " FROM PRODUCTS p "
		+" LEFT JOIN STOCKS s ON p.product_id = s.product_id "
		+" WHERE p.company_id=? AND p.outlet_id=?  AND  p.del_flag=0 ";
	var params =  [companyId, outletId];
	if(cat_id){
		sql += " AND p.category_id=?";
		params.push(cat_id);
	}
	//分页查询 MODIFY BY CPQ
	var pageSize = parseInt($("#pageSize").val());
	var currentPage = parseInt($("#currentPage").val()) - 1;//从0开始计数
	var start = pageSize * currentPage;
	
	db.transaction(function(tx) {
		tx.executeSql("SELECT COUNT(*) as item_count " + sql, params,function(count_tx,count_results){
			var _count = (count_results.rows[0] || count_results.rows.item(0)).item_count;
			var pageCount = _count % pageSize != 0 ? Math.floor(_count / pageSize) + 1 : _count / pageSize;
			
			$("#page_count").text(pageCount);
			$("#_count").text(_count);
			
			if(pageCount == 1){//只有一页时，不能翻页
				$("#first_arrow,#pre_arrow").attr("class","btn btn-default disabled");
				$("#last_arrow,#next_arrow").attr("class","btn btn-default disabled");
			}
			
			params.push(start);
			params.push(pageSize);
			tx.executeSql("SELECT  p.*, s.qty as stock " + sql + "limit ?,?", params, function(tx, results) {
				console.log(results);
				var len = results.rows.length;
				if (results.rows.length > 0) {
					$("#search_product_results_table").show();
					$("#gpCopies_select_all").prop("checked",false);
					// 搜索结果装到表格里
					for ( var i = 0; i < results.rows.length; i++) {
						var p = $.extend({}, results.rows.item(i));
						if(!p.stock || p.stock=='null') p.stock = 0;
						
						var custProps = custPropFormatted(p.cust_props, false);
						var nowFontClass = JSON.parse(localStorage.getItem("theme"))? JSON.parse(localStorage.getItem("theme")).themeFontSize : "font-default"
						var gpLabelNumStyle = {
							"font-big":"4em",
							"font-default":"6em",
							"font-small":"7em"
						}
						var row_tr = "<tr>";
						if(0 >= $('#lbl_temp').parents('div.form-group:hidden').length) {
							row_tr += "<td style='text-align:center;'><label class='md-check'>"
								+ "<input type='checkbox' class='gp_p_id' value='"+p.product_id+"'><i class='indigo'></i></label></td>"
								+ "<td><div class='form-inline' style='text-align:center;'>"
								+ "<input type='number' min='0' name='gpLabelNum' class='form-control' value='"+(p.stock <= 0 ? 1 : p.stock)+"' style='max-width:"+ gpLabelNumStyle[nowFontClass] +  "' />"
								+ "</div></td>";
						}
						row_tr += "<td>" + (i + 1) + "</td><td>" 
							+ p.product_name + "</td><td>" 
							+ p.barcode + "</td><td>" 
							+ custProps + "</td><td>" 
							+ p.unit + "</td><td class='ellipsis-1'><span class='pull-right'>" 
							+ p.stock
							+ " <span class='fa fa-plus text-primary needonline' onclick='viewAllStocks(\""+p.barcode+"\");'></span>"
							+ "</span></td><td><span class='pull-right'>" 
							+ doDecimal(p.price) + "</span></td>"
							//+ "<td><span class='pull-right'>" 
							//+ doDecimal(p.wholesale_price) + "</span></td><td><span class='pull-right'>" 
							//+ doDecimal(p.vip_price) + "</span></td>"
						
						row_tr += "</tr>";
						$("#search_product_results_table tbody").append(row_tr);
					}
				}
	
			});
		},function(tx, error) {
			console.log('error: ' + error.message);
		});
	});
}


//查看所有店铺同码库存
function viewAllStocks(barcode){	
	var jtoken = "";//XXX : 查看所有店铺库存jtoken待完善 
	
	$.ajax({url:apiurl+"viewAllStocks",
		data:{"barcode":barcode,"jtoken":jtoken},
		type:"POST",
		dataType : "json",
		success:function(result){
			//console.log("-------- all stocks->\n"+JSON.stringify(result),result.length);
			if(result.length==0) alert("没有查询到该商品的库存,或库存全部为零.");
			else{
				
				$("#stock_results_table tbody").empty();
				for(var i=0; i<result.length; i++){
					//console.log("-------- item->"+JSON.stringify(result[i]));
					var item = result[i];
					// 添加表体
					var row_tr = "<tr><td>" 
						+ (i + 1) + "</td><td>" 
						+ item.outlet_name + "</td><td>" 
						+ item.product_name + "</td><td>" 
						+ item.barcode + "</td><td>" 
						+ (item.cust_prop!=undefined?item.cust_prop:'') + "</td><td>" 
						+ item.unit + "</td><td><span class='font-bold'>" 
						+ item.stock_qty 
						+ "</span></td></tr>";
						$("#stock_results_table tbody").append(row_tr);
				}
				
				//弹出库存分布modal
				$("#stockModal").modal("show");
				
			}
		},
		error:function(XMLHttpRequest, textStatus, errorThrown){
			console.log(textStatus + "/" + errorThrown);
			message("查询失败,请检查网络与登录状态!")
		}
	})
}



//######员工登录密码修改 ADD BY CPQ START######
function modifyUserPassword(){
	var oldPasswordInput = $("#userForm_user_old_password");
	var oldPassword = oldPasswordInput.val();
	var newPasswordInput =  $("#userForm_user_password");
	var newPassword = newPasswordInput.val();
	var confirmPasswordInput = $("#userForm_user_confirmPassword")
	var confirmPassword = confirmPasswordInput.val();
	
	if(!newPassword){
		setErrorStyle(newPasswordInput,'新密码不能为空!',false);
    	return;
	}else if(newPassword != confirmPassword){
		setSuccessStyle(newPasswordInput);
		setErrorStyle(confirmPasswordInput,'确认密码与新密码不一致!!',false);
    	return;
	}else{
		setSuccessStyle(confirmPasswordInput);
	}
	var id = $("#auth_id").val();
	var jtoken = $("#modfiyUserPassword_jtoken").val();
	$("#userForm_button_save").prop("disabled",true);
	$.ajax({url:apiurl+"modifyUserPassword",
		data:{"id":id,"password":oldPassword,"newPassword":newPassword,"jtoken":jtoken},
		success:function(results){
			if(results == "SUCCESS"){
				//修改成功后，等待下行同步完成
				setTimeout(function(){
					alert("修改密码成功,请用新密码重新登录!",function(){
						logout();
					});
				},2000);
			}else{
				message("旧密码错误!");
				$("#userForm_button_save").prop("disabled",false);
			}
		},
		error:function(XMLHttpRequest, textStatus, errorThrown){
			$("#userForm_button_save").prop("disabled",false);
			console.log(textStatus + "/" + errorThrown);
			message("修改密码失败!")
		}
	})
}
//######员工登录密码修改 ADD BY CPQ END######
//customer screen support by Jimmy
//$('#checkoutModal').on('shown.bs.modal',function(){savePayType();inform('gen_cs');});
//$('#checkoutModal').on('hide.bs.modal',function(){inform('hide_cs')});
//$(window).keydown(function(e){inform('show_cs')});
//$(window).mousemove(function(e){inform('show_cs')});

$(function(){
$('.payment-intput').change(savePayType);
$('span[name^=payment_icon_],#btnPay').live('click',savePayType);
});
function savePayType(){ //auto inform
	var paymentitems={'应收':$('#recv').val()};
	$('.payment-label:visible').each(function(i,me){
		paymentitems[$(me).text()]=$(me).next().val();
	});
	paymentitems['找零']=$('#c_change').val();
	window.localStorage.setItem("refresh_cs",
			JSON.stringify(paymentitems));
}

//打印今日销售统计 ADD BY CPQ
function printTodaySaleReport(){
	var date = new Date();
	$('#taday_sale_report_print_area').prepend("<div id='temp_today_sale_report_div'>今日销售统计(本机) <br />日期:"+date.Format("yyyy年MM月dd日")+"</div>")
	$('#taday_sale_report_print_area').printArea();
	$('#taday_sale_report_print_area #temp_today_sale_report_div').remove();
}

//交班记录查询（仅查询本地记录） ADD BY CPQ 20170222 START
//初始化交班记录MODAL
function initShiftRecordModal(){
	$("#searchShiftRecordModal .card-body").outerHeight($(window).height()-173-5-$("#searchShiftRecordModal .card-heading").outerHeight());
	
	$("#searchShiftRecordModal input").val("");
	$("#searchShiftRecordModal .card-heading .btn").prop("disabled",true);
	$("#shiftRecord_count").text("");
	$("#shiftRcord_pageCount").text(1);
	$("#searchShiftRecordModal .currentPage").val(1)
	$("#shiftRecord_pageSize").val(10)
	
	var date = new Date().Format("yyyy-MM-dd");
	$("#shift_start_time").val(date + " 00:00:00");
	$("#shift_end_time").val(date + " 23:59:59");
	goToPage4SearchShiftRecord(1,1);
}

//分页查询交班记录
function goToPage4SearchShiftRecord(pg,flag){
	var pageCount = parseInt($("#shiftRcord_pageCount").text());
	if(pg<=0){
		pg = 1;
	}else if(pg > pageCount && pageCount > 0){
		pg = pageCount
	}
	
	$("#searchShiftRecordModal .currentPage").val(pg);
	
	var eles1 = $("#searchShiftRecordModal").find(".first_arrow,pre_arrow");
	var eles2 = $("#searchShiftRecordModal").find(".last_arrow,.next_arrow");
	
	if(pg == 1){
		eles1.attr("class","btn btn-default disabled");
		eles2.attr("class","btn btn-primary active");
	}else if(pg == pageCount){
		eles1.attr("class","btn btn-primary active");
		eles2.attr("class","btn btn-default disabled");
	}else{
		eles1.attr("class","btn btn-primary active");
		eles2.attr("class","btn btn-primary active");
	}
	
	searchShiftRecord(flag);
}

//查询交班记录
//flag 1:是modal初始化，不弹出无记录提示;其它(包括undefined) 弹出提示 BY CPQ
function searchShiftRecord(flag){
	var params = [companyId,outletId];
	var cashier = $("#shift_cashier_name").val();
	var startTime = $("#shift_start_time").val();
	var endTime = $("#shift_end_time").val();
	
	var sql = " FROM SHIFTRECORDS WHERE company_id = ? AND outlet_id = ? "
	if(startTime && endTime){
		if(startTime > endTime){
			message("开始时间不能大于结束时间.")
			return;
		}
		
	}
	
	if(startTime){
/*		startTime = startTime.replace("T"," ")+":00";*/
		sql += " AND start_time >= '" + startTime + "' ";
	}
	
	if(endTime){
/*		endTime = endTime.replace("T"," ")+":59";*/
		sql += " AND end_time <= '" + endTime + "' ";
	}
	
	if(cashier){
		sql += " AND username like '%"+cashier+"%'";
	}
	
	var pageSize = parseInt($("#shiftRecord_pageSize").val());
	var currentPage = parseInt($("#searchShiftRecordModal .currentPage").val()) - 1;//从0开始计数
	
	if(currentPage < 0) currentPage = 0;
	
	var start = pageSize * currentPage;
	
	$("#shiftRecord_table tbody").empty();
	db.transaction(function(context){
		context.executeSql("SELECT COUNT(*) as item_count " + sql, params,function(count_tx,count_results){
			var _count = (count_results.rows[0] || count_results.rows.item(0)).item_count;
			var pageCount = _count % pageSize != 0 ? Math.floor(_count / pageSize) + 1 : _count / pageSize;
			
			$("#shiftRcord_pageCount").text(pageCount);
			$("#shiftRecord_count").text(_count);
			
			if(pageCount == 1){//只有一页时，不能翻页
				$("#searchShiftRecordModal").find(".first_arrow,pre_arrow").attr("class","btn btn-default disabled");
				$("#searchShiftRecordModal").find(".last_arrow,.next_arrow").attr("class","btn btn-default disabled");
			}
			
			if(_count <= 0 && flag != 1){
				message("没有符合条件的交班记录.");
				return;
			}
			
			params.push(start);
			params.push(pageSize);
			
			context.executeSql("SELECT * " + sql +" ORDER BY start_time DESC,end_time DESC LIMIT ?,?",params,function(tx,result){
				var _tr = "";
				for(var i = 0; i < result.rows.length; i++){
					var item = result.rows.item(i);
					var start_time = item.start_time;
					var sellPayRecord = JSON.parse(item.sell_pay_record);
					var depositPayRecord = JSON.parse(item.deposit_pay_record);
					
					var radio = "<label class='ui-checks ui-checks-sm'><input type='radio' name='shift_id' value='"+item.id+"'><i></i></label>"
					
					var sellPayRecord_a = "<a href='javascript:void(0)' data-toggle='tooltip' class='btn btn-primary btn-xs' "+
						"title='现金:" + sellPayRecord.CASH + 
						 ",银行卡:" + sellPayRecord.CARD + 
						 ",券:" + sellPayRecord.COUPON + 
						 ",会员卡:" + sellPayRecord.BALANCE + 
						 ",支付宝:" + sellPayRecord.ALIPAY + 
						 ",微信:" + sellPayRecord.WEIXIN + "'><i class='glyphicon glyphicon-th-list'></i></a>";
					
					var depositPayRecord_a = "<a href='javascript:void(0)' data-toggle='tooltip' class='btn btn-primary btn-xs' "+
						"title='现金:" + depositPayRecord.CASH + 
						 ",银行卡:" + depositPayRecord.CARD + 
						 ",券:" + (depositPayRecord.COUPON || 0) + 
						 ",支付宝:" + (depositPayRecord.ALIPAY || 0) + 
						 ",微信:" + (depositPayRecord.WEIXIN || 0) + "'><i class='glyphicon glyphicon-th-list'></i></a>";
					
					_tr += "<tr><td>"+radio+"</td>" +
							"<td>"+item.username+"</td>" +
							"<td>"+item.start_time+"</td>" +
							"<td>"+item.end_time+"</td>" +
							"<td>"+item.sale_amount+"</td>" +
							"<td class='text-center'>" + sellPayRecord_a + "</td>" +
							"<td>"+item.deposit_amount+"</td>" +
							"<td>"+item.gift_amount+"</td>" +
							"<td class='text-center'>"+ depositPayRecord_a +"</td>" +
							"<td>"+ item.pretty_cash +"</td>" +
							"<td>"+ item.roe_cash +"</td>" +
							"<td>"+item.total_cash+"</td></tr>"
				}
				
				$("#shiftRecord_table").append(_tr);
				
				$('#searchShiftRecordModal a[data-toggle="tooltip"]').tooltip({position: {my: "center bottom-20",at: "center top"} });
			})
		},function(tx,error){
			console.log("查询总交班记录数时出错");
		})
	})
}

//打印交班记录
//20170414：delete by dph
//方法移至settle-print.js
/*function printShiftRecord(){
	var shiftId = $("#searchShiftRecordModal input[name='shift_id']:checked").val();
	if(!shiftId){
		message("请选择要打印的交班记录.");
		return;
	}
	db.transaction(function(context){
		context.executeSql("SELECT * FROM SHIFTRECORDS WHERE company_id = ? AND outlet_id = ? AND id = ?"
				,[companyId,outletId,shiftId]
		,function(tx,result){
			if(result.rows.length > 0){
				var item = result.rows.item(0);
				var sellPayRecord = JSON.parse(item.sell_pay_record);
				var depositPayRecord = JSON.parse(item.deposit_pay_record);
				
				var printDiv = $("#settle_print_div");
				var clonePrintDiv = printDiv.clone();
				printDiv.find(".sTime").text(item.start_time);
				printDiv.find(".eTime").text(item.end_time);
				
				$("#cashier").text(item.username);
				$("#total_cash").text(doDecimal(item.total_cash));
				$("#total_sale_amount").text(doDecimal(item.sale_amount));
				$("#total_charge").text(doDecimal(item.deposit_amount));
				$("#total_gift").text(doDecimal(item.gift_amount));
				
				$("#settle_payment").empty();
				$("#settle_custom_payment").empty();
				for(var k in sellPayRecord){
					var cloneObj = $("#payment_copy_resource").children().clone(true);
					cloneObj.find(".payment").text(PAYMENT_ARRAY[k]);
					cloneObj.find(".amount").text(doDecimal(sellPayRecord[k]));
					$("#settle_payment").append(cloneObj);
				}
				
				for(var k in depositPayRecord){
					var cloneObj = $("#payment_copy_resource").children().clone(true);
					cloneObj.find(".payment").text(PAYMENT_ARRAY[k]+"(充值)");
					cloneObj.find(".amount").text(doDecimal(depositPayRecord[k]));
					$("#settle_custom_payment").append(cloneObj);
				}
				
				//从付款记录中取得退货信息、次卡消费信息、销售笔数
				context.executeSql("SELECT * FROM PAYRECORDS WHERE company_id=? AND outlet_id=?" +
						" AND cashier_id=? AND settle_status=1 AND create_date BETWEEN ? AND ?",
						[companyId,outletId,item.user_id,item.start_time,item.end_time],
				function(tx,results){
					if(results.rows.length > 0){
						var sale_no = [];//销售笔数
						var refund_no = [];//退货笔数
						
						var total_refund_amount = 0;//退款金额
						var total_sale_amount = 0;//收银合计
						var time_card_total_charge = 0;//次卡充值金额
						var normal_card_total_charge = 0;//普通卡充值金额
						var total_gift = 0;//会员赠送金额
						var time_card_total_gift = 0;//次卡赠送金额
						var normal_card_total_gift = 0;//普通卡赠送金额
						
						for(var i=0; i<results.rows.length; i++){
							var payrecord = results.rows.item(i);
							var sale_order_no = payrecord.sale_order_no;
							var amount = parseFloat(payrecord.amount);
							var pr_type = payrecord.record_type;
							
							if(amount < 0){
								//计算退货笔数
								if(sale_order_no && refund_no.indexOf("'"+sale_order_no+"'") == -1){
									refund_no.push("'"+sale_order_no+"'");
								}
								//退货金额
								total_refund_amount += (amount * -1);
							}
							switch(pr_type){
								case 0:
								case 1://次卡消费，也是销售
									//计算销售笔数
									if(sale_order_no && sale_no.indexOf("'"+sale_order_no+"'") == -1){
										sale_no.push("'"+sale_order_no+"'");
									}
									total_sale_amount += amount;
									break;
								case 10:
									normal_card_total_charge += amount;
									break;
								case 100:
									time_card_total_charge += amount;
									break;
								case 11:
									normal_card_total_gift += amount;
									break;
								case 101:
									time_card_total_gift += amount;
									break;
								}
						}
						
						$("#sell_total_amount").text(doDecimal(total_sale_amount));
						$("#total_sale_num").text(sale_no.length);
						$("#return_num").text(refund_no.length);
						$("#return_amount").text(doDecimal(total_refund_amount));
						
						$("#settle_normal_card_total_charge").text(doDecimal(normal_card_total_charge));
						$("#settle_time_card_total_charge").text(doDecimal(time_card_total_charge));
						$("#settle_normal_card_total_gift").text(doDecimal(normal_card_total_gift));
						$("#settle_time_card_total_gift").text(doDecimal(time_card_total_gift))
					}
					
					$("#todaySaleReportDialog").addClass("hidden");
					$("#sellteDialog").removeClass("hidden");
					
					printDiv.printArea();
					printDiv.replaceWith(clonePrintDiv);
				})
			}
		});
	})
}*/
//交班记录查询 ADD BY CPQ 20170222 END


//查找导购员
function searchEmployee(value){
	if(value){
		$("#employee-list a").removeClass("show").addClass("hidden");
		$("#employee-list a[data-employee_name*='"+value+"']").removeClass("hidden").addClass("show");	
		$("#employee-list a[data-employee_code*='"+value+"']").removeClass("hidden").addClass("show");
	}else{
		$("#employee-list a").removeClass("hidden").addClass("show");
	}
}

//初始化导购员MODAL的删除按钮
function initRemoveEmployeeBtnEvent(employeeId,cartId){
	$("#remove_employee_btn").unbind('click');
	if(!employeeId){
		$("#remove_employee_btn").addClass("disabled");
	}else{
		$("#remove_employee_btn").removeClass("disabled");
		$("#remove_employee_btn").click(function(){
			removeEmployee(cartId);
			$('#guideModal').modal('hide');	
		});
	}
}

//单品贴标打印
function doSingleTagPrint(cartId) {
	var tagJson = localStorage.getItem("PRINTER_TAG");
	if(tagJson){
		tagJson = JSON.parse(tagJson);
		var lines =  tagJson['lines'] || [["desk_no","product_name"],["tastes"],["sale_price"],["sale_date"]];
		//console.log("########## 标签打印lines:"+lines);
		//每个商品打印一次
		var desk_no = $("#desk_no").val() || "";
		var sale_date = new Date().Format("yyyy-MM-dd hh:mm:ss");
		
		db.transaction(function(tx){
			tx.executeSql("SELECT * FROM SHOPPINGCARTS WHERE id = ? OR parent_seq=?",[cartId,cartId],function(tx,result){
				if(result.rows.length > 0){
					var product = $.extend({}, result.rows.item(0)) || $.extend({}, result.rows[0]);
					var tastes = product.tastes || "";
					
					for(var i = 0; i < result.rows.length; i++){
						var p = result.rows.item(i) || result.rows[i];
						if(p.parent_seq){
							var qtyStr = p.qty == 1 ? "" : "X"+p.qty;
							tastes += (tastes ? "," : "") + p.product_name + qtyStr;
						}
					}
					
					product.tastes = tastes;
					
					var msgBuff = [];
					for(var j in lines){
						var line = lines[j];
						
						for(var k in line){
							var field = line[k];
							//console.log("########## 标签打印字段"+field+"="+product[field]);
							if(field == "desk_no"){
								if(desk_no!='') msgBuff.push("桌号:"+desk_no+"\n");
							}
							else if(field == "sale_date"){
								msgBuff.push(sale_date+"\n");
							}
							else{
								var value = field=='sale_price'?"￥"+product[field]:product[field];
								msgBuff.push(value!=''?value+"\n":"");
							}
						}
					}
					console.log("########## 标签打印内容:",msgBuff);
					if(pc) {
						pc.printTag && pc.printTag(tagJson,msgBuff);
					} else if(browser.versions.mobileAndroid){
						tagJson["print_data"] = msgBuff.join("");
						PBAPrinter.printTag && PBAPrinter.printTag(JSON.stringify(tagJson));
					}
				}
			})
		})
	}
}

//初始化口味MODAL
function initTastesModal(tastes){
//	$("#taste_remark").tagsinput("removeAll");
//	$("#taste_remark").tagsinput("add",_this.data("tastes"));
	db.transaction(function(tx){
		tx.executeSql("SELECT * FROM TASTES WHERE company_id = ? AND outlet_id = ? AND del_flag = 0",[companyId,outletId],function(tx,tastesResult){
			if (tastesResult.rows.length > 0) {
				$("#taste_btn_group").empty();
				$("#taste_btn_group_1").empty();
				for(var i = 0; i < tastesResult.rows.length; i++){
					var tasteProduct = tastesResult.rows.item(i) || tastesResult.rows[i];
					var tasteName = tasteProduct.taste_name;
					var price = doDecimal(tasteProduct.price || 0);
					var tasteType = tasteProduct.taste_type || 0;
					
					var ele = $("#taste_btn_source").children().clone();
					
					ele.find(".taste_name").text(tasteName + (tasteType == 1 ? "(￥ "+price+")" : ""));
					ele.find(".taste_name").data("taste_name",tasteName);
					ele.find(".taste_name").data("price",price);
					
					if(tasteType == 1){
						$("#taste_btn_group_1").append(ele);
					}else{
						$("#taste_btn_group").append(ele);
					}
				}
				$("#taste_remark").tagsinput("removeAll");
				$("#taste_remark").tagsinput("add",tastes);
				$("#tastesModal").modal({backdrop:'static',keyboard:false});
			}
		});
	})
}

//点击购物车商品，弹出口味设置
function initTastesClickEvent(){
	$("#cart tbody").delegate("tr","click",function(event){
		if(!$(event.target).is($(this).find("td,td span")) || $(event.target).hasClass("btn")){
			return false;
		}
		
		var _this = $(this);
		
		if(_this.data("parent_seq")){
			_this = $("#cart tbody tr#"+_this.data("parent_seq"));
		}
		
		var cartId = _this.data("cart_id") || _this.attr("id");
		var tastesTr = $(".tastes_tr[data-cart_id='"+cartId+"']");
		var cartTr = $("#"+cartId);
		
		var productId = cartTr.data("product_id");
		var tastes = tastesTr.data("tastes");
		
		var productName = cartTr.find('.product_name').text();
		var barcode = cartTr.find('.barcode').text();
		var price = cartTr.find(".ori_price").text().trim();
		var salePrice = cartTr.find('input[name="sale_price"]').val();
		var qty = cartTr.find('input[name="qty"]').val();
		var subtotal = cartTr.find('.subtotal').text();
		
		var salePriceReadOnly = cartTr.find('input[name="sale_price"]').prop("readonly") ? "readonly='readonly'" : "";
		
		$("#tastes_product_info tbody").empty();
		$("#tastes_product_info tbody").append("<tr data-cart_id='"+cartId+"' data-product_id='"+productId+"'><td><div class='text_overflow'><span class='taste_product_name'>"+productName+"</span><div></td>"
			+ "<td><div class='text_overflow'><span>"+barcode+"</span></div></td>"
			+ "<td><span><input type='number' data-price='"+price+"' class='md-input taste_sale_price' value='"+salePrice+"' "+salePriceReadOnly+"  onchange='calcTasteSubtotal(this);'/></span></td>"
			+ "<td><span><input type='number' class='md-input taste_qty' data-qty='"+qty+"' value='"+qty+"'  onchange='calcTasteSubtotal(this);'/></span></td>"
			+ "<td><span class='taste_subtotal'>"+subtotal+"</span></td><td></td></tr>");
		
		$("#tastesModal .modal-title").text(productName);
		
		//插入加料行
		$("#cart tbody tr[data-parent_seq='"+cartId+"']").each(function(){
			productName = $(this).find('.product_name').text();
			barcode = $(this).find('.barcode').text();
			price = $(this).find(".ori_price").text().trim();
			salePrice = $(this).find('input[name="sale_price"]').val();
			qty = $(this).find('input[name="qty"]').val();
			subtotal = $(this).find('.subtotal').text();
			var tasteCartId = $(this).attr("id");
			var tasteProductId = $(this).data("product_id");
			
			$("#tastes_product_info tbody").append("<tr data-cart_id='"+tasteCartId+"' data-product_id='"+tasteProductId+"'><td><div class='text_overflow'><span class='taste_product_name'>"+productName+"</span><div></td>"
				+ "<td><div class='text_overflow'><span>"+barcode+"</span></div></td>"
				+ "<td><span><input type='number'  data-price='"+price+"' class='md-input taste_sale_price' value='"+salePrice+"'  onchange='calcTasteSubtotal(this)'/></span></td>"
				+ "<td><span><input type='number' class='md-input taste_qty' data-qty='"+qty+"' value='"+qty+"' onchange='calcTasteSubtotal(this)'/></span></td>"
				+ "<td><span class='taste_subtotal'>"+subtotal+"</span></td>"
				+ "<td><button type='button' class='btn btn-xs btn-default' onclick='removeTastesTr(this)'><i class='fa fa-remove'></i></button></td>"
				+ "</tr>");
		});
		
		$("#tastesModal").one("shown.bs.modal",function(){initTastesModal(tastes)});
		
		$("#taste_delete_btn").one("click",function(){removeCart(cartId, 0)});
		
		$("#select_taste_btn").unbind('click');
		$("#select_taste_btn").bind("click",function(){
			var tasteRemark = $("#taste_remark").val();
			var updateDate = parseDate(new Date(), "yyyy/MM/dd hh:mm:ss.S");
			
			var productTr = $("#tastes_product_info tbody tr:eq(0)");
			var salePrice = productTr.find(".taste_sale_price").val();
			var qty = productTr.find(".taste_qty").val();
			var oldSalePrice = $("#"+cartId).find('.price').val();
			var oldQty = $("#"+cartId).find('.cart_item_input[name="qty"]').val();
			
			//更新售价
			if(salePrice != oldSalePrice){
				updateCart(cartId,productTr.find(".taste_sale_price"),3);
			}
			
			//更新数量
			if(qty != oldQty){
				updateCart(cartId,productTr.find(".taste_qty"),2);
			}
			
			//更新口味和加料
			db.transaction(function(tx){
				tx.executeSql("UPDATE SHOPPINGCARTS SET tastes = ?,update_date = ? WHERE id = ?",[tasteRemark,updateDate,cartId]);
				
				$("#tastes_product_info tbody tr:gt(0)").each(function(){
					var tasteProductName = $(this).find(".taste_product_name").text().trim();
					var price = parseFloat($(this).find(".taste_sale_price").data("price") || 0);
					var salePrice = parseFloat($(this).find(".taste_sale_price").val() || 0);
					var qty = parseFloat($(this).find(".taste_qty").val() || 0);
					var subtotal = qty*salePrice;
					var discount = doDecimal(salePrice * 100 / price);
					var updateCartId = $(this).data("cart_id");
					
					if(updateCartId){
						tx.executeSql("UPDATE SHOPPINGCARTS SET discount=?,sale_price=?,qty=?,subtotal=?,update_date=? WHERE id = ?",
								[discount,parseFloat(doDecimal(salePrice)),qty,parseFloat(doDecimal(subtotal)), updateDate, updateCartId]);
					}else{
						tx.executeSql('INSERT INTO SHOPPINGCARTS (outlet_id, category_id , category_name, brand_id , brand_name, supplier_id , supplier_name, product_id, product_name, barcode, unit, supply_price, price, discount_enabled, vip_discount_type, commission_type, commission_rate, commission_amount, discount, wholesale_price, vip_price, sale_price, qty, subtotal,point_enabled,point_rate,subtotal_points,subtotal_commission,refund_flag,update_date,employee_id,parent_seq,gift_flag)'
								 + ' VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', 
								[outletId, 0, "", 0, "", 0, "", 0, tasteProductName, "", "", 0, price, 1, 0, "0", "0", 0, discount, "0", "0", parseFloat(doDecimal(salePrice)), qty, parseFloat(doDecimal(subtotal)),0,100,0,0,0, updateDate, 0,cartId,0])
					}
					
				});
			},function(error){
				console.log(error);
			},function(){
				loadCart();// 加载购物车
				if($("#single_tag_print").prop('checked')){
					doSingleTagPrint(cartId);
				}
				$("#select_taste_btn").unbind('click');
			})
		})
		
		$("#select_taste_btn").prop('disabled',false);
		$("#tastesModal").modal({backdrop:'static',keyboard:false});
	});
}

function checkIfHasOtherRefund(sno){
	if($("#cart tr[data-refund_flag='1']").length > 0
			&& $("#cart tr[data-remark='"+sno+"']").length == 0){
		message("已有其它单在退货中,请先完成当前的退货.",2000);
		return true;
	}
	
	return false;
}

//设置当前行的背景色和字体颜色 BY CPQ
function setCartCurrentRowColor(){
	var quickKey = localStorage.getItem("QUICKKEY");
	var highContrast = 0;
	if(quickKey != undefined){
		quickKey = JSON.parse(quickKey);
		highContrast = quickKey.highContrast || 0;
	}
	if(highContrast == 1){
		$("#cart tr").not(".currentRow").removeClass("highContrast");
		$("#cart .currentRow").addClass("highContrast");
	}
}

//加料加到列表中
function addTasteToTastesProductInfo(){
	var productName = $(this).data("taste_name");
	var salePrice = doDecimal($(this).data("price"));
	var exists = false;
	$("#tastes_product_info tbody tr:gt(0)").each(function(){
		var tasteProductName = $(this).find(".taste_product_name").text().trim();
		if(productName == tasteProductName){
			var price = parseFloat($(this).find(".taste_sale_price").val() || 0);
			var qty = parseFloat($(this).find(".taste_qty").val() || 0) + 1;
			var subtotal = qty*price;
			
			$(this).find(".taste_qty").val(qty);
			$(this).find(".taste_subtotal").text(doDecimal(subtotal));
			
			exists = true;
			
			return false;
		}
	})
	
	if(!exists){
		$("#tastes_product_info tbody").append("<tr data-product_id='0'><td><div class='text_overflow'><span class='taste_product_name'>"+productName+"</span><div></td>"
				+ "<td></td>"
				+ "<td><span><input type='number' data-price='"+salePrice+"' class='md-input taste_sale_price' value='"+salePrice+"' onkeyup='calcTasteSubtotal(this)'/></span></td>"
				+ "<td><span><input type='number' class='md-input taste_qty' value='1' onkeyup='calcTasteSubtotal(this)'/></span></td>"
				+ "<td><span class='taste_subtotal'>"+salePrice+"</span></td>"
				+ "<td><button type='button' class='btn btn-xs btn-default' onclick='removeTastesTr(this)'><i class='fa fa-remove'></i></button></td></tr>");
	}
}

//移除加料行
function removeTastesTr(self){
	var _tr = $(self).parents("tr");
	if(_tr.data("cart_id")){
		removeCart(_tr.data("cart_id"), 0)
	}
	_tr.remove();
}

//计算口味列表小计
function calcTasteSubtotal(self){
	var _tr = $(self).parents('tr');
	var salePrice = _tr.find(".taste_sale_price").val();
	var price = _tr.find(".taste_sale_price").data("price");
	var productId = _tr.data("product_id");
	var qty = _tr.find('.taste_qty').val();
	var oldQty = _tr.find('.taste_qty').data("qty");
	var diffQty = qty - oldQty;
	
	$("#select_taste_btn").prop('disabled',true);
	if(!/^\d+(\.\d{1,2})?$/.test(salePrice)){
		message('售价必须数字!');
		
		setTimeout(function(){
			_tr.find(".taste_sale_price").focus().select();
		},1500);
		return;
	}
	
	// 校验收银员权限
	var minDiscount = getSetting("cMinDiscount");
	var role = $("#auth_role").val();
	var discount = salePrice * 100 / price;
	if(role.indexOf('ROLE_CASHIER')>-1  && discount<parseInt(minDiscount)){
		message("收银员最低折扣为:"+minDiscount+"%");
		
		setTimeout(function(){
			_tr.find(".taste_sale_price").focus().select();
		},1500);
		return;
	}
	
	if(!/^\d+(\.\d{1,2})?$/.test(qty) || qty <= 0){
		message('请输入大于0的数字');
		
		setTimeout(function(){
			_tr.find(".taste_qty").focus().select();
		},1500)
		return;
	}
	
	var zeroStockDisabled = getSetting("cZeroStockDisabled");//无库存禁止销售
	if(zeroStockDisabled == 1 && productId != 0){
		db.transaction(function(tx){
			getProductStock(tx,productId,function(stockQty){//取得该商品的库存后的回调
				
				//无库存禁止销售> 当前库存-销售<0 禁止销售
				var saleQty = getSaleQtyInCart(productId) + diffQty;
				console.log("---------------------销售数量 saleQty @ updateCart() ->"+saleQty);
				if(stockQty-saleQty < 0){
					message("库存不足,禁止销售!<br>库存数量"+stockQty+",销售数量"+saleQty+".");
					
					setTimeout(function(){
						_tr.find(".taste_qty").focus().select();
					},1500);
					
					return;
				}else{
					_tr.find('.taste_subtotal').text(doDecimal(salePrice*qty));
					$("#select_taste_btn").prop('disabled',false);
				}
			});
		});
	}else{
		_tr.find('.taste_subtotal').text(doDecimal(salePrice*qty));
		$("#select_taste_btn").prop('disabled',false);
	}
}