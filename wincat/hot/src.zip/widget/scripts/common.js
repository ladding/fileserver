// ###################################################################################
// #################################   前台通用方法     ##################################
// ###################################################################################
//常量 ADD BY CPQ
//DEPOSIT 会员卡余额变更记录类型
//DEPOSIT_TYPE START
var DEPOSIT_TYPE_NORMAL_SELL = 8; //销售扣款
var DEPOSIT_TYPE_ORIGINAL_BALANCE = 9; //期初余额
var DEPOSIT_TYPE_NORMAL_CHARGE = 100; //前台充值
var DEPOSIT_TYPE_NORMAL_EXCHANGE = 101; //前台积分兑换
var DEPOSIT_TYPE_GIFT_EXCHANGE = 102; //前台积分兑换礼品
var DEPOSIT_TYPE_TIME_CARD_CHARGE = 200; //次卡充值
var DEPOSIT_TYPE_TIME_CARD_DELETE = 201; //次卡删除
var DEPOSIT_TYPE_TIME_CARD_SELL = 81; //次卡扣款
//DEPOSIT_TYPE END

//PAYRECORD 付款记录类型
//RECORD_TYPE START
var RECORD_TYPE_NORMAL_SELL = 0; //普通销售
var RECORD_TYPE_TIME_CARD_SELL = 1; //次卡销售
var RECORD_TYPE_NORMAL_CHARGE = 10; //普通充值
var RECORD_TYPE_NORMAL_GIFT = 11; //普通充值赠送
var RECORD_TYPE_TIME_CARD_CHARGE = 100; //次卡充值
var RECORD_TYPE_TIME_CARD_GIFT = 101; //次卡充值赠送
var RECORD_TYPE_PRETTY_CASH = 20; //准备金
var RECORD_TYPE_ROE_CASH = 21; //非营业现金收支
//RECORD_TYPE END

//通过KEY取得保存在LocalStorage里的设置
function getSetting(key) {
  var settings = "";
  try {
    settings = JSON.parse(localStorage.getItem("settings"));
  } catch (e) {
    console.log(e);
    return "";
  }

  //console.log("settings IN LS \n"+settings,key);

  if (
    typeof localStorage.getItem("settings") == "undefined" ||
    localStorage.getItem("settings") == null ||
    localStorage.getItem("settings") == ""
  )
    return "";

  //var cookies = settings[2].cookies;
  return settings[key];
}

//用LS替代COOKIE
/*function setCookieExpireOnSeconds(name, value, sec) {
  //console.log("**************** 设置"+name+"LS",value,sec,new Date());
  sessionStorage.setItem(name,value);
  setTimeout(function(){
    sessionStorage.removeItem(name);
  },sec*1000)
}*/

//item是LocalStorage的item,key是value中的JSON的KEY
function getCustomerProperty(key) {
  var item = "CURRENT_CUSTOMER";
  var ls = "";
  try {
    ls = JSON.parse(localStorage.getItem(item));
  } catch (e) {
    console.log(e);
    return "";
  }

  //console.log("settings IN LS \n"+settings,key);

  if (
    typeof localStorage.getItem(item) == "undefined" ||
    localStorage.getItem(item) == null ||
    localStorage.getItem(item) == ""
  )
    return "";

  return ls[key];
}

//V2:改用LS,多窗口检查需要cookie
// 设置cookie
function setCookie(name, value) {
  var Days = 365;
  var exp = new Date();
  exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
  document.cookie =
    name + "=" + encodeURIComponent(value) + ";expires=" + exp.toGMTString();
}

//设置cookie
function setCookieExpireOnSeconds(name, value, sec) {
  var exp = new Date();
  exp.setTime(exp.getTime() + sec * 1000);
  document.cookie =
    name + "=" + encodeURIComponent(value) + ";expires=" + exp.toGMTString();
}
// 通过cookie key获得cookie value
function getCookie(name) {
  var reg = new RegExp(["(?:^| )", name, "=([^;]*)"].join(""), "i"),
    arr = document.cookie.match(reg);
  return arr ? decodeURIComponent(arr[1]) : null;
}

// 删除cookie
function delCookie(name) {
  // 删除cookie
  var exp = new Date();
  exp.setTime(exp.getTime() - 1);
  var cval = getCookie(name);
  if (cval != null)
    document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
}

//不四舍五入,并保留2位小数点,小数点不足的,补0,返回字符型
function doDecimal(val) {
  var floatvar = null2zero(val);

  var f_x = parseFloat(floatvar);
  if (isNaN(f_x)) {
    return "0.00";
  }
  var f_x = Math.round(f_x * 100) / 100;
  var s_x = f_x.toString();
  var pos_decimal = s_x.indexOf(".");
  if (pos_decimal < 0) {
    pos_decimal = s_x.length;
    s_x += ".";
  }
  while (s_x.length <= pos_decimal + 2) {
    s_x += "0";
  }
  return s_x;
}

//不四舍五入,并保留3位小数点,小数点不足的,补0,返回字符型
function wrapWeight(val) {
  var floatvar = null2zero(val);

  var f_x = parseFloat(floatvar);
  if (isNaN(f_x)) {
    return "0.000";
  }
  var f_x = Math.round(f_x * 1000) / 1000;
  var s_x = f_x.toString();
  var pos_decimal = s_x.indexOf(".");
  if (pos_decimal < 0) {
    pos_decimal = s_x.length;
    s_x += ".";
  }
  while (s_x.length <= pos_decimal + 3) {
    s_x += "0";
  }
  return s_x;
}

//金额处理:根据帐号设置保留小数点位数 ,返回字符型,1-3
function doRound(val) {
  //var val2 = null2zero(val) ;

  var result = Number(val).toFixed(2); // default
  var level = 2; // 默认保留两位

  var cRound = getSetting("cRound");
  var cRoundType = getSetting("cRoundType");
  // console.log("--------------------- round level / type->
  // "+cRound+"/"+cRoundType);

  if (cRound == "FEN") {
    level = 2;
  } else if (cRound == "JIAO") {
    level = 1;
  } else if (cRound == "YUAN") {
    level = 0;
  }

  if (cRoundType == "CEIL") {
    with (Math) {
      result = ceil(val * pow(10, level)) / pow(10, level);
    }
  } else if (cRoundType == "FLOOR") {
    with (Math) {
      result = floor(val * pow(10, level)) / pow(10, level);
    }
  } else {
    // cRound == 'ROUND',defualt
    with (Math) {
      result = round(val * pow(10, level)) / pow(10, level);
    }
  }

  return doDecimal(result);
}

//返回小数点位数
function getDecimalLen(str) {
  //确保str为字符串，indexOf方法才有效 ADD BY CPQ
  str += "";
  var len = 0;
  if (str.indexOf(".") != -1) {
    len = str.toString().split(".")[1].length;
  }
  return len;
}

//数字输入空转零
function null2zero(str) {
  if (str == null || str == "" || str == "undefined") return 0;
  else return str;
}

//主要用于商品数量，服装版(小数一般都为0)时，小数为0的返回整数 ADD BY CPQ
function doDecimal2(val) {
  var val = doDecimal(val);
  return getSetting("Industry") == "1001" ? parseFloat(val) : val;
}

//判断字段串是否为日期格式
function isDate2(dateString) {
  if (dateString.trim() == "") return true;
  var r = dateString.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);
  if (r == null) {
    alert(
      "请输入格式正确的日期\n\r日期格式：yyyy-mm-dd\n\r例  如：2008-08-08\n\r"
    );
    return false;
  }
  var d = new Date(r[1], r[3] - 1, r[4]);
  var num =
    d.getFullYear() == r[1] && d.getMonth() + 1 == r[3] && d.getDate() == r[4];
  if (num == 0) {
    alert(
      "请输入格式正确的日期\n\r日期格式：yyyy-mm-dd\n\r例  如：2008-08-08\n\r"
    );
  }
  return num != 0;
}

function filterEmoji(str) {
  if (!str) return "";

  str = str.replace(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g, "");
  return str;
}

/**
 * 同时计算并设置多个目标元素的高度
 * @param {需要计算并设置高度的目标元素( jQuery 对象 )数组} targetArray
 * @param {一一对应的需要排除的，处于同一水平位置的最外层元素( jQuery 对象 )数组} excludeElementsArray
 * @param {计算到此元素后停止计算} untilElement
 */
function countAndSetResponsiveHeightMultiple(
  targetArray,
  excludeElementsArray,
  untilElement
) {
  requestAnimationFrame(() => {
    for (let i = 0; i < targetArray.length; i++) {
      countAndSetResponsiveHeight(
        targetArray[i],
        excludeElementsArray[i],
        untilElement
      );
    }
  });
}
/**
 * 计算并设置高度
 * @param {需要计算并设置高度的目标元素( jQuery 对象 )} targetSelector
 * @param {需要排除的，处于同一水平位置的最外层元素( jQuery 对象 )} excludeElementsSelector
 * @param {计算到此元素后停止计算, 默认计算到 document} untilElement
 */
function countAndSetResponsiveHeight(target, excludeElements, untilElement) {
  let tempTarget = target;
  //计算后的高度，初始为屏幕高
  let targetHeight = $(window).height();
//   console.log("begin-target", target);
  do {
    //外部高度
    var outerHeight = tempTarget.outerHeight();
    //减去垂直方向的 padding + border 的总高度
    var outContentHeight = outerHeight - tempTarget.height();
    //减去垂直方向的margin高度
    var marginV = getMarginV(tempTarget);

    targetHeight -= outContentHeight + marginV;

    //减去不需要再同一水平线显示的兄弟节点高度
    var brothers = tempTarget.siblings();
    for (var i = 0; i < brothers.length; i++) {
      var brother = $(brothers[i]);
      if (brother.is(":visible") && !brother.is(excludeElements) && !brother.hasClass("modal-backdrop") && !brother.hasClass("modal") && !brother.hasClass("loadPageModal")) {
        marginV = getMarginV(brother);

		targetHeight -= brother.outerHeight() + marginV;
        // console.log("brother");
        // console.log(brother, brother.outerHeight());
        // console.log(targetHeight);
      }
    }

    //向上取得父元素，继续计算
    tempTarget = tempTarget.parent();
  } while (!tempTarget.is(untilElement || document));

//   console.log(targetHeight);
  if (targetHeight >= 0) $(target).height(targetHeight);
}

function getMarginV(element) {
  var marginTop = parseFloat(element.css("margin-top").replace("px", ""));
  var marginBottom = parseFloat(element.css("margin-bottom").replace("px", ""));

  // console.log("target");
  // console.log(tempTarget, outContentHeight, marginTop, marginBottom);
  // console.log(targetHeight);

  if (marginTop < 0) {
    marginTop = 0;
  }

  if (marginBottom < 0) {
    marginBottom = 0;
  }

  return marginTop + marginBottom;
}

const speak = (num, test = false) => {
  //   var getVoices = await setSpeech();
  //   const utterance = new SpeechSynthesisUtterance(s);
  //    utterance.voice = getVoices;
  //   window.speechSynthesis.speak(utterance);

  // 播放时是否有其他的在播放
  for (let ele of document.querySelectorAll('audio')) {
    if (!ele.paused) return
  }

  let audioArr = ['success', ...numToArray(num), 'yuan']

  // 判断是否为播报测试
  // if (!test)
  //   audioArr.unshift('success')


  // 语音播放   
  var nowAduio = 0;

  const listener = () => {
    nowAduio++;
    if (audioArr[nowAduio]) {
      const elementNext = document.querySelector(`#speak_${audioArr[nowAduio]}`);
      elementNext.play();
      elementNext.addEventListener("pause", listener, false);
    }

    if (audioArr[nowAduio - 1]) {
      const elementLast = document.querySelector(`#speak_${audioArr[nowAduio - 1]}`);
      elementLast.removeEventListener("pause", listener, false);
    }
  };

  const elementStart = document.querySelector(`#speak_${audioArr[0]}`)
  elementStart.addEventListener("pause", listener,false);
  elementStart.play();
};




// // 返回中文语音
// const setSpeech = async () => {
//   var synth = window.speechSynthesis;
//   //  getVoices为空处理
//   var getVoices = await new Promise((resolve, reject) => {
//     var voices = synth.getVoices();
//     if (voices.length) {
//       resolve(voices);
//     } else {
//       synth.onvoiceschanged = function () {
//         voices = synth.getVoices();
//         resolve(voices);
//       };
//     }
//   });

//   //  TODO: 没有中文语音处理
//   for (voice of getVoices) {
// 	  if (voice.lang === "zh-CN") {
// 		  return voice;
// 		}
// 	}
// 	return null
// };

/** @param {需要放入的标签内} defaultEle  */
function speakCreatEle(defaultEle) {
  var allAudioEle = "";
  for (var i in new Array(10).fill(null)) {
    allAudioEle += `<audio id="speak_${i}" src="./audio/money-short/${i}.wav" controls="false" poster="" name="语音播报" author=""></audio>`;
  }

  for (var value of [
    "ten",
    "hundred",
    "thousand",
    "ten-thousand",
    "dot",
    "yuan",
    "success",
  ]) {
    allAudioEle += `<audio id="speak_${value}" src="./audio/money-short/${value}.wav" controls="false" poster="" name="语音播报" author=""></audio>`;
  }
  $(`#${defaultEle}`).append(allAudioEle);
}


// 获取数字转换为对应播放列表数组
/** @param {暂支持数字/字符串类型1234、1234.01、.16、有小数保留两位小数} num */
function numToArray(num) {
  let IntNumArr = Math.trunc(parseInt(num)).toString().split('')
  let IntNumArrLen = IntNumArr.length

  let audioArr = []
  // 个位/小数点
  let dotArr = parseInt(num).toString().split('')
  let indexDot = dotArr.findIndex(item => item === '.')
  if (indexDot === 0) dotArr.unshift('0')
  dotArr = indexDot >= 0 ? dotArr.slice(indexDot - 1).map(item => item === '.' ? 'dot' : item) : [dotArr[dotArr.length - 1]];

  // 十位
  let tenArr = []
  if (IntNumArrLen >= 2) {
    tenArr.push(IntNumArr[IntNumArrLen - 2], 'ten')
    // 个位为0不播放
    if (dotArr[0] === '0') dotArr.shift()
  }

  // 百位
  let hundredArr = []
  if (IntNumArrLen >= 3) {
    hundredArr.push(IntNumArr[IntNumArrLen - 3], 'hundred')
    // 十位为0 不播放单位
    if (tenArr[0] === '0') tenArr = ['0']
    // 十位个位均为0不播放
    if (tenArr[0] === '0' && (dotArr[0] === 'dot' || dotArr.length === 0)) tenArr = []
  }

  // 千位
  let thousandArr = []
  if (IntNumArrLen >= 4) {
    thousandArr.push(IntNumArr[IntNumArrLen - 4], 'thousand')
    // 百位为0 不播放单位
    if (hundredArr[0] === '0') hundredArr = ['0']
    // 百位十位个位均为0 或 百位十位均为0 不播放 
    if (hundredArr[0] === '0' && tenArr.length === 0
      || (hundredArr[0] === '0' && tenArr[0] === '0')) hundredArr = []

  }

  // 万位
  let tenThousandArr = []
  if (IntNumArrLen >= 5) {
    tenThousandArr.push(IntNumArr[IntNumArrLen - 5], 'ten-thousand')
    // 千位为0 不播放单位
    if (thousandArr[0] === '0') thousandArr = ['0']
    // 千位百位十位均为0 或 千位百位十位均为0 不播放
    if (thousandArr[0] === '0' && hundredArr.length === 0
      || (thousandArr[0] === '0' && hundredArr[0] === '0')) thousandArr = []
  }

  let moreArr = []
  if (IntNumArrLen >= 6) {
    let newNum = parseInt(IntNumArr.slice(0, IntNumArrLen - 4).join(''))
    tenThousandArr = ['ten-thousand']
    moreArr = numToArray(newNum)
  }


  audioArr = [...moreArr, ...tenThousandArr, ...thousandArr, ...hundredArr, ...tenArr, ...dotArr]
  console.log("%c Line:486 🍬 audioArr", "color:#3f7cff", audioArr);
  return audioArr
}