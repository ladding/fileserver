//###################################################################################
//############################# 会员相关操作的JAVASCRIPT ##############################
//###################################################################################

/*
 * 在autoComplete的选项上回车时会调用两次getCustomerInfo,
 * 在第一次进入后getCustomerInfoFlag=false;直到处理完成
 * 再次设置为true;来使得第二次进入方法时若前次处理尚未结束直接返回；
 * ADD BY CPQ
*/
var getCustomerInfoFlag = true;

$(document).ready(function () {
	//会员输入获得焦点时，选中文字
	if(!browser.versions.mobileAndroid){
		$("#ac_customer_no").focus(function(){
			$(this).select();
		})
	}
	
	
	// 会员自动填充
	if(browser.versions.mobileIos){
		//ipad客户端下使用tinyAutocomplete
		$("#ac_customer_no").tinyAutocomplete({
			minChars : 2,
			itemTemplate:'<li class="autocomplete-item">{{label}}</li>',
			maxItems: 10,
			showNoResults: true,
			noResultsTemplate: '<li class="autocomplete-item">没有匹配的会员 </li>',
			searchLocalDb :searchCustomers,
			makeData:makeCustomerAutocompleteData,
			onSelect : function(event, result) {
				var customer = result.customer;
				if(!customer) return;
				
				initCustomerModalTab0(customer,false);
			}
		});
	}else{
		$("#ac_customer_no").autocomplete({
			delay: 1000, 
			source : function(request, response) {
				var q = request.term;
				// alert(q);
				searchCustomers(q, function(result) {
					// 处理response
					response(makeCustomerAutocompleteData(result));
				});
			},
			minLength : 2,
			position: {
				collision: "none"
			},
			select : function(event, result) {
				var customer = result.item.customer;
				if(!customer) return;
				
				initCustomerModalTab0(customer,false);
			}

		});
	}

	//弹出会员modal#2
	 $("#btnMember").click(function() {
	 	/*var iclass = $(this).find("i:first").attr("class");
	 	console.log("###################i class->"+iclass+"/"+$(this).find("i:first").hasClass('glyphicon-option-horizontal'));
	 	if($(this).find("i:first").hasClass('glyphicon-option-horizontal')){
	 		$(".openMemberModal").click();
	 	}
	 	if($(this).find("i:first").hasClass('glyphicon-remove')){
	 		restorePrice();
	 	}*/
		 $(".member_name").html("会员⒡")
		 $(".member_balance").html('').hide()
		 $("#memberBtn").removeClass("bg-primary").addClass("btn-primary")

		 $('#memberModal .modal-header .x_t1').addClass("hide");
		 restorePrice();
		 
	 });
	 
	//弹出会员modal
	$(".openMemberModal").click(function() {
		
		$(".new-customer").hide();
		$('.search-customer,.exist-customer').show();
		
		$('#memberModal').one('shown.bs.modal',function(){		
//			if($('#customer_no').val()!='') getCustomerInfo($('#customer_no').val(),false,true);
//			else setCustomerTab(0);
			var no=$("#ac_customer_no").val();
			if(no){
				setCustomerTab(0,no);
			}else{
				setCustomerTab();
			}
			
			
			var mcode = $('#ac_customer_no');
			if(!browser.versions.mobileAndroid){
			 	$(mcode).select();
			}
		});
		
		$('#memberModal').modal('show');
	});
	
	//点击会员tab
	$(".member-tab li").click(function(e) {
		e.preventDefault();
	
		var index = $(this).index();
		console.log("member tab index->" + index,$(this).hasClass("disabled"));
		
		//if($(this).hasClass("disabled")) return;
		
		setCustomerTab(index);
		
		if (!browser.versions.mobileAndroid&&index == 1) {// 充值
			setTimeout('$("#deposit_pay").focus()', 100);
		}
		
		if (!browser.versions.mobileAndroid&&index == 2) {// 兑换
			setTimeout('$("#exchange_point").focus()', 100);
		}
	});

	//会员查询 ADD BY CPQ
	$("#btnCustomerSearch").click(function(){
		$('#searchCustomerModal').one('shown.bs.modal',function(){
			$('#search_customer_kw').select();
			$("#discount_list_cardBody").outerHeight($("#customer_list_cardBody").outerHeight() + $("#customer_list_pageCard").outerHeight());
			//分类列表 ADD BY CPQ
			initDiscountList();
		});
		$('#searchCustomerModal').modal('show');
	})
	
	$('#btnPointExchangeGift').click(function(){
		$('#pointExchangeGiftModal').one('shown.bs.modal',function(){
			$('#giftex_customer_kw').select();
		});
		$('#pointExchangeGiftModal').modal('show');
	})
	
	$('#checkpasswordModal').on('shown.bs.modal',function(){
		$('#c_password').val("").select();
	});
	
	$('#checkpasswordModal').on('hidden.bs.modal',function(){
		$('#c_password').closest(".form-group").removeClass("has-error");
		$('#c_password').removeAttr("style");
		$('#c_password').next().text("");
		$('#c_password').val("");
		updateKeyBindings("memberModal");
		if($("#memberModal")[0].scrollHeight > $(window).height()){
			$("#memberModal").css("overflow-y","auto");
		}
		$('#memberModal').focus();
	});
});

function makeCustomerAutocompleteData(result){
	return $.map(result, function(item, i) {
		//alert($("#memberModal").css("z-index"));//return 1050
		$(".ui-autocomplete").css("z-index","1051");
		var name = item.customer_name;
		var phone = item.phone_number;
		
		if(name && name.length > 1){
			var nameSplit = name.split('');
			nameSplit.splice(1,1,"*");
			name = nameSplit.join('');
		}
		
		if(phone.length > 3){
			var num = phone.length > 7 ? 4 : (phone.length - 3);
			var phoneSplit = phone.split('');
			
			for(var j = 0; j < num; j++){
				phoneSplit.splice(3+j,1,"*");
			}
			phone = phoneSplit.join("");
		}
		return {
			label : (i + 1) + ":" + item.customer_code + "(" + name +", "+ (phone ? phone + " , " : "") + item.discount_rate + "% )",
			value : item.customer_code,
			//customerCode : item.customer_code //返回会员卡号
			customer:item//返回会员信息
		}
	})
}

//搜索会员,用于autocomplete
function searchCustomers(q, callback) {
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM CUSTOMERS WHERE company_id=? AND (outlet_id=? OR shared=1) AND  del_flag=0 AND enabled = 1 AND (customer_name LIKE '%" + q + "%' OR customer_code LIKE '%" + q + "%' OR phone_number LIKE '%" + q + "%' OR customer_pinyin LIKE '%" + q.toUpperCase() + "%') limit 10 ", [companyId, outletId], function(tx, results) {
			if (results.rows) {
				var pj = [];
				for ( var i = 0; i < results.rows.length; i++) {
					var row = results.rows.item(i);
					// pj.push(JSON.stringify(row));
					pj.push(row);

				}
				callback(pj);
			}

		}, null);
	});

}

//验证会员卡密码
function checkMemberPassowrd(){
	
	if(!online){
		message("离线下,不能使用会员卡付款");
		return;
	}
	var customerNo = $("#customer_no").val();
	var password = $("#c_password").val();
	
	if(password==''){
		setErrorStyle($("#c_password"),'密码为空!',false);
	}else{
		db.transaction(function(tx) {
			tx.executeSql(
				"SELECT * FROM CUSTOMERS WHERE company_id=? AND (outlet_id=? OR shared=1) AND  del_flag=0 AND customer_code = ? AND password = ? ", 
				[companyId, outletId, customerNo, hex_md5(password)], function(tx, r) {	//hex_md5():MD5加密方法
					console.log("--------------- 会员数 @ checkMemberPassowrd() ->"+r.rows.length);
					if (r.rows.length > 0) {// 验证通过
						var payment = $("#_payment").val();
						var hasWEIXIN_1 = payment.indexOf('WEIXIN_1') != -1;
						var hasALIPAY_1 = payment.indexOf('ALIPAY_1') != -1;
						var _alipay = $("#c_alipay").val();
						var _weixin = $("#c_weixin").val();
						
						if( (hasALIPAY_1 && _alipay>0) || (hasWEIXIN_1 && _weixin>0) ){
							var modalId = "checkoutModal";
							var webpayType = payment;
							var webpayAmount = hasALIPAY_1 && _alipay>0?_alipay:_weixin;
							
							if(hasWEIXIN_1){
								webpayType = "WEIXIN_1";
							}else if(hasALIPAY_1){
								webpayType = "ALIPAY_1";
							}
							
							gotoWebpay(modalId, webpayType, webpayAmount);
						} else {
							checkout();
						}
					}
					else{
						setErrorStyle($("#c_password"),'密码错误!',false);
					}
				}, null
			);
		});
	}
}

//会员销售MODAL，TAB0初始化共通方法;
function initCustomerModalTab0(customer,inputFlag){
	//保存CURRENT_CUSTOMER LocalStorage(CCLS)
	localStorage.setItem("CURRENT_CUSTOMER",JSON.stringify(customer));//临时保存会员信息
	
	//AC设置为当前会员号
	$("#ac_customer_no").val(customer.customer_code);
	
	//显示充值、兑换、设密tab
 	$("ul.member-tab li").removeAttr("style").removeClass("hide");
 	
 	//激活TAB1
 	setCustomerTab(0,inputFlag);
 	$("#ac_customer_no").blur();
}

//取得会员信息:用于memberModal的精确查询、自动填充选定、新增会员后
function getCustomerInfo(no,inputFlag){
	if(!no) return;
	
	db.transaction(function(tx) {//增加手机号精确查找 ADD BY CPQ
		tx.executeSql("SELECT * FROM CUSTOMERS WHERE company_id=? AND (outlet_id=? OR shared=1) AND  del_flag=0" +
				" AND (customer_name LIKE '%" + no + "%' OR customer_code LIKE '%" + no + "%' OR phone_number LIKE '%" + no + "%' OR customer_pinyin LIKE '%" + no.toUpperCase() + "%') AND enabled = 1", [ companyId, outletId], function(tx, results) {
			
			if(results.rows.length == 0){
				message("没有匹配的会员!");
			}else if (results.rows.length == 1) {//只有一个时，载入会员信息
				var customer = results.rows.item(0);
				console.log("--------------------- customer @ getCustomerInfo() -> 会员号: " + customer.customer_code + " , 折扣: " + customer.discount_rate);
				
				initCustomerModalTab0(customer,inputFlag);
			}else if(results.rows.length > 1){//多个会员时弹出autocomplete下拉
				if(!browser.versions.mobileIos) {
					// 修复在IOS下聚焦或选中，虚拟键盘一直跳
					$("#ac_customer_no").focus();
				}
				if(browser.versions.mobileIos){
					//ipad客户端
					$("#ac_customer_no").trigger("keyup");
				}else{
					$("#ac_customer_no").autocomplete("search");
				}
			}
		}, null);
	});
}


//设置会员tab:用于取得会员信息后(getCustomerInfo())、打开membermodal时、点击tab时
//inputFlag true 时为输入会员号后，点回车时的初始化，焦点放到MODAL上，
 function setCustomerTab(index,inputFlag){
	 $('ul.member-tab li:eq('+index+') a').tab('show');	
	
	 $("[id^=x_t]").removeClass("hide").addClass("hide");
	 $("#x_t" + (index + 1)).removeClass("hide");
	 $("#memberModal .modal-header .exist-customer button").removeClass("hide").addClass("hide");
	var no = getCustomerProperty("customer_code"); 
	if(index != 0 || no != ""){
		$("#memberModal .modal-header .x_t" + (index + 1)).removeClass("hide");
	}

	// 会员资料
	if (index == 0 && no != "") {
		var customer = JSON.parse(localStorage.getItem("CURRENT_CUSTOMER"));
		var name = customer.customer_name;
		var phone = customer.phone_number;
		
	 	//初始化会员资料tab(6项)
	 	$(".ci_code").html(customer.customer_code || "&nbsp;");
	 	$(".ci_phone").html(phone || "&nbsp;");
	 	$(".ci_name").html(name || "&nbsp;");
	 	$(".ci_discount").html(customer.discount_rate || "&nbsp;");
	 	$(".ci_balance").html(doDecimal(customer.balance) || "&nbsp;");
	 	$(".ci_point").html(doDecimal(customer.point) || "&nbsp;");
	 	$(".ci_memo").val(customer.memo);
	 	console.log("************* 会员有效期->",customer.expired_date,customer.expired_date!=null,customer.expired_date!='null');
	 	$(".ci_expired_date").html(customer.expired_date!=null?new Date(customer.expired_date).Format("yyyy-MM-dd"):'永久');
	 	
	 	//初始化会员资料时，焦点放到MODAL上，
		//可以在输入会员号后，2次回车，直接关闭modal开始会员销售
	 	//var mcode = $('#ac_customer_no');
	 	//$(mcode).select();
	 	if(inputFlag){
	 		$("#memberModal").focus();
	 	}else if(!browser.versions.mobileAndroid && !browser.versions.mobileIos){
		 	$('#ac_customer_no').select();
	 	}
	}	
	if (!no){
		if(!browser.versions.mobileIos) {
			// 修复在IOS下聚焦或选中，虚拟键盘一直跳
			$('#ac_customer_no').select();
		}
		$("#x_t1").removeClass("hide").addClass("hide");
		$(".btnSell4Customer").removeClass("hide").addClass("hide");
	}
	
	//充值
	// 没有选择会员时，余额充值tab不可用 MODIFY BY CPQ
	if (index == 1 && no != "" && online) {
		// 初始化tab content
		initDepositForm();
		getLastCustomerData(no, 1);
		
		initPaymentSelectBox($("#deposit_payment"));//取得可用的付款方式
		initEmployeeSelectBox($("#deposit_employee_id"));//取得导购员
		
		if(getSetting("rechargeGradeEnabled") == 1){
			$("#deposit_pay,#deposit_gift,#deposit_point,#deposit_amount").prop("readonly",true);
			initRechargeGradeSelectBox($("#deposit_recharge_grade"));//取得充值套餐
			$("#deposit_recharge_grade_div").show();
		}
		else{
			$("#deposit_recharge_grade_div").hide();
			$("#deposit_pay,#deposit_gift,#deposit_point").removeAttr("readonly");
		}
	}

	//积分兑换
	// 没有选择会员时，积分兑换tab不可用 MODIFY BY CPQ
	if (index == 2 && no != "" && online) {
		// 初始化tab content
		initExchangeForm();
		getLastCustomerData(no, 2);
		
		if(getSetting("pointExchangeGradeEnabled") == 1){
			$("#exchange_point,#exchange_balance").prop("readonly",true);
			initPointExchangeGradeSelectBox($("#point_exchange_grade"));//取得充值套餐
			$("#point_exchange_grade_div").show();
		}
		else{
			$("#point_exchange_grade_div").hide();
			$("#exchange_point,#exchange_balance").removeAttr("readonly");
		}
	}
	
	//设密
	// 没有选择会员时，设密tab不可用 
	if (index == 3 && no != "" && online) {
		//var passwordEnabled = getCustomerProperty("password_enabled"); 
	 	var password = getCustomerProperty("password"); 
	 	var phoneNumber = getCustomerProperty("phone_number"); 
	 	
		var hasPassword = password!=''?1:0;
		$("#has_password").val(hasPassword);//保留has_password隐藏域
		
		if (phoneNumber == '' && hasPassword == 0) {
			message("该会员没有设置密码,且没有绑定手机号,无法在收银前台修改密码!", 3000);
			$('ul.member-tab li:eq(0) a').tab('show');
			return;
		}
		
		// 初始化tab content
		initCustomerModifyPassword(hasPassword, true);
		getLastCustomerData(no, 3);
	}
	
 }

 

 /**
  * 会员销售：用于memberModal中tab1下点击“会员销售”按钮时
  * 注意:这里不需要处理会员信息,因为wrapCartItem()中会从LS中取得会员信息,而LS中的CURRENT_CUSTOMER一定是最新的.
  * 
  * @returns
  */
 function sellForCustomer(){	
 	 //判断是否过期
 	 if(getCustomerProperty("expired_date")!=undefined && getCustomerProperty("expired_date")!=null){
 		var expiredDate = new Date(getCustomerProperty("expired_date")).Format("yyyyMMdd").toString();
 		var currentDate = new Date().Format("yyyyMMdd").toString();
 		console.log(expiredDate,currentDate);
 		if(parseInt(currentDate)>parseInt(expiredDate)){
 			 message("会员已过期!",3000);
 			 return;
 		}
 	 }
 	 
 	 
 	 
 	//设置用于会员销售的会员号与会员销售方式
 	var cde =  $("#customer_discount_enabled").prop("checked");//会员销售打折
 	var cpe = $("#customer_point_enabled").prop("checked");//会员销售积分
 	
 	//默认为-1,即非会员销售, 0不打折只积分, 1为即打折又积分, 2为只打折不积分, 3为不打折不积分(可能用于会员卡余额消费)
 	var _saleType = -1;
 	if(!cde && cpe) _saleType = 0;
 	else if(cde && cpe) _saleType = 1;
 	else if(cde && !cpe) _saleType = 2;
 	else if(!cde && !cpe) _saleType = 3;
 	else _saleType = -1;
 	
 	$("#customer_sale_type").val(_saleType);//这儿是唯一设置customer_sale_type的地方
 	 
 	console.log("--------------------- saleType @ sellForCustomer() -> saleType = " +$("#customer_sale_type").val());
 	
 	$("#customer_no").val(getCustomerProperty("customer_code"));
 	
 	//设置会员销售input外观
 	$("#r_customer_info").val(getCustomerProperty("customer_name")+" ￥"+getCustomerProperty("balance"));
 	/*$("#btnMember").html('<i class="glyphicon glyphicon-remove"></i>');*/

	 //将会员信息赋值给主界面按钮
	$(".member_name").html($(".ci_name").html())
	$(".member_balance").html($(".ci_balance").html()).show()
	// 修改按钮颜色
	$("#memberBtn").removeClass("btn-primary").addClass("bg-primary")

 	$("#memberModal").modal("hide"); 	
 	
 	//**************** 以上是前置处理 ****************  
 	
 	db.transaction(function(tx) {
 		//V2:增加提成
 		tx.executeSql('SELECT cart.* FROM SHOPPINGCARTS cart WHERE cart.gift_flag !=1 and  cart.outlet_id = ? AND cart.refund_flag = 0 AND cart.discount_enabled = 1 ORDER BY cart.update_date DESC', [outletId], function(tx, results) {
 			
 			var len = results.rows.length, i;
 			if(len>0){
 				
 				for (i = 0; i < len; i++) {
 					var item = results.rows.item(i);// 此处不是商品,是购物车中的明细项,但具备商品大部分的属性(字段相同)
 					
 					//调用 wrapCartItem更新item start
 					wrapCartItem(item, tx, function(resultx){
 						//console.log("--------------------- "+resultx+",index="+index+",len="+len);
 					},8);	
 					//调用 wrapCartItem更新item end
 					
 				}
 				
 			}
 		});	
 		//
 	
 	},null,function(){
 		//事务结束后，调用载入购物车
 		loadCart();
 	});
 	
 }
 
 
 
//更新会员信息:用于同步后更新CURRENT_CUSTOMER LS
 //更新:不与销售关联,仅更新临时存储LS,传入id以防会员号改变
 function updateCustomerInfo(id){
 	//console.log("--------------- 更新会员信息 @ updateCustomerInfo()->"+id);
 	if(!id) return;
 	
 	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM CUSTOMERS WHERE company_id=? AND (outlet_id=? OR shared=1) AND  del_flag=0 AND customer_id =? ", [ companyId, outletId, id ], function(tx, results) {
			if (results.rows.length > 0) {
				var customer = results.rows.item(0);
				console.log("--------------------- customer @ updateCustomerInfo() -> 会员号: " + customer.customer_code + " , 折扣: " + customer.discount_rate);
				
				localStorage.setItem("CURRENT_CUSTOMER",JSON.stringify(customer));
				
				$("#ac_customer_no").val(getCustomerProperty("customer_code"));
				
				//设置会员销售input外观(如果有)
				if($("#r_customer_info").val().indexOf(' ') == -1)
				$("#r_customer_info").val(customer.customer_name+" ￥"+customer.balance);
				
			}
			
		}, null);
	});
 }
 

//初始化会员信息:用于取单、退货后(如果有会员销售/退货存在)
function initCustomerInfo(saleType,no){

 	console.log("--------------- 初始化会员信息 @ initCustomerInfo()->",saleType,no);
 	if(!no) return;
 	
 	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM CUSTOMERS WHERE company_id=? AND (outlet_id=? OR shared=1) AND  del_flag=0 AND customer_code =? ", [ companyId, outletId, no ], function(tx, results) {
			if (results.rows.length > 0) {
				var customer = results.rows.item(0);
				console.log("--------------------- customer @ initCustomerInfo() -> 会员号: " + customer.customer_code + " , 折扣: " + customer.discount_rate);
				
				localStorage.setItem("CURRENT_CUSTOMER",JSON.stringify(customer));
				
				$("#customer_sale_type").val(saleType);
				$("#customer_no").val(customer.customer_code);
				
				//设置会员销售input外观
			 	$("#r_customer_info").val(customer.customer_code+" ￥"+customer.balance+" ☆"+customer.point);
			 /*	$("#btnMember").html('<i class="glyphicon glyphicon-remove"></i>');*/
			 	
			 	getCustomerInfo(customer.customer_code);
				
			}
			
		}, null);
	});
 }


/**
 * 还原会员销售
 * 规则:1).无促销的，恢复商品标价；2).有促销的,不满足条件，恢复商品标价，满足条件的，恢复促销价格。
 */
 function restorePrice() {
 	// 清空会员信息
 	clearCustomerInfo();
 	
 	//**************** 以上是前置处理 **************** 
 	
 	var index = 1;
 	//
 	db.transaction(function(tx) {
 		tx.executeSql('SELECT * FROM SHOPPINGCARTS WHERE gift_flag !=1 and refund_flag = 0 AND discount_enabled = 1 AND outlet_id = ?  ORDER BY update_date DESC', [outletId], function(tx, results) {
 		//V2:增加提成
 		//tx.executeSql('SELECT cart.*,p.commission_type,p.commission_rate,p.commission_amount FROM SHOPPINGCARTS cart,PRODUCTS p WHERE cart.product_id=p.product_id AND cart.refund_flag = 0 AND cart.discount_enabled = 1 AND cart.outlet_id = ?  ORDER BY cart.update_date DESC', [outletId], function(tx, results) {
 			
 			var len = results.rows.length, i;
 			if(len>0){
 				for (i = 0; i < len; i++) {
 					var cartItem = $.extend({}, results.rows.item(i));
 					
 					//传入的基础价格与基础折扣为初始的
 					cartItem.sale_price = cartItem.price;
 					cartItem.discount = 100;
 					
 					//wrapCartItem中更新item start
 					wrapCartItem(cartItem, tx, function(resultx){
 					});
 					//wrapCartItem中更新item end
 				}
 				
 			}
 		});	
 	},null,function(){
 		//事务结束后，调用载入购物车
 		loadCart();
 	});	
 	//	

 }
 


// 清空会员信息:还原到无会员状态.做法:清空会员信息与清空会员销售信息
function clearCustomerInfo() {
	//2.清空会员销售信息
	$("#customer_no").val("");
	$("#customer_sale_type").val(-1);//-1为非会员销售
	
	if(!getCustomerProperty("customer_code")) return;//如果没有会员LS,无需清理
	
	//1.清空会员信息	
	localStorage.removeItem("CURRENT_CUSTOMER");
	// 清空AC INPUT值
	$("#ac_customer_no").val("");
	
	//tab设为不可见
	$('ul.member-tab li:eq(1),ul.member-tab li:eq(2),ul.member-tab li:eq(3)').addClass('hide');	
	
	// footer按钮设为不可见
	$("[id^=x_t]").removeClass("hide").addClass("hide")

	// 清空TAB1的会员资料
	$(".ci_name").html('&nbsp;');
	$(".ci_code").html('会员号');
	$(".ci_balance").html('0.00');
	$(".ci_point").html('0.00');
	$(".ci_phone").html('手机号码');
	$(".ci_discount").html('100');
	$(".ci_expired_date").html('永久');
	
	// 设置重要会员信息与删除会员折扣按钮,初始化多此项
	$("#r_customer_info").val(" ");
/*	$("#btnMember").html('<i class="glyphicon glyphicon-option-horizontal"></i>');*/
	
	//2.清空会员销售信息
//	$("#customer_no").val("");
//	$("#customer_sale_type").val(-1);//-1为非会员销售
}


//################################################################ 分割线 ################################################################

//取得会员最新信息
//customerCode:会员号,returnType:1为返回余额,2为返回积分,3为返回修改密码
function getLastCustomerData(customerCode,returnType) {
	var alertObj = $('#deposit_alert');
	if(returnType==2)
		alertObj = $('#exchange_alert');
	
	if(customerCode==''){
		setAlertMsg(alertObj,"会员卡号不能为空!","alert alert-danger");
		return;
	}
	
	//清空hidden,以防止使用上一个会员的值得
	if(returnType==1){//充值
		$('#available_balance').text('');
    	$('#deposit_bookbalance').val('');
    	$('#customer_id_4_deposit').val('');
    	$('#deposit_jtoken').val('');
    	$('#deposit_bookpoint').val('');
	}
	else if(returnType==2){//积分兑换
		$('#available_point').text('');
    	$('#exchange_bookpoint').val('');
    	$('#customer_id_4_exchange').val('');
    	$('#exchange_jtoken').val('');
    	$('#exchange_bookbalance').val('');
	}else if(returnType ==  3){
		$('#customer_id_4_modifyPassword').val('');
		$('#modifyPassword_jtoken').val('');
	}
	
	//以下内容需要在线	
	
	// 为什么不搜索web sql,因为本地不可靠	
	//返回JSON
	$.ajax({
		url:apiurl+"getCustomerJson",
		type:"post",
		dataType:"json",
		async:false,
		data:{no:customerCode},
		success:function(result,status){
			console.log(result,status);
			var customer = result;
			//console.log("------------------ id / code / name ->"+customer.id +"/"customer.customer_code+"/"+customer.customer_name);
			    
			if(customer.id==undefined){//不存在   	
				setAlertMsg(alertObj,'会员('+customerCode+')不存在!',"alert alert-danger");
				return;
		    }
		    else{//存在
		    	$(alertObj).hide();
		    	if(returnType==1){//充值
		    		$('#available_balance').text(doDecimal(customer.customer_balance));
			    	$('#deposit_bookbalance').val(customer.customer_balance);
			    	$('#customer_id_4_deposit').val(customer.id);
			    	$('#deposit_jtoken').val(customer.jtoken);
			    	$('#deposit_bookpoint').val(customer.customer_point);
		    	}
		    	else if(returnType==2){//积分兑换
		    		$('#available_point').text(doDecimal(customer.customer_point));
			    	$('#exchange_bookpoint').val(customer.customer_point);
			    	$('#customer_id_4_exchange').val(customer.id);
			    	$('#exchange_jtoken').val(customer.jtoken);
			    	$('#exchange_bookbalance').val(customer.customer_balance);
		    	}else if(returnType ==  3){
		    		$('#customer_id_4_modifyPassword').val(customer.id);
		    		$('#modifyPassword_jtoken').val(customer.jtoken);
		    	}
		    }
		},
		error:function(XMLHttpRequest, textStatus, errorThrown){
			message("网络中断,请稍后再试!");
			setCustomerTab(0);//并跳转第一个tab
		}
	})
}


//初始化充值FORM,用于前台会员卡充值
function initDepositForm(){	
	$(".deposit-bookbalance").text(doDecimal(getCustomerProperty("balance")));
	
	$('#deposit_amount').val('');
	$('#deposit_pay').val('');
	$('#deposit_point').val('');
	$('#deposit_remark').val('');	
	$('#deposit_gift').val('');
	removeStyle($('#deposit_amount'));
	removeStyle($('#deposit_pay'));
	removeStyle($('#deposit_point'));
	removeStyle($('#deposit_remark'));

	$("#btn_confirm_deposit").removeAttr("disabled")
}


//初始化积分兑换FORM,用于前台会员卡充值
function initExchangeForm(){	
	$(".exchange-bookpoint").text(doDecimal(getCustomerProperty("point")));
	$(".exchange-bookbalance").text(doDecimal(getCustomerProperty("balance")));
	
	$('#exchange_point').val('');
	$('#exchange_balance').val('');
	$('#exchange_remark').val('');	
	
	removeStyle($('#exchange_point'));
	removeStyle($('#exchange_balance'));
	removeStyle($('#exchange_remark'));

	$("#btn_confirm_exchange").removeAttr("disabled")
}

//新的会员查询，按折扣分组 ADD BY CPQ 20170221 SATRT
//初始化折扣列表
function initDiscountList(){
	$("#search_customer_results_table tbody").empty();
	
	$(".birthday_conditions").hide();
	$("#search_customer_kw").show();
	$("#customer_change_search_btn").text("生日查询");
	$("#search_customer_birthday,#search_customer_kw").val("");
	$("#searchCustomerModal input[name='search_birthday_type']").prop("checked",false);
	$("#searchCustomerModal input[name='search_birthday_type'][value='0']").prop("checked",true);

	$("#searchCustomerModal .card-body:eq(0)").outerHeight($(window).height()-188);
	$("#searchCustomerModal .card-body:eq(1)").outerHeight($(window).height()-188-$("#searchCustomerModal .card-heading:eq(0)").outerHeight());
	
	$("#customer_first_arrow,#customer_pre_arrow").attr("class","btn btn-default disabled");
	$("#customer_last_arrow,#customer_next_arrow").attr("class","btn btn-default disabled");
	
	var params = [companyId,outletId];
	var list_group = $("#searchCustomerModal").find(".list-group");
	var first_item = list_group.find("a:first").clone(true);
	list_group.empty().append(first_item);
	db.transaction(function (context) {
		context.executeSql("SELECT discount_rate as discount,count(customer_id) as num FROM CUSTOMERS" +
				" WHERE company_id = ? AND (outlet_id = ? OR shared = 1)  AND del_flag = 0 GROUP BY discount_rate ORDER BY discount_rate",params,function(context,result){
			if(result.rows.length > 0){
				var sum = 0;
				var _html = "";
				for(var i = 0; i < result.rows.length; i++){
					var item = result.rows.item(i);
					var discount = item.discount;
					var num = item.num;
					
					_html += '<a onclick="searchCusotmerByDiscountPre('+item.discount+',this,0)" class="list-group-item b-l-5x">' +
			          '<span class="pull-right text-primary">'+num+'</span>'+discount+"%"+'</a>';
					
					sum += num;
				}
				list_group.append(_html);
				$("#all_customer_num").text(sum);
			}
		},
		function (context, error) {
			console.log('会员折扣分组查询失败: ' + error.message);
		})
	})
}

//searchType 0:按折扣查询会员,1:按条件
function searchCusotmerByDiscountPre(discount,_this,searchType){
	$("#searchCustomerModal .list-group a").removeClass("b-l-info");
	if(searchType == 0){
		$(_this).addClass("b-l-info");
	}
	$('#search_discount').val(discount);
	$("#customer_search_type").val(searchType);
	
	goToPage4SearchCustomer(1);
}

//分页查询会员
function goToPage4SearchCustomer(pg){
	var pageCount = parseInt($("#customer_pageCount").text());
	if(pg<=0){
		pg = 1;
	}else if(pg > pageCount){
		pg = pageCount
	}
	$("#customer_currentPage").val(pg);
	if(pg == 1){
		$("#customer_first_arrow,#customer_pre_arrow").attr("class","btn btn-default disabled");
		$("#customer_last_arrow,#customer_next_arrow").attr("class","btn btn-primary active");
	}else if(pg == pageCount){
		$("#customer_first_arrow,#customer_pre_arrow").attr("class","btn btn-primary active");
		$("#customer_last_arrow,#customer_next_arrow").attr("class","btn btn-default disabled");
	}else{
		$("#customer_first_arrow,#customer_pre_arrow").attr("class","btn btn-primary active");
		$("#customer_last_arrow,#customer_next_arrow").attr("class","btn btn-primary active");
	}
	
	searchCustomerByDiscount($("#customer_search_type").val());
}

//按折扣分组查询会员，或按条件查询会员
function searchCustomerByDiscount(flag){
	var params = [companyId,outletId];
	var sql = " FROM CUSTOMERS WHERE company_id = ? AND (outlet_id = ? OR shared = 1) AND del_flag = 0 ";
	
	if(flag == 0){
		var discount = $('#search_discount').val();
		if(discount && /^\d+(\.\d+)?$/){
			sql += " AND discount_rate = ? ";
			params.push(parseFloat(discount));
		}
	}else{
		$("#searchCustomerModal .list-group a").removeClass("b-l-info");
		var kw = $("#search_customer_kw").val();
		var birthdayCondition = $("#search_customer_birthday").val();
		var birthdayType = $("#searchCustomerModal input[name='search_birthday_type']:checked").val();
		
		if(birthdayCondition){
			//var hackBirthday = birthdayCondition.substring(4);
			//var lunarDay = 
			sql += " AND (birthday_type = "+birthdayType+" AND birthday like '%"+birthdayCondition+"%')";
		}else if(kw){
			sql += " AND (customer_code like '%"+kw+"%' OR phone_number = ? OR customer_name = ?)";
			params.push(kw,kw);
		}
	}
	
	
	//分页查询 MODIFY BY CPQ
	var pageSize = parseInt($("#customer_pageSize").val());
	var currentPage = parseInt($("#customer_currentPage").val()) - 1;//从0开始计数
	var start = pageSize * currentPage;
	
	$("#search_customer_results_table tbody").empty();
	db.transaction(function (context) {
		context.executeSql("SELECT COUNT(*) as item_count " + sql, params,function(count_tx,count_results){
			var _count = (count_results.rows.item(0) || count_results.rows[0]).item_count;
			var pageCount = _count % pageSize != 0 ? Math.floor(_count / pageSize) + 1 : _count / pageSize;
			
			$("#customer_pageCount").text(pageCount);
			$("#customer_count").text(_count);
			
			if(pageCount == 1){//只有一页时，不能翻页
				$("#customer_first_arrow,#customer_pre_arrow").attr("class","btn btn-default disabled");
				$("#customer_last_arrow,#customer_next_arrow").attr("class","btn btn-default disabled");
			}
			
			params.push(start);
			params.push(pageSize);
			
			context.executeSql(" SELECT * " + sql +" ORDER BY discount_rate, update_date DESC,IFNULL(expired_date,'9999-99-99') LIMIT ?,? ",params,function(context,result){
				if(result.rows.length > 0){
					var _tr = "";
					for(var i = 0; i < result.rows.length; i++){
						var item = result.rows.item(i);
						var cOid = item.outlet_id;
						var name = item.customer_name;
						var code = item.customer_code;
						var discount = item.discount_rate;
						var balance = item.balance;
						var point = item.point;
						var phone = item.phone_number;
						var birthday = item.birthday || "";
						var birthdayType = item.birthday_type;
						var expired = item.expired_date || "";
						var memo = item.memo || "";
						
						if(birthday){
							birthday = new Date(birthday).Format("MM-dd");
							
							if(birthdayType == 1){
								birthday += '<span class="badge badge-xs bg-info up">农</span>';
							}
						}
						
						if(name.length > 1){
							var nameSplit = name.split('');
							nameSplit.splice(1,1,"*");
							name = nameSplit.join('');
						}
						
						if(phone.length > 3){
							var num = phone.length > 7 ? 4 : (phone.length - 3);
							var phoneSplit = phone.split('');
							
							for(var j = 0; j < num; j++){
								phoneSplit.splice(3+j,1,"*");
							}
							phone = phoneSplit.join("");
						}
						
						if(expired){
							expired = new Date(expired).Format("yyyy-MM-dd");
						}else{
							expired = "永久";
						}
						
						var _span;
						if(cOid == outletId){
							_span = '<span class="badge bg-info">是</span>';
						}else{
							_span = '<span class="badge bg-dark">否</span>'
						}
						
						_tr = "<tr><td>"+(i+1)+"</td>" +
						"<td>"+_span+"</td>" +
						"<td>"+name+"</td>" +
						"<td>"+code+"</td>" +
						"<td>"+doDecimal(discount)+"</td>" +
						"<td>"+doDecimal(balance)+"</td>" +
						"<td>"+doDecimal(point)+"</td>" +
						"<td>"+phone+"</td>" +
						"<td>"+birthday+"</td>" +
						"<td>"+expired+"</td>" +
						"<td><a href='javascript:void(0)' class='text_over' data-toggle='tooltip' title='"+memo+"'>"+memo+"</a></td>" +
						"</tr>";
						$("#search_customer_results_table tbody").append(_tr);
					}
					
					$('#search_customer_results_table a[data-toggle="tooltip"]').each(function(){
						if(this.scrollWidth > 150){
							$(this).tooltip({position: {my: "center bottom-20",at: "center top"} });
						}
					})
				}else{
					message("没有找到匹配的会员.");
				}
			},
			function (context, error) {
				console.log('会员按折扣查询失败: ' + error.message);
			})
		});
	})
}

//切换查询类型
function changeCustomerSearch(ths){
	var _oldText = $(ths).text();
	$(ths).text(_oldText == "生日查询" ? "条件查询" : "生日查询");
	$(".birthday_conditions,#search_customer_kw").toggle();
	$("#search_customer_birthday,#search_customer_kw").val("");
	if(_oldText == "生日查询"){
		$("#search_customer_birthday").val("");
	}
}
//新的会员查询，按折扣分组 20170221 ADD BY CPQ END
//################################################################ 分割线 ################################################################

//################################################################ 分割线 ################################################################


//会员卡充值
function deposit(){
	if(!online){
		message("离线不能充值!")
		return;
	}
	
	genDepositAmount();//bug fix:重新计算一遍新增金额,以防充值金额的onkeyup事件来不及触发,by fandy
	
	var bookBalance = $("#deposit_bookbalance").val()|| 0;
	var bookPoint = $("#deposit_bookpoint").val() || 0;
	var deposit = $("#deposit_amount").val();
	var pay = $("#deposit_pay").val();
	var point = $("#deposit_point").val() || 0;
	var remark = $("#deposit_remark").val();
	var gift = $("#deposit_gift").val() || 0;
	console.log("-------------------- bookBalance/bookPoint/deposit/pay->"+bookBalance+"/"+bookPoint+"/"+deposit+"/"+pay);
	
	//格式校验 start
	if(!pay){
		setErrorStyle($("#deposit_pay"),'充值金额不能为空!',false);
    	return;
	}
	else{
		var reg = /^[0-9]*[1-9][0-9]*$/;
		var reg2 = /^[+-]?\d+\.?\d*$/;
		if (!reg2.test(pay) || getDecimalLen(pay)>2) {
			setErrorStyle($("#deposit_pay"),'支付金额必须是数字，且最多只能保留两位小数点!',false);
	    	return;
		}
		else{
			setSuccessStyle($("#deposit_pay"));
		}
	}
	
	if(!deposit){
		setErrorStyle($("#deposit_amount"),'新增余额不能为空,请输入充值金额或赠送金额!',false);
    	return;
	}
	else{
		var reg = /^[0-9]*[1-9][0-9]*$/;
		var reg2 = /^[+-]?\d+\.?\d*$/;
		if (!reg2.test(deposit) || getDecimalLen(deposit)>2) {
			setErrorStyle($("#deposit_amount"),'充值金额必须是数字，且最多只能保留两位小数点!',false);
	    	return;
		}
		else{
			setSuccessStyle($("#deposit_amount"));
		}
	}
	
	
	if(point){//不用判断空，空默认为0，MODIFY BY CPQ
		var reg = /^[0-9]*[1-9][0-9]*$/;
		var reg2 = /^[+-]?\d+\.?\d*$/;
		if (!reg2.test(point) || getDecimalLen(point)>2) {
			setErrorStyle($("#deposit_point"),'赠送积分必须是正数,且最多只能保留两位小数点!',false);
			return;
		}
		else{
			setSuccessStyle($("#deposit_point"));
		}
	}
	
	//校验赠送金额 ADD BY CPQ
	if(gift){
		var reg2 = /^[+-]?\d+\.?\d*$/;
		if (!reg2.test(point) || getDecimalLen(point)>2) {
			setErrorStyle($("#deposit_gift"),'赠送金额必须是正数,且最多只能保留两位小数点!',false);
			return;
		}
		else{
			setSuccessStyle($("#deposit_gift"));
		}
	}
	//格式校验 end
	
	//校验通过
	$("#btn_confirm_deposit").attr("disabled","disabled");	//防止重复提交
	
	var id = $("#customer_id_4_deposit").val();
	var jtoken = $("#deposit_jtoken").val();
	var payment = $("#deposit_payment").val();
	var hackPayment = (payment == 'ALIPAY_1' || payment == 'WEIXIN_1')?payment.substring(0,payment.lastIndexOf('_')):payment;
	var employeeId = $("#deposit_employee_id").val();
	
	
	$.ajax({
		url: apiurl+"depositAtSell", 
		type: "post",
		data: {dt:100,id:id,ex_point:point,ex_balance:deposit,pay:pay,remark:remark,jtoken:jtoken,payment:hackPayment,gift:gift,
			employee_id:employeeId}, 
		dataType: "json",
		success: function(result){
			console.log("### 充值返回 ->"+result,result.return_code)
			//提示，并修改余额与积分
			   if(result.return_code == 'SUCCESS'){
				   var customer = result;
				   
				   message("成功充值"+deposit+"元,当前通用余额"+customer.balance+"元!");
				   
				   $('.deposit-bookbalance').text(doDecimal(customer.balance)).effect("highlight", {
						color : '#ffc107'
					}, 1000);
				   
				   //设置会员input,如果当前收银会员不为空且与充值操作的会员相同
				   var customerNo = $("#customer_no").val();
				   if(customerNo!='' && getCustomerProperty("customer_code") == customerNo)
					   $("#r_customer_info").val(customerNo+" ￥"+customer.balance+" ☆"+customer.point);
				   
				   //v2:更新本地DB会员数据,插入PAYRECORDS ADD BY CPQ
				   var uId = $("#auth_id").val();
				   var username = $("#auth_username").val();
				   
				   
				   db.transaction(function(tx){
					   //更新本地会员数据
					   tx.executeSql('UPDATE CUSTOMERS SET balance = ? , point = ? , update_date = ? WHERE company_id = ? AND  customer_id = ? ', 
							[customer.balance, customer.point,  customer.update_date, companyId, customer.customer_id], 
							function(r){
						   		console.log("更新本地会员数据成功");
						   		updateCustomerInfo(customer.customer_id);//更新CCLS
					   		},function(tx,error){
							   console.log(error.message)
						   });
					   
					   tx.executeSql('INSERT INTO PAYRECORDS (company_id, outlet_id, sale_order_no, cashier_id, cashier_name, payment, amount, real_amount, settle_status, create_date, update_date,record_type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', 
							[companyId, outletId, null, uId, username, hackPayment, pay, pay, 0, customer.update_date, customer.update_date ,10 ], 
							function(r){
					   			console.log("插入本地充值实付PR成功");
					   		},function(tx,error){
							   console.log(error.message)
					   		});
					   
					  if(gift != 0){//有赠送金额 //FIXME:real_amount是否设为0?payment为null?
						  tx.executeSql('INSERT INTO PAYRECORDS (company_id, outlet_id, sale_order_no, cashier_id, cashier_name, payment, amount, real_amount, settle_status, create_date, update_date,record_type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', 
								[companyId, outletId, null, uId, username, null, gift, gift, 0, customer.update_date, customer.update_date ,11 ], 
								function(r){
						   			console.log("插入本地充值赠送PR成功");
						   		},function(tx,error){
						   			console.log(error.message)
						   		});
					  }
				   },
				   function(err){
					   console.log("transaction error:",err);
				   },
				   function(){//充值WEBSQL执行回调成功
					   
					 //弹出钱箱 ADD BY CPQ 201704
					   var cPopCashBox = localStorage.getItem("popCashBox");
					   if(cPopCashBox == "1"){
							popCashBox();
					   }
					   
						//打印
					   if($("#print_deposit_receipt").prop('checked')){
						   $("input:hidden[name='deposit_date']").val(customer.update_date.substring(0,16));//充值时间设为会员更新时间
						   printDepositReceipt();   
					   }
					   
					   var phoneNumber = getCustomerProperty("phone_number");
					   
					   //V2:发送余额通知短信
					   settings = JSON.parse(localStorage.getItem("settings"));//取得设置
					   console.log(settings.notice_enabled,settings.sms_qty,"充值金额="+deposit,"余额="+customer.balance);
					   if(settings.notice_enabled ==1 && settings.sms_qty>0  && phoneNumber !='' ){
						   balanceNotice(phoneNumber, customer.customer_id,customer.customer_code,customer.customer_name,doDecimal(deposit),doDecimal(customer.balance),'充值');
					   }
					   
					    //发送微信通知,by fandy AT 20170612
						if(settings.wx_notice_enabled ==1){
							wxDepositNotice(customer.customer_id, customer.update_date, pay, gift, deposit, point, hackPayment, remark);
						}
				   }
				   );//db.transaction end
				   
				   
				   
			   }
			   else{
				   //充值失败
				   $("#btn_confirm_deposit").removeAttr("disabled");
				   alert("充值失败 : "+result.return_msg);
			   }
		},
		error: function(){
			message("网络连接错误");
		}
	});
}


//计算新增余额 ADD BY CPQ
function genDepositAmount(){
	var pay = parseFloat($("#deposit_pay").val()) || 0;
	var gift = parseFloat($("#deposit_gift").val()) || 0;
	$("#deposit_amount").val(pay+gift);
}



//积分兑换
function exchangePoint(){
	var totalPoint = $("#exchange_bookpoint").val();
	var exchangePoint = $("#exchange_point").val();
	var exchangeBalance = $("#exchange_balance").val();
	var remark = $("#exchange_remark").val();
	var bookBalance = $("#exchange_bookbalance").val();
	
	console.log("-------------------- totalPoint/exchangePoint/exchnageBalance->"+totalPoint+"/"+exchangePoint+"/"+exchangeBalance);
	
	if(!exchangePoint){
		setErrorStyle($("#exchange_point"),'兑换积分不能为空!',false);
    	return;
	}
	else{
		var reg = /^[0-9]*[1-9][0-9]*$/;
		var reg2 = /^[+-]?\d+\.?\d*$/;
		//console.log(exchangePoint<totalPoint);
		if (!reg2.test(exchangePoint) || exchangePoint<0  || getDecimalLen(exchangePoint)>2) {
			setErrorStyle($("#exchange_point"),'兑换积分必须是正数,且最多只能保留两位小数点!',false);
			return;
		}
		else if (parseFloat(exchangePoint) > parseFloat(totalPoint)) {
			setErrorStyle($("#exchange_point"),'兑换积分不能大于当前可用积分!',false);
			return;
		}
		else{
			setSuccessStyle($("#exchange_point"));
		}
	}
	
	if (!reg2.test(exchangeBalance)||exchangeBalance<0 || getDecimalLen(exchangeBalance)>2){
		setErrorStyle($("#exchange_balance"),'兑换金额必须是大于零的数字,且最多只能保留两位小数点!',false);
    	return;
	}else{
		setSuccessStyle($("#exchange_balance"));
	}
	
	//校验通过
	$("#btn_confirm_exchange").attr("disabled","disabled");	//防止重复提交
	var id = $("#customer_id_4_exchange").val();
	var jtoken = $("#exchange_jtoken").val();
	
	$.post(apiurl+"depositAtSell", {dt:101,id:id,ex_point:exchangePoint,ex_balance:exchangeBalance,pay:0,remark:remark,jtoken:jtoken,gift:0}, function(result){
		console.log("################ result @ exchangePoint()->\n"+JSON.stringify(result));
	 	//successfully
	   //提示，并修改余额与积分
	   if(result.customer_id!='undefined'){
		   var customer = result;
		   
		   message("成功兑换"+exchangeBalance+"元,当前余额"+customer.balance+"元!");
		   
		   $('.exchange-bookpoint').text(doDecimal(customer.point))
		   $('.exchange-bookbalance').text(doDecimal(customer.balance)).effect("highlight", {
				color : '#ffc107'
			}, 1000);
		   
		   //设置会员input,如果当前收银会员不为空且与充值操作的会员相同
		   var customerNo = $("#customer_no").val();
		   if(customerNo!='' && getCustomerProperty("customer_code") == customerNo)
			   $("#r_customer_info").val(customerNo+" ￥"+customer.balance+" ☆"+customer.point);
		   
		   	
		   //v2:更新本地DB会员数据,插入PAYRECORDS ADD BY CPQ
		   db.transaction(function(tx){
			   //更新本地会员数据
			   tx.executeSql('UPDATE CUSTOMERS SET balance = ? , point = ? , update_date = ? WHERE company_id = ? AND  customer_id = ? ', 
					[customer.balance, customer.point,  customer.update_date, companyId, customer.customer_id], 
					function(r){
				   		console.log("更新本地会员数据成功 @ exchangePoint()");
				   		
				   		updateCustomerInfo(customer.customer_id);//更新CCLS
				   		
			   		},function(tx,error){
					   console.log(error.message)
				   });
			   
		   },function(err){
			   console.log("transaction error:",err);
		   });//db.transaction end
		   
			
			//打印
		   //if ($("#print_exchange_receipt").attr("checked")) {
		   if($("#print_exchange_receipt").prop('checked')){
			   $("input:hidden[name='exchange_date']").val(customer.update_date.substring(0,16));//充值时间设为会员更新时间
			   printExchangeReceipt();   
		   }
		   
		   
		   var phoneNumber = getCustomerProperty("phone_number");
		   
		   //V2:发送余额通知短信
		   settings = JSON.parse(localStorage.getItem("settings"));//取得设置
		   console.log(settings.notice_enabled,settings.sms_qty,"充值金额="+exchangeBalance,"余额="+customer.balance);
		   if(settings.notice_enabled ==1 && settings.sms_qty>0 && phoneNumber !='' ){
			   balanceNotice(phoneNumber, customer.customer_id,customer.customer_code,customer.customer_name,doDecimal(exchangeBalance),doDecimal(customer.balance),'积分兑换');
		   }
		   
		   //发送微信通知,by fandy AT 20170612
			if(settings.wx_notice_enabled ==1){
				wxExchangeNotice(customer.customer_id, customer.update_date, exchangePoint, doDecimal(exchangeBalance), remark);
			}
	   }
	   else{			
		   $("#btn_confirm_exchange").removeAttr("disabled");
		   message("兑换失败!");
	   }
	   
  },'json');
	
	
}


//################################################################ 分割线 ################################################################


//新增会员准备
function addNewCustomerPre(){
	$('.search-customer,.exist-customer,.new-customer,.add-customer').toggle();
	 
	initNewCustomerForm();
	$('#add_customer_alert').removeAttr('class').hide();
	$('#add_customer_alert').find('span:first').text('');
	$("#customerForm_customer_enable_password").prop("checked", false);
	$('#password_div').addClass('hidden')
}


//初始化新增会员
function initNewCustomerForm(){
	if(!online){//判断在线状态 ADD BY CPQ
		message("网络连接断开！请检查网络连接！")
		return;
	}
	$('#customer_group_id').empty();
	
	$.ajax({
		type:"POST",
		url:apiurl+"getGroupListJson",
		data: {outlet_id:outletId},
		dataType: "json",
		success:function(result){		
			//console.log("result->\n"+JSON.stringify(result));
			var len = result.length, i;
			if(len>0){
				for (i = 0; i < len; i++) {
					var group = result[i];
					//console.log("---------------------" + group.group_name + " = " + group.group_discount+"/"+group.group_id);
//					$("#customer_group_id").append(new Option(group.group_name+"("+group.group_discount+"%)", group.group_id));
					
					//将折扣存放到data-discount中 MODIFY BY CPQ
					$("#customer_group_id").append("<option value='"+ group.group_id+"' data-discount='"+group.group_discount+"'>"+group.group_name+" [折扣"+group.group_discount+"%] "+"</option>");
				}
				$('#customerForm_customer_discount').val($('#customer_group_id option:selected').data("discount"));
				
				$("#customerForm_customer_employee").html("<option value='0'>无</option>");
				db.transaction(function(tx){
					tx.executeSql("SELECT * FROM EMPLOYEES WHERE company_id = ? AND outlet_id = ? AND del_flag = 0",
							[companyId,outletId],function(tx,results){
						var len = results.rows.length
						if(len > 0){
							for(var i = 0; i < len; i++){
								var item = results.rows.item(i);
								$("#customerForm_customer_employee").append(new Option(item.employee_name,item.employee_id))
							}
						}
					})
				})
			}
			else{
				message("没有会员组,请先在后台设置.",1500);
				return;
			}
			
		},
		error:function(XMLHttpRequest, textStatus, errorThrown){
			message("获取会员组出错,无法新增会员.",2000);
			$('.search-customer,.exist-customer,.new-customer,.add-customer').toggle();//返回
		}
	});
	
	
	$("#customerForm_customer_customerCode").val('');
	$("#customerForm_customer_phoneNumber").val('');
	$("#customerForm_customer_customerName").val('');
	$("#customerForm_customer_password").val('');
	$("#customerForm_customer_repassword").val('');
	$("#customerForm_button_save").removeAttr("disabled");
	setSuccessStyle($("#customerForm_customer_customerCode"));
	
	$("#customerForm_customer_birthday").val('');
	$("#birthday_month").val('');
	$("#birthday_day").val('');
	$("#customerForm_customer_birthday_type").prop("checked",false);
	$("#customerForm_customer_expired_date").val('');
	$("#customerForm_customer_shared").prop("checked",true);
	$("#customerForm_customer_time_enabled").prop("checked",false);
	
	var tcEnabled = getSetting("timeCardEnabled");
	console.log("--------- tc enabled->",tcEnabled);
	if(tcEnabled==1)
		$(".time-card-enabled-div").show();
	else
		$(".time-card-enabled-div").hide();
	
	initDiscountInput();
}

//初始化折扣错误提示
function initDiscountInput(){
	$("#customerForm_customer_discount").next().text("").removeAttr("style");
	$("#customerForm_customer_discount").removeAttr("style");
	$("#customerForm_button_save").removeAttr("disabled");
}


//初始化密码错误提示
function initCustomerPasswordInput(id,flag){
	if(flag){//flag = true时，是点击启用密码，需要清空密码输入
		$(id).val("");
	}
	$(id).next().text("").removeAttr("style");
	$(id).removeAttr("style");
	$(id).parents('.form-group').removeClass("has-error");
	$("#customerForm_button_save").removeAttr("disabled");
}


//新增会员生日处理
function initBirthday(){
	var month = $("#birthday_month option:selected").val();
	var day = $("#birthday_day option:selected").val();
	
	if(month && day)
		$("#customerForm_customer_birthday").val(month+"-"+day);
	else 
		$("#customerForm_customer_birthday").val('');
}

//检查会员是否已存在(卡号相同),1-22
function checkCustomerCode(ths){
	if(!online){//判断在线状态 ADD BY CPQ
		message("网络连接断开！请检查网络连接！")
		return;
	}
	var customerCode = $(ths).val();
	
	//当customerCode不为空时
	if(customerCode){		
		//返回JSON
		$.get(apiurl+"getCustomerJson",{no:customerCode}, function(result){
			var customer = result;
			//console.log("------------------ id / code / name ->"+customer.id +"/"customer.customer_code+"/"+customer.customer_name);
			    
			if(customer.id==undefined){//不存在   	
		    	$("#customerForm_button_save").removeAttr("disabled");
		    	setSuccessStyle($("#customerForm_customer_customerCode"));
		    }
		    else{//已存在
		    	$("#customerForm_button_save").attr("disabled","disabled");			    	
		    	setErrorStyle($("#customerForm_customer_customerCode"),'该卡号已存在!',false);
		    }
		},
		'json'
		);
	}
}

//添加新会员
function addCustomer(){
	if(!online){//判断在线状态 ADD BY CPQ
		message("网络连接断开！请检查网络连接！")
		return;
	}
	
	var groupId = $('#customer_group_id').val();	
	var customerCode = $('#customerForm_customer_customerCode').val();
	var phoneNumber = $('#customerForm_customer_phoneNumber').val();
	var customerName = $('#customerForm_customer_customerName').val();
	var customerPassword = $('#customerForm_customer_password').val();
	var repassword = $("#customerForm_customer_repassword").val();
	var discount = $("#customerForm_customer_discount").val();

	var birthday = $("#customerForm_customer_birthday").val();
	var birthdayType = $("#customerForm_customer_birthday_type").prop("checked")?1:0;
	var shared = $("#customerForm_customer_shared").prop("checked")?1:0;
	var timeEnabled = $("#customerForm_customer_time_enabled").prop("checked")?1:0;
	var expiredDate = $("#customerForm_customer_expired_date").val();
	
	//启用密码 ADD BY CPQ
	var passwordEnabled = $("#customerForm_customer_enable_password").prop("checked") ? 1 : 0;
	
	var remark = $("#customerForm_customer_remark").val();
	var employeeId = $("#customerForm_customer_employee").val();
	//校验卡号
	if(customerCode=='' || customerCode.length==0){//
    	$("#customerForm_button_save").attr("disabled","disabled");	
    	setErrorStyle($("#customerForm_customer_customerCode"),'卡号不能为空!',false);
    	return;
    }
	var reg = /[\u4E00-\u9FA5\uF900-\uFA2D]/g;
	if(reg.test(customerCode)){
		$("#customerForm_button_save").attr("disabled","disabled");	
    	setErrorStyle($("#customerForm_customer_customerCode"),'会员卡号不能包含中文!',false);
    	return;
	}
	
	//验证折扣 ADD BY CPQ
	if(discount == ""){
		$("#customerForm_button_save").attr("disabled","disabled");
    	setErrorStyle($("#customer_group_id"),'请选择会员组!',false);
    	return;
	}
	
	//验证生日:空或完整日期
//	var month = $("#birthday_month option:selected").val();
//	var day = $("#birthday_day option:selected").val();
//	console.log(month,day,birthday);
//	if(!birthday && ((!month && day) || (month && !day))){
//		message("生日出错,选择正确的月份与日期!");
//		return;
//	}
	
	console.log("生日格式？",birthday,isDate2(birthday));
	if(!isDate2(birthday)){
		message("生日日期格式错误!");
		return;
	}
	
	//校验过期日期,大于今日
	if(new Date() > Date.parse(expiredDate)){
		message("到期日期必须晚于今天!");
		return;
	}
	
	
	//验证密码
	if( passwordEnabled == 1){
		if( customerPassword == ""){
			$("#customerForm_button_save").attr("disabled","disabled");
	    	setErrorStyle($("#customerForm_customer_password"),'密码不能为空!',false);
	    	return;
		}
		
		if(repassword != customerPassword){
			$("#customerForm_button_save").attr("disabled","disabled");
	    	setErrorStyle($("#customerForm_customer_repassword"),'两次输入的密码不一致!',false);
	    	return;
		}
	}
	
	//校验会员组
	if(!groupId){
		message("请选择会员组!");
    	return;
	}
	
	var ths = $('#customerForm_customer_customerCode');
	
	$("#customerForm_button_save").attr("disabled","disabled");	//防止重复提交
	
	$.ajax({
		type:"POST",
		url:apiurl+"addCustomer",
		data: {
			"groupId":groupId,"customerCode":customerCode,"phoneNumber":phoneNumber,"customerName":customerName,
			"password":customerPassword,"discount":discount,"passwordEnabled":passwordEnabled,"birthday":birthday,
			"birthdayType":birthdayType,"shared":shared,"timeEnabled":timeEnabled,"expiredDate":expiredDate,"remark":remark,
			"employeeId":employeeId},
		dataType: "json",
		success:function(result){
			
			if(result.is_exist==0){//添加成功
				var customer = result.customer;
				
				
				
				//更新本地DB ADD BY CPQ
				db.transaction(function(tx){
					tx.executeSql("INSERT INTO CUSTOMERS (customer_id,company_id,outlet_id,shared,customer_name,customer_pinyin," +
							"customer_code,password,phone_number,discount_rate,point,balance,"
							+"update_date,del_flag,time_enabled,tc_balance,password_enabled,on_account_enabled,enabled,expired_date,memo)" +
							" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
						[customer.customer_id,companyId,outletId,1,customerName,customer.customer_pinyin,customer.customer_code,
						 customer.password,customer.phone_number,customer.discount_rate,0,0,customer.update_date,0,timeEnabled,0,customer.password_enabled,0,1,customer.expired_date,remark],
						function(){

							message("添加会员成功!");
							
							//添加会员后的处理:插入本地DB,生成CCLS,设置tab1并切换到tab1
//							localStorage.setItem("CURRENT_CUSTOMER",JSON.stringify(customer));
//							$("#ac_customer_no").val(customer.customer_code);
							getCustomerInfo(customer.customer_code);
							$('.search-customer,.exist-customer,.new-customer,.add-customer').toggle();
						
						},
						function(tx,error){
							console.log("添加会员更新本地DB出错:"+error.message);
					})
				},null,function(){			
					console.log("事务成功");
					
					
				})
			}
			
			else if(result.is_exist==1){//已存在
				$("#customerForm_button_save").attr("disabled","disabled");	
				
		    	$(ths).next().text("该卡号已存在!").css({"color":"#ff0000","font-weight":"bold"});
		    	$(ths).css("border", "1px solid #ff0000").focus().select();
			}
			
		},
		error:function(XMLHttpRequest, textStatus, errorThrown){
			$("#customerForm_button_save").removeAttr("disabled");
			message("添加会员失败!");
		}
	});
	
}


//######会员修改密码 ADD BY CPQ START#########

//初始化修改密码 tab
function initCustomerModifyPassword(hasPassword,flag){
	var passwordEnabled = getCustomerProperty("password_enabled")!=''?getCustomerProperty("password_enabled"):0;
	
	//是否启用密码
	if(passwordEnabled == 1){
		$("#modify_password_enable_password").prop("checked",true);
		$('#input_password_div').removeClass('hidden');
	}else{
		$("#modify_password_enable_password").prop("checked",false);
		$('#input_password_div').addClass('hidden');
	}

	if(flag){
		$("#customer_id_4_modifyPassword").val("");
		$("#modifyPassword_jtoken").val("");
	}
	
	$("#modify_password_div,#forget_password").removeClass("hidden");
	$("#reset_password_div,#find_password").addClass("hidden");
	$("#modify_password_form .form-group").removeClass("has-error has-success")
	$("#modify_password_form input").val("").removeAttr("style");
	$("#modify_password_form input").next("span").removeClass("help-block").text("");
	$("#modifyType").val(0);
	
	//没有倒计时再重置发送验证码按钮
	if(!curCount) $("#btnReSendValidcode").text("发送");
	
	//是否有密码 ADD BY CPQ
	if(hasPassword == 1){
		$("#modify_password_newPassword_text").text("新密码");
	}else{
		$("#modify_password_newPassword_text").text("密码");
		changePasswordDiv(false);
	}
}

//忘记密码<->修改密码
function changePasswordDiv(flag){
	
	if(flag){ 
		if(!getCustomerProperty("phone_number")){
			alert("没有绑定手机,忘记密码取回需要绑定手机.");
			return;
		}
		initCustomerModifyPassword($("#has_password").val(),false);
	}

	$("#modifyType").val(1);
	$("#modify_password_form input[name='phoneNumber']").val(getCustomerProperty("phone_number"));
	$("#modify_password_enable_password").prop("checked",true);
	$("#reset_password_div,#find_password").removeClass("hidden");
	$("#forget_password,#modify_password_div").addClass("hidden");
	$("#modify_password_form").find("input[name='password'],input[name='repassword']").val("");
	$('#input_password_div').removeClass('hidden');
}

//修改或重置密码
function modifyOrResetPassword(){
	if(!online){
		message("网络连接断开,重置会员密码必须连网,请检查网络连接！")
		return;
	}
	
	var modifyType = $("#modifyType").val();//0为修改,1为取回
	var passInput = $("#modify_password_form input[name='password']");
	var repassInput = $("#modify_password_form input[name='repassword']");
	var newpassword = passInput.val();
	var repassword = repassInput.val();
	//var new_text = $("has_password").val() == 1 ? "" : "新"; 
	
	
	
	if(modifyType == 0){//修改密码
		
		var checked;
		
		//有密码时才要校验密码 ADD BY CPQ		
		if($("#has_password").val()==1){
			var oldpasssInput = $("#modify_password_form input[name='oldPassword']");
			var oldpassword = oldpasssInput.val();
			if(!oldpassword){
				setErrorStyle(oldpasssInput,'原密码不能为空!',false);
		    	return;
			}else{
				setSuccessStyle(oldpasssInput);
			}
		}
		
		//有启用密码，才校验密码 MODIFY BY CPQ
		if($("#modify_password_enable_password").prop("checked")){
			if(!newpassword){
				setErrorStyle(passInput,'密码不能为空!',false);
		    	return;
			}else if(newpassword !== repassword){
				setSuccessStyle(passInput);
				setErrorStyle(repassInput,'两次输入的密码不一致!',false);
		    	return;
			}else{
				setSuccessStyle(repassInput);
			}
		}
		
		checked = checkMemberPassworFromServer();
		switch(checked){
		case 0:
			setErrorStyle(oldpasssInput,'原密码错误!',false);
			break;
		case 1:
			setSuccessStyle(oldpasssInput);
			modifyMemberPassworFromServer();
			break;
		case 2:
			setErrorStyle(oldpasssInput,'验证密码时发生错误!!',false);
			break;
		}
		
	}
	else{//找回密码
		var queryCodeInput = $("#modify_password_form input[name='queryCode']");
		var queryCode = queryCodeInput.val();
		var phoneNumber = $("#modify_password_form input[name='phoneNumber']").val();
		
		if(!queryCode){
			setErrorStyle(queryCodeInput,'验证码不能为空!',false);
	    	return;
		}
		
		if(queryCode.length != 6){
			setErrorStyle(queryCodeInput,'验证码格式错误!',false);
	    	return;
		}
		
		//有启用密码，才校验密码 MODIFY BY CPQ
		if($("#modify_password_enable_password").prop("checked")){
			if(!newpassword){
				setErrorStyle(passInput,'新密码不能为空!',false);
		    	return;
			}else if(newpassword !== repassword){
				setSuccessStyle(passInput);
				setErrorStyle(repassInput,'两次输入的密码不一致!',false);
		    	return;
			}else{
				setSuccessStyle(repassInput);
			}
		}
		
		if(!checkValidcode(phoneNumber,queryCode)){
			setErrorStyle(queryCodeInput,'验证码错误!',false);
			return;
		}
		
		setSuccessStyle(queryCodeInput);
		
		modifyMemberPassworFromServer();
	}
}

//从服务器端验证密码
function checkMemberPassworFromServer(){
	if(!online){
		message("网络连接断开,修改会员密码必须连网,请检查网络连接！")
		return;
	}
	var checked = 0;//0：密码错误；1：密码正确；2：验证密码失败；
	var customerno = getCustomerProperty("customer_code");
	var password = $("#modify_password_form input[name='oldPassword']").val();
	var hasPassword = $("#has_password").val();
	
	$.ajax({
		async:false,
		type:"POST",
		url:apiurl+"checkMemberPassword",
		data:{"customerno":customerno,"password":password,"hasPassword":hasPassword},
		success:function(result){			
			if(result == "SUCCESS"){
				checked = 1;
			}
		},
		error:function(XMLHttpRequest, textStatus, errorThrown){
			console.log(textStatus + "/" + errorThrown);
			checked = 2;
		}
	});
	//console.log("############### checked @ checkMemberPassworFromServer() "+checked)
	return checked;
}

//修改密码
function modifyMemberPassworFromServer(){
	if(!online){
		message("网络连接断开,修改会员密码必须连网,请检查网络连接！")
		return;
	}
	
	
	var customerno = getCustomerProperty("customer_code");
	//var password = $("#modify_password_form input[name='oldPassword']").val();
	var newpassword = $("#modify_password_form input[name='password']").val();
	var phoneNumber = $("#modify_password_form input[name='phoneNumber']").val();
	var modifyType = $("#modifyType").val();
	var queryCode = $("#modify_password_form input[name='queryCode']").val();
	var passwordEnabled = $("#modify_password_enable_password").prop("checked") ? 1 : 0;
	var jtoken = $("#modifyPassword_jtoken").val();
	var id = $("#customer_id_4_modifyPassword").val();//校验JTOKEN时需要id
	
	
	$("#customer_modify_password_btn").prop("disabled",true);
	
	$.ajax({
		async:false,
		url:apiurl+"modifyMemberPassword",
		data:{
			//"modifyType":modifyType,
			passwordEnabled:passwordEnabled,
			"customerno":customerno,
			"newPassword":newpassword,
			"phonenumber":phoneNumber,
			"queryCode":queryCode,
			id:id,
			jtoken:jtoken
			
		},
		dataType: "json",
		success:function(result){
			console.log("------------- 改密/取密 result @modifyMemberPassworFromServer()\n"+JSON.stringify(result))
			if(result.customer_id!='undefined'){
				var customer = result;
			   
				message("设置密码成功!");
				
				$("#modify_password_form").find("input[name='oldPassword'],input[name='password'],input[name='repassword'],input[name='queryCode']").val("");
				
				//设置密码后，肯定有密码
				$("#has_password").val(1)
				$("#customer_modify_password_btn").prop("disabled",false);
				
				initCustomerModifyPassword(1,false);
				
				//更新本地数据库 //不能使用本地数据更新,应使用返回的数据更新
				db.transaction(function(tx){
					tx.executeSql("UPDATE CUSTOMERS SET password=?,password_enabled=?,update_date=?" +
							" WHERE company_id=? AND customer_id=? ",
							[customer.password,customer.password_enabled,customer.update_date,companyId,customer.customer_id],
							null,
					function(tx,error){
						console.log("设置密码更新本地数据库失败："+error.message);
					})
				})
			}else{
				message("设置密码失败!");
				$("#customer_modify_password_btn").prop("disabled",false);
			}
		},
		error:function(XMLHttpRequest, textStatus, errorThrown){
			console.log(textStatus + "/" + errorThrown);
			$("#customer_modify_password_btn").prop("disabled",false);
			message("设置密码失败!");
		}
	});
}



var InterValObj;
var curCount;

//获得手机验证码(发送短信)
function sendValidcode(){
	settings = JSON.parse(localStorage.getItem("settings"));//取得设置
	console.log(settings.verify_code_enabled,settings.sms_qty);
	if(settings.verify_code_enabled==0 || settings.sms_qty==0){
		alert("没有启用发送设置密码短信验证码,或者可用短信数量不足!");
		return;
	}
	
	var phoneInput = $("#modify_password_form input[name='phoneNumber']");
	var phoneNumber = phoneInput.val();
	if(phoneNumber.length != 11){
		setErrorStyle(phoneInput.parents(".input-group"),'手机号码格式错误!',false);
		return false;
	}
	$.ajax({
		async:false,
		url:apiurl+"sendCustomerValidcode",
		type:"POST",
		data:{phonenumber:phoneNumber,sendtype:3,smsType:3} //sendtype:3,smsType:3 表示为会员取密/设密短信,可以在服务器端设为固定
		,success:function(result){
			if(result=="-805"){
				alert("短信余额不足,无法发送验证码,请联系客服充值.");
				return;
			}
			
		    if(result=="-1"){ 
		    	alert("短信发送失败，请稍后再试!");
		    	return;
		    }
		    
		  	//临时,实际的返回按短信API说明
		    if(result=="0"){
		    	//alert(result);
		    	//发送成功,转到下一步
		    	alert("验证码已发短信至您的手机"+phoneNumber);
		    	$("#modify_password_form input[name='queryCode']").val('');
		    	curCount = 90;
	    	    $("#btnReSendValidcode").attr("disabled", "true");
	    	    $("#btnReSendValidcode").text("" + curCount + "秒后重新发送");
	    	    InterValObj = window.setInterval(SetRemainTime4CustomerModifyPassword, 1000); //启动计时器，1秒执行一次 
		    }
			
		}
	});
}

//发送手机短信验证码按钮 倒计时timer处理函数
function SetRemainTime4CustomerModifyPassword() {
  if (curCount == 0) {                
      window.clearInterval(InterValObj);//停止计时器
      $("#btnReSendValidcode").removeAttr("disabled");//启用按钮
      $("#btnReSendValidcode").text("重新发送");
  }
  else {
      curCount--;
      $("#btnReSendValidcode").text("" + curCount + "秒后重新发送");
  }
}


//校验手机短信验证码
function checkValidcode(phonenumber,val){
	$.ajax({
		async:false,
		url:apiurl+"checkValidcode",
		data:{phonenumber:phonenumber,validcode:val,sendtype:3},
		success: function(result){
		    if(result=="0"){
//		    	message("验证码错误!");
		    	flag = false; 
		    }	
		    else{
		    	flag = true;
		    }
		}
	});
	return flag;
}
//######会员修改密码 ADD BY CPQ END#########



/**
 * 取得可用的付款方式:用于充值(注意,包括次卡充值),排除会员卡支付
 * @param selectbox : 付款方式select box对象
 */
function initPaymentSelectBox(selectbox){
	//取得可用的付款方式(根据条件可能还需要过滤充值卡付款)
	var payments = getSetting("cPayment");
	if(payments==null || payments==''){
		alert("没有设置付款方式,请联系您的店铺管理员!");
		return;
	}
	else if(payments=='BALANCE'){
		alert("没有设置可用的付款方式,请联系您的店铺管理员!");
		return;
	}
	
	var paymentArr = new Array();
	if(payments!=null && payments!=''){
		paymentArr = payments.split(",");
	}
	console.log("########################## paymentArr->"+paymentArr);	
	
	//$("#deposit_payment").empty();
	$(selectbox).empty();
	
	if(paymentArr.length>0){
		for(var i=0; i<paymentArr.length; i++){
			if(paymentArr[i]=='BALANCE') continue;//除非会员卡支付	
			
			//不在线时,微信支付和支付宝钱包不可用
			//console.log("---------------- init payment , online? "+online);
			if(!online && (paymentArr[i]=='WEIXIN_1' || paymentArr[i]=='ALIPAY_1')) continue;
			
			$(selectbox).append(new Option(getPayment(paymentArr[i]), paymentArr[i]));
		}
	}	
}


/**
 * 取得导购员:用于充值(注意,包括次卡充值)
 * @param selectbox : 付款方式select box对象
 */
function initEmployeeSelectBox(selectbox){
	$(selectbox).empty();
	$(selectbox).append(new Option('选择导购员', ''));
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM EMPLOYEES WHERE company_id=? AND (outlet_id=? OR shared=1) AND enabled=1 AND del_flag=0  ORDER BY employee_code ", [companyId, outletId], function(tx, results) {
			var len = results.rows.length, i;
			console.log("--------------- 初始化会员充值面板导购员列表 , len-> " +len);			
			if(len>0){	
				for (i = 0; i < len; i++) {
					var item = results.rows.item(i);
					//console.log("---------------------" + item.employee_id + " = " + item.employee_name);		
			        $(selectbox).append(new Option(item.employee_name, item.employee_id));
					
				}
				//$("#deposit_employee_div").removeClass("hide");
			}
			else{
				console.log("没有导购员");
			}
		}, function(tx, error) {
			console.log("init employee,Error : " + error.message);
		});
		
	});
}


/**
 * 取得充值套餐:用于会员充值
 * @param selectbox : select box对象
 */
function initRechargeGradeSelectBox(selectbox){
	$(selectbox).empty();
	$(selectbox).append(new Option('选择充值套餐', ''));
	//有可能同步,采用在线取充值套餐数据
	$.ajax({
		url: apiurl+'getSettingJson',
		type: 'post',
		dataType: 'json',
		success:function(result){
			console.log(result);
			var rechargeGradeArr = result.rechargeGrade;
			if(rechargeGradeArr != undefined){
				for (i = 0; i < rechargeGradeArr.length; i++) {
					var item = rechargeGradeArr[i];
					console.log("--------------------- 充" + item.pay + " 送 " + item.gift+ " ,积分 " + item.point);		
			        $(selectbox).append(new Option('充'+item.pay+'元送'+item.gift+'元',item.pay+','+item.gift+','+item.point));
				}
			}
		},
		error: function(){
			console.log("### 获取充值套餐出现网络错误 ####");
		}
	});
	
	
}

/**
 * 选择充值套餐
 * @param rg : 充送值得,逗号分隔,如充100送5元"100,5"
 * @returns
 */
function pickupRechargeGrade(rechargeGradeStr){
	if(rechargeGradeStr == ''){
		$("#deposit_pay,#deposit_gift,#deposit_point,#deposit_amount").val("");
		return;
	}
	
	var rg = rechargeGradeStr.split(',');
	$('#deposit_pay').val(rg[0]);
	$('#deposit_gift').val(rg[1]);
	var deposit = parseFloat(rg[0]) + parseFloat(rg[1]);
	$('#deposit_amount').val(deposit);
	$('#deposit_point').val(rg[2]);
}

/**
 * 取得积分套餐:用于会员充值
 * @param selectbox : select box对象
 */
function initPointExchangeGradeSelectBox(selectbox){
	$(selectbox).empty();
	$(selectbox).append(new Option('选择积分兑换套餐', ''));
	$(selectbox).next().text("");
	//有可能同步,采用在线取充值套餐数据
	$.ajax({
		url: apiurl+'getSettingJson',
		type: 'post',
		dataType: 'json',
		success:function(result){
			var pointExchangeGradeArr = result.pointExchangeGrade;
			if(pointExchangeGradeArr != undefined){
				for (i = 0; i < pointExchangeGradeArr.length; i++) {
					var item = pointExchangeGradeArr[i];
					if(parseFloat(item.point) > parseFloat($("#exchange_bookpoint").val())) continue;
			        
					$(selectbox).append(new Option(item.point+'积分兑换'+item.amount+'元',item.point+','+item.amount));
				}
			}
			if($(selectbox).find("option").length == 1){
				$(selectbox).next().text("积分不足,没有合适的积分兑换套餐.");
			}
		},
		error: function(){
			console.log("### 获取充值套餐出现网络错误 ####");
		}
	});
	
	
}

/**
 * 选择积分套餐
 * @param rg : 充送值得,逗号分隔,如充100送5元"100,5"
 * @returns
 */
function pickupPointExchangeGrade(pointExchangeGradeStr){
	if(pointExchangeGradeStr == ''){
		$("#exchange_point,#exchange_balance").val("");
		$("#exchange_num").val("").prop("readonly",true);
		return;
	}
	
	var rg = pointExchangeGradeStr.split(',');
	$('#exchange_point').val(rg[0]);
	$('#exchange_balance').val(rg[1]);
}

//V2:发送会员卡余额通知短信:amount是扣款金额,balance是最新余额
function balanceNotice(phoneNumber,id,customerCode,customerName,amount,balance,act){
	if(amount!=0){//有变动金额增量才需要发送通知短信
		$.get(apiurl+"sendCustomerNotice",{phone_number:phoneNumber,customer_id:id,customer_code:customerCode,customer_name:customerName,amount:amount,balance:balance,act:act},function(result){
			console.log("************************ 会员卡余额通知短信发送结果->"+result);		
			if(result!='OK'){
				alert("会员余额通知短信发送失败,原因:"+result);
			}
		},"text");
	}
	
}

/**
 * 充值付款 
 * 
 */
function depositPay(){
	var modalId = "memberModal";
	var webpayType = $("#deposit_payment option:selected").val();
	var webpayAmount = $("#deposit_pay").val();
	
	//console.log(modalId, webpayType, webpayAmount);
	if(webpayType =='ALIPAY_1' || webpayType == 'WEIXIN_1')
		gotoWebpay(modalId, webpayType, webpayAmount);
	else
		deposit();
}

//会员生日提醒 ADD BY CPQ 20161117
function reminderCustomerBirthday(){
	var dontReminderFlag = getCookie("DONT_REMINDER_CUSTOMER_BIRTHDAY");
	
	if(getSetting("birthdayReminder") == 1
			&& firstReminderFlag
			&& dontReminderFlag != 1){
		
		var cid = getSetting("cId");
		var oid = getSetting("oId");
		var now = new Date();
		var todayLunar = lunarCalendar.solar2lunar(now.getFullYear(),now.getMonth()+1,now.getDate());
		
		var solarMonth = now.getMonth();
		var solarDate = now.getDate();
		
		var lunarMonth = todayLunar.lMonth;
		var lunarDate = todayLunar.lDay;
		
		db.transaction(function(tx) {
			tx.executeSql("select * FROM CUSTOMERS WHERE company_id = ? AND outlet_id = ?",[cid,oid],function(tx,result){
				//console.log("--------------- 会员生日提醒 ---------------");
				if(result.rows.length > 0){
					var _tr = "";
					for(var i = 0; i < result.rows.length; i++){
						var customer = result.rows.item(i);

						if(!customer.birthday) {
							// 跳过无生日的会员
							continue;
						}

						var birthday = new Date(customer.birthday);
						
						var birthdayMonth = birthday.getMonth();
						var birthdayDate = birthday.getDate();
						var birthdayType = customer.birthday_type;
						
						var formateBirthday = birthday.Format("MM-dd");

						//birthdayMonth+1 == lunarMonth getMonth的结果月份是从0开始计数的，lunarMonth从1开始计数
						if((birthdayMonth == solarMonth && birthdayDate == solarDate && birthdayType == 0)
								|| (birthdayMonth+1 == lunarMonth && birthdayDate == lunarDate && birthdayType == 1)){
							
							_tr += "<tr><td>"+customer.customer_name+"</td>" +
									"<td>"+customer.customer_code+"</td>" +
									"<td>"+customer.phone_number+"</td>" +
									"<td>"+(formateBirthday + (birthdayType == 1 ? "(农历)" : "") )+"</td></tr>";
							
						}
					}
					
					if(_tr != ""){
						$("#reminderCustomerBirthday_table").append(_tr);
						$("#reminderCustomerBirthdayModal").modal("show");
					}
				}
				firstReminderFlag = false;
			},function(tx,error){
				//console.log("--------------- 会员生日提醒错误 ---------------\n");
				console.error("会员生日提醒，查询会员时发生错误",error);
			});
		});
	}
}

//会员生日提醒，不再提醒 COOKIE 有效期至当天23:59:59
function dontReminderCustomerBirthday(){
	//localStorage.setItem("DONT_REMINDER_CUSTOMER_BIRTHDAY",1);
	var end = new Date();
	end.setHours(23);
	end.setMinutes(59);
	end.setSeconds(59);
	
	document.cookie = "DONT_REMINDER_CUSTOMER_BIRTHDAY" + "=" + encodeURIComponent(1) + ";expires=" + end.toGMTString();
}


//发送微信会员消费通知消息:pay是扣款金额,balance是最新余额
function wxBuyNotice(saleOrderNo, saleDate, customerId, customerCode, pay, balance, amount, point){
	$.get(apiurl+"sendCustomerWxNotice",
			{sale_order_no:saleOrderNo, sale_date:saleDate, customer_id:customerId, customer_code:customerCode, pay:pay, balance:balance, amount:amount, point:point},
			function(result){
		console.log("************************ 微信会员消费通知消息发送结果->"+result);	
	},"text");
}


//发送微信会员充值通知消息:amount是新增金额,point赠送积分
function wxDepositNotice(customerId, depositDate, pay, gift, amount, point, payment, remark){
	$.get(apiurl+"sendCustomerWxChargeNotice",
			{customer_id:customerId, deposit_date:depositDate, pay:pay, gift:gift, amount:amount, point:point,  payment:payment,remark:remark},
			function(result){
		console.log("************************ 微信会员充值通知消息发送结果->"+result);	
	},"text");
}


//发送微信会员充值通知消息:amount是新增金额
function wxExchangeNotice(customerId, exchangeDate, point, amount, remark){
	$.get(apiurl+"sendCustomerWxExchangeNotice",
			{exchange_date:exchangeDate, customer_id:customerId, point:point, amount:amount, remark:remark},
			function(result){
		console.log("************************ 微信会员积分兑换通知消息发送结果->"+result);	
	},"text");
}



//打印充值凭条
function printDepositReceipt(){
	setDepositReceiptStyle();
	
	$("#deposit_print_area .deposit_receipt_remark").empty();
	$("#deposit_print_area .deposit_receipt_header").empty();
	$("#deposit_print_area .deposit_receipt_body").empty();
	
	//$("#deposit_print_area .title").text("充值凭条");
	
	//var localStorage = window.localStorage;
	//MODIFY BY CPQ_PAGE 取得小票设置
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}
	//MODIFY BY CPQ_PAGE END
	//console.log("----------------- receipt header & footer -> " + JSON.stringify(receiptSetting));
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {	
		
		//载入header,footer
		var logo = receiptSetting.header_logo!=''?'<img src="'+receiptSetting.header_logo+'"><br />':'';
		//$(".deposit_receipt_header").html(logo+decodeURIComponent(receiptSetting.header_text));
		$(".deposit_receipt_header").html(logo+removeCR(decodeURIComponent(receiptSetting.header_text)));
		
	}
	
	
	var bookBalance = $("#deposit_bookbalance").val();
	var deposit = $("#deposit_amount").val();
	var pay = $("#deposit_pay").val();
	var point = $("#deposit_point").val();
	var remark = $("#deposit_remark").val();
	var bookPoint = $("#deposit_bookpoint").val();
	var balance = parseFloat(bookBalance)+parseFloat(deposit);
	var newPoint = parseFloat(bookPoint)+parseFloat(point);
	
	var date = $("input:hidden[name='deposit_date']").val();//从服务器端返回的
	
	var dataMap = languageSetting['depositReceipt'];
	$("#deposit_print_area .deposit_receipt_title").html(dataMap['title']);
	
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['date'] + ":</td><td>"+date+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['auth_username'] + ":</td><td>"+$("#auth_username").val()+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['customer_code'] + ":</td><td>"+getCustomerProperty("customer_code")+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['customer_name'] + ":</td><td>"+getCustomerProperty("customer_name")+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['deposit'] + ":</td><td>"+doDecimal(deposit)+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['pay'] + ":</td><td>"+doDecimal(pay)+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['point'] + ":</td><td>"+doDecimal(point)+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['bookBalance'] + ":</td><td>"+doDecimal(bookBalance)+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['balance'] + ":</td><td>"+doDecimal(balance)+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['bookPoint'] + ":</td><td>"+doDecimal(bookPoint)+"</td></tr>");
	$(".deposit_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['newPoint'] + ":</td><td>"+doDecimal(newPoint)+"</td></tr>");
	// 20170121:增加多语言支持 Modify by dph

	$(".deposit_receipt_remark").text(remark);

	var print_json=JSON.parse(rcpJson);
	var receiptTypeMap = getreceiptTypeMap();
	var receiptType = print_json.receipt_template.width || receiptTypeMap[receiptObj.printer.receipt_type] || 58;

	switch(receiptType) {
	case 58:
	case 76:
	case 80:
		if(pc){
			//pcPrintSlip("deposit");
			printSlip("deposit", pc);
		}else if(browser.versions.mobileAndroid){ // 20161114:增加安卓打印 Add by Dingph
	        printSlip("deposit", PBAPrinter);
		} else if(browser.versions.mobileIos) {
			printSlip("deposit", api.require('posPrinter'));
		}else{
			$("#deposit_print_area").printArea();
		}
		break;
	case 100:
		$("#deposit_print_area").printArea();
		break;
	}
}


//打印积分兑换凭条
function printExchangeReceipt(){
	setDepositReceiptStyle();
	
	$("#exchange_print_area .exchange_receipt_remark").empty();
	$("#exchange_print_area .exchange_receipt_header").empty();
	$("#exchange_print_area .exchange_receipt_body").empty();
	
	//$("#exchange_print_area .title").text("充值凭条");
	
	//var localStorage = window.localStorage;
	//MODIFY BY CPQ_PAGE 取得小票设置
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}
	//MODIFY BY CPQ_PAGE END
	//console.log("----------------- receipt header & footer -> " + JSON.stringify(receiptSetting));
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {	
		
		//载入header,footer
		var logo = receiptSetting.header_logo!=''?'<img src="'+receiptSetting.header_logo+'"><br />':'';
		$(".exchange_receipt_header").html(logo+removeCR(decodeURIComponent(receiptSetting.header_text)));
	}
		

	//var customerName = $("#h_customer_name").val();
	
	
	var bookBalance = $("#exchange_bookbalance").val();
	var bookPoint = $("#exchange_bookpoint").val();
	var balance = $("#exchange_balance").val();
	var point = $("#exchange_point").val();
	var remark = $("#exchange_remark").val();
	var newBalance = parseFloat(bookBalance)+parseFloat(balance);
	var newPoint = parseFloat(bookPoint)-parseFloat(point);
	
	var date = $("input:hidden[name='exchange_date']").val();//从服务器端返回的
	
	var dataMap = languageSetting['exchangeReceipt'];
	$("#exchange_print_area .exchange_receipt_title").html(dataMap['title']);
	
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['date'] + ":</td><td>"+date+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['auth_username'] + ":</td><td>"+$("#auth_username").val()+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['customer_code'] + ":</td><td>"+getCustomerProperty("customer_code")+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['customer_name'] + ":</td><td>"+getCustomerProperty("customer_name")+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['point'] + ":</td><td>"+doDecimal(point)+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['balance'] + ":</td><td>"+doDecimal(balance)+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['bookPoint'] + ":</td><td>"+doDecimal(bookPoint)+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['newPoint'] + ":</td><td>"+doDecimal(newPoint)+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['bookBalance'] + ":</td><td>"+doDecimal(bookBalance)+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['newBalance'] + ":</td><td>"+doDecimal(newBalance)+"</td></tr>");
	// 20170121:增加多语言支持 Modify by dph
	
	$(".exchange_receipt_remark").text(remark);

	var print_json=JSON.parse(rcpJson);
	var receiptTypeMap = getreceiptTypeMap();
	var receiptType = print_json.receipt_template.width || receiptTypeMap[receiptObj.printer.receipt_type] || 58;

	switch(receiptType) {
	case 58:
	case 76:
	case 80:
		if(pc){
			//pcPrintSlip("exchange");
			printSlip("exchange", pc);
		}else if(browser.versions.mobileAndroid){ // 20161114:增加安卓打印 Add by Dingph
			printSlip("exchange", PBAPrinter);
		} else if(browser.versions.mobileIos) {
			printSlip("exchange", api.require('posPrinter'));
		}else{
			$("#exchange_print_area").printArea();
		}
		break;
	case 100:
		$("#exchange_print_area").printArea();
		break;
	}
}

//打印积分兑换礼品凭条
function printExchangeGiftReceipt(){
	setDepositReceiptStyle();
	
	$("#exchange_print_area .exchange_receipt_remark").empty();
	$("#exchange_print_area .exchange_receipt_header").empty();
	$("#exchange_print_area .exchange_receipt_body").empty();
	
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	var receiptSetting = null;
	if(rcpJson && rcpJson != "{}" && rcpJson != "undefined"){
		receiptSetting = JSON.parse(rcpJson);
	}
	
	if (typeof(receiptSetting)!='undefined'&&receiptSetting!=null&&receiptSetting!=''&&receiptSetting!='{}') {	
		
		//载入header,footer
		var logo = receiptSetting.header_logo!=''?'<img src="'+receiptSetting.header_logo+'"><br />':'';
		$(".exchange_receipt_header").html(logo+removeCR(decodeURIComponent(receiptSetting.header_text)));
	}

	var customer = JSON.parse(sessionStorage.getItem("CURRENT_GIFTEX_CUSTOMER"));
	var totalExPoint = parseFloat($("#total_giftex_point").text());
	var bookPoint = customer.point + totalExPoint;
	var point = totalExPoint;
	var newPoint = customer.point;
	
	var date = $("input:hidden[name='exchange_date']").val();//从服务器端返回的
	
	var dataMap = languageSetting['exchangeGiftReceipt'];
	var productTitle = languageSetting['productTitle'];
	var commonTitle = languageSetting['commonTitle'];
	$("#exchange_print_area .exchange_receipt_title").html(dataMap['title']);
	
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['date'] + ":</td><td>"+date+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['auth_username'] + ":</td><td>"+$("#auth_username").val()+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['customer_code'] + ":</td><td>"+customer.customerNo+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['customer_name'] + ":</td><td>"+customer.customerName+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['point'] + ":</td><td>"+doDecimal(point)+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['bookPoint'] + ":</td><td>"+doDecimal(bookPoint)+"</td></tr>");
	$(".exchange_receipt_body").append("<tr><td style='text-align:right;'>" + dataMap['newPoint'] + ":</td><td>"+doDecimal(newPoint)+"</td></tr>");
	
	var productTable = $("<table style='text-align:left;'>");
	productTable.append("<thead style='white-space:nowrap;'><tr>" +
		"<th>"+productTitle["name_barcode"]+"</th>" +
		"<th>"+productTitle["qty"]+"</th>" +
		"<th style='text-align:right;'>"+productTitle["exchange_point"]+"</th>" +
		"</tr></thead>");
	
	var totalQty = 0;
	$("#giftex_products tbody tr").each(function(){
		var qty = $(this).find(".qty").val()*1;
		
		if(!qty || qty == 0) return;
		var subTotalExPoint = $(this).find(".subtotal_ex_point").text()*1;
		var productName = $(this).find(".product_name").val();
		var barcode = $(this).find(".barcode").val();
		
		productTable.append("<tbody><tr>" +
			"<td>" + productName + "<br>" + barcode + "</td>" +
			"<td>"+qty+"</td>" +
			"<td style='text-align:right;'>"+subTotalExPoint+"</td>" +
			"</tr></tbody>");
		
		totalQty += qty;
	});
	productTable.append("<tfoot><tr>" +
		"<td>"+commonTitle["totalPrice"]+"</td>" +
		"<td>"+totalQty+"</td>" +
		"<td style='text-align:right;'>"+totalExPoint+"</td>" +
		"</tr></tfoot>");
	$(".exchange_receipt_body").after(productTable);
	productTable.before("<hr />");
	
	var print_json=JSON.parse(rcpJson);
	var receiptTypeMap = getreceiptTypeMap();
	var receiptType = print_json.receipt_template.width || receiptTypeMap[receiptObj.printer.receipt_type] || 58;

	switch(receiptType) {
	case 58:
	case 76:
	case 80:
		if(pc){
			//pcPrintSlip("exchange");
			printSlip("exchange_gift", pc);
		}else if(browser.versions.mobileAndroid){ // 20161114:增加安卓打印 Add by Dingph
			printSlip("exchange_gift", PBAPrinter);
		} else if(browser.versions.mobileIos) {
			printSlip("exchange_gift", api.require('posPrinter'));
		}else{
			$("#exchange_print_area").printArea();
			productTable.prev().remove();
			productTable.remove();
		}
		break;
	case 100:
		$("#exchange_print_area").printArea();
		productTable.prev().remove();
		productTable.remove();
		break;
	}
}

//20170523: 获取打印宽度Map
function getreceiptTypeMap() {
	return {
		"0" : 58,
		"1" : 80,
		"9" : 100
	};
}

// 会员充值/积分兑换凭条打印
function printSlip(flag, printInterface){
	// 非法调用，不予提示，也不予操作
	if(!printInterface) return;
	
	var rcpJson = window.localStorage.getItem("PRINTER_RCP");
	if(!rcpJson || rcpJson == "{}"){
		message("未设置打印");
		return;
	}
	var print_json=JSON.parse(rcpJson);
	if(!isValidBase64(print_json["header_logo"])){
		print_json["header_logo"] = "";
	}

	// build print data
	var printData = [];
	var target = {};
	if(flag == "deposit"){
		var slipJson = genDepositJson();
		target = $.extend({}, print_json, slipJson);
		printData = getDepositData(target);
	}
	else if(flag == "exchange"){
		var slipJson = genExchangeJson();
		target = $.extend({}, print_json, slipJson);
		printData = getExchangeData(target);
	}else if(flag == "exchange_gift"){
		var slipJson = genExchangeGiftJson();
		target = $.extend({}, print_json, slipJson);
		printData = getExchangeGiftData(target);
	}
	
	// print data
	if('undefined' != typeof(PBAPrinter) && PBAPrinter == printInterface) {
		target['print_data'] = printData.join('');
		printInterface.print(JSON.stringify(target));
	}
	else if(browser.versions.mobileIos) {
		var printer = '';
		if('bt' === target['printer']['default_printer_ios']) {
			printer = target['printer']['mac'];
		}
		else if('wifi' === target['printer']['default_printer_ios']) {
			printer = target['printer']['ip'];
		}
		var tmpPrintData = printData.join(""),
		logo = target['header_logo'].replace('data:image/png;base64,', ''),
		qr = target['QR_code'].replace('data:image/png;base64,', '');
		tmpPrintData = tmpPrintData
		.replace('{logo}', !logo ? '' : '<C><BASE64>' + logo + '</BASE64></C>')
		.replace('{qr_code}', !qr ? '' :'<C><BASE64>' + qr + '</BASE64></C>');
		var param = {
				taskList : [
					{
			            printerAddr: printer,
			            content: tmpPrintData, 
			            keepAlive:true,
			            copyNum: 1
			        }
				]
		};
		if(printer)
			printInterface.printOnSpecifiedPrinters(param);
	}
	else {
		printInterface.print(target, printData);
	}
}
//20170121:统一接口 会员充值/积分兑换凭条打印 Modify by dph end

//ADD BY CPQ pc积分兑换凭条JSON
function genExchangeJson(){
	var customerInfo = JSON.parse(localStorage.getItem("CURRENT_CUSTOMER"));
	var date = $("input:hidden[name='exchange_date']").val();//从服务器端返回的
	var authUsername = $("#auth_username").val();
	var customerCode = getCustomerProperty("customer_code");
//	var customerName = getCookie("cCustomerName");
	var customerName = customerInfo.customer_name;
	
	var point = $("#exchange_point").val();
	var balance = $("#exchange_balance").val();
	var bookPoint = $("#exchange_bookpoint").val();
	var newPoint = parseFloat(bookPoint)-parseFloat(point);
	var bookBalance = $("#exchange_bookbalance").val();
	var newBalance = parseFloat(bookBalance)+parseFloat(balance);
	var remark = $("#exchange_remark").val();
	
	var exchangeJson = {
		"date":date,//兑换时间
		"auth_username":authUsername,//操作人员
		"customer_code":customerCode,//会员号
		"customer_name":customerName,//会员名
		"point":doDecimal(point),//兑换积分
		"balance":doDecimal(balance),//兑换金额
		"bookPoint":doDecimal(bookPoint),//兑换前积分
		"newPoint":doDecimal(newPoint),//兑换后积分
		"bookBalance":doDecimal(bookBalance),//兑换前金额
		"newBalance":doDecimal(newBalance),//兑换后金额
		"remark":remark//备注
	}
	return exchangeJson;
}

//20170121:积分兑换凭条数据 Add by dph
function getExchangeData(json) {
	var dataMap = languageSetting['exchangeReceipt'];
	var width = parseInt(json['receipt_template']['width']);
	var length = getLineLength(width);
	var printData = ['\x1b\x40'];
	
	printData.push(buildCenter(dataMap['title'], length));
	printData.push(' \n');
	
	printData.push('{logo}');
	printData.push(' \n');
	
	buildReceiptHeader(json['header_text'], length, printData);
	
	for(var i = 0; i < length; i++) {
		printData.push('-');
	}
	printData.push('\n');
	
	var size = length / 2;
	
	buildReceiptValue(json, dataMap, printData, 'date', size);
	buildReceiptValue(json, dataMap, printData, 'auth_username', size);
	buildReceiptValue(json, dataMap, printData, 'customer_code', size);
	buildReceiptValue(json, dataMap, printData, 'customer_name', size);
	buildReceiptValue(json, dataMap, printData, 'point', size);
	buildReceiptValue(json, dataMap, printData, 'balance', size);
	buildReceiptValue(json, dataMap, printData, 'bookPoint', size);
	buildReceiptValue(json, dataMap, printData, 'newPoint', size);
	buildReceiptValue(json, dataMap, printData, 'bookBalance', size);
	buildReceiptValue(json, dataMap, printData, 'newBalance', size);
	
	buildReceiptRemark(json, printData, 'remark');
	if(58 == width) {
		printData.push(" \n \n");
	}
	
	return printData;
}

//ADD BY CPQ pc会员充值凭条JSON
function genDepositJson(){
	var customerInfo = JSON.parse(localStorage.getItem("CURRENT_CUSTOMER"));
	var date = $("input:hidden[name='deposit_date']").val();//从服务器端返回的
	var authUsername = $("#auth_username").val();
	var customerCode = getCustomerProperty("customer_code");
//	var customerName = getCookie("cCustomerName");
	var customerName = customerInfo.customer_name;
	
	var deposit = $("#deposit_amount").val();
	var pay = $("#deposit_pay").val();
	var point = $("#deposit_point").val();
	var bookBalance = $("#deposit_bookbalance").val();
	var balance = parseFloat(bookBalance)+parseFloat(deposit);
	var bookPoint = $("#deposit_bookpoint").val();
	var newPoint = parseFloat(bookPoint)+parseFloat(point);
	var remark = $("#deposit_remark").val();
	
	var depositJson = {
		"date":date,//充值时间
		"auth_username":authUsername,//操作人员
		"customer_code":customerCode,//会员号
		"customer_name":customerName,//会员名
		"deposit":doDecimal(deposit),//充值金额
		"pay":doDecimal(pay),//支付金额
		"point":doDecimal(point),//赠送积分
		"bookBalance":doDecimal(bookBalance),//充值前余额
		"balance":doDecimal(balance),//充值后余额
		"bookPoint":doDecimal(bookPoint),//充值前积分
		"newPoint":doDecimal(newPoint),//充值后积分
		"remark":remark//备注
	}
	return depositJson;
}

// 20170121:会员充值凭条数据 Add by dph
function getDepositData(json) {
	var dataMap = languageSetting['depositReceipt'];
	var width = parseInt(json['receipt_template']['width']);
	var length = getLineLength(width);
	var printData = ['\x1b\x40'];
	
	printData.push(buildCenter(dataMap['title'], length));
	printData.push('\n');
	
	printData.push('{logo}');
	printData.push('\n');
	
	buildReceiptHeader(json['header_text'], length, printData);
	
	for(var i = 0; i < length; i++) {
		printData.push('-');
	}
	printData.push('\n');
	
	var size = length / 2;
	
	buildReceiptValue(json, dataMap, printData, 'date', size);
	buildReceiptValue(json, dataMap, printData, 'auth_username', size);
	buildReceiptValue(json, dataMap, printData, 'customer_code', size);
	buildReceiptValue(json, dataMap, printData, 'customer_name', size);
	buildReceiptValue(json, dataMap, printData, 'deposit', size);
	buildReceiptValue(json, dataMap, printData, 'pay', size);
	buildReceiptValue(json, dataMap, printData, 'point', size);
	buildReceiptValue(json, dataMap, printData, 'bookBalance', size);
	buildReceiptValue(json, dataMap, printData, 'balance', size);
	buildReceiptValue(json, dataMap, printData, 'bookPoint', size);
	buildReceiptValue(json, dataMap, printData, 'newPoint', size);
	
	buildReceiptRemark(json, printData, 'remark');
	if(58 == width) {
		printData.push(" \n \n");
	}
	
	return printData;
}

//ADD BY CPQ pc积分兑换礼品凭条JSON
function genExchangeGiftJson(){
	var customerInfo = JSON.parse(localStorage.getItem("CURRENT_CUSTOMER"));
	var date = $("input:hidden[name='exchange_date']").val();//从服务器端返回的
	var authUsername = $("#auth_username").val();
	
	var customer = JSON.parse(sessionStorage.getItem("CURRENT_GIFTEX_CUSTOMER"));
	var customerCode = customer.customerNo
	var customerName = customer.customerName;
	var totalExPoint = parseFloat($("#total_giftex_point").text());
	var bookPoint = customer.point + totalExPoint;
	var point = totalExPoint;
	var newPoint = customer.point;
	
	var totalQty = 0;
	var products = [];
	$("#giftex_products tbody tr").each(function(){
		var qty = $(this).find(".qty").val()*1;
		
		if(!qty || qty == 0) return;
		var subtotalPoint = $(this).find(".subtotal_ex_point").text()*1;
		var productName = $(this).find(".product_name").val();
		var barcode = $(this).find(".barcode").val();
		
		var product = {
			"product_name":productName,
			"barcode":barcode,
			"qty":qty,
			"subtotal_point":subtotalPoint
		}
		products.push(product);
		totalQty += qty;
	})
	
	var exchangeJson = {
		"date":date,//兑换时间
		"auth_username":authUsername,//操作人员
		"customer_code":customerCode,//会员号
		"customer_name":customerName,//会员名
		"point":doDecimal(point),//兑换积分
		"bookPoint":doDecimal(bookPoint),//兑换前积分
		"newPoint":doDecimal(newPoint),//兑换后积分
		"products":products,
		"totalQty":totalQty
	}
	return exchangeJson;
}

//20170121:积分兑换礼品凭条数据 Add by dph
function getExchangeGiftData(json) {
	var dataMap = languageSetting['exchangeGiftReceipt'];
	var productTitle = languageSetting['productTitle'];
	var commonTitle = languageSetting['commonTitle'];
	
	var width = parseInt(json['receipt_template']['width']);
	var length = getLineLength(width);
	var printData = ['\x1b\x40'];
	
	printData.push(buildCenter(dataMap['title'], length));
	printData.push('\n');
	
	printData.push('{logo}');
	printData.push('\n');
	
	buildReceiptHeader(json['header_text'], length, printData);
	
	var seperator = "";
	for(var i = 0; i < length; i++){
		seperator += "-"
	}
	
	printData.push(seperator + '\n');
	
	var size = length / 2;
	
	buildReceiptValue(json, dataMap, printData, 'date', size);
	buildReceiptValue(json, dataMap, printData, 'auth_username', size);
	buildReceiptValue(json, dataMap, printData, 'customer_code', size);
	buildReceiptValue(json, dataMap, printData, 'customer_name', size);
	buildReceiptValue(json, dataMap, printData, 'point', size);
	buildReceiptValue(json, dataMap, printData, 'bookPoint', size);
	buildReceiptValue(json, dataMap, printData, 'newPoint', size);
	
	var products = json.products;
	var titleNameBarcode = productTitle.name_barcode + " ";
	var titleQty = productTitle.qty + " ";
	var titleExchangePoint = productTitle.exchange_point;
	
	var titleArray = [titleNameBarcode,titleQty,titleExchangePoint];
	var lenArray = [15,8,9];
	if(76 == width){
		lenArray = [21,14,13];
	}else if(80 == width){
		lenArray = [15,14,13];
	}
	
	printData.push("\n" + seperator + "\n");
	
	setTitle(printData,titleArray,lenArray,titleArray.length,length);
	
	for(var i in products){
		var p = products[i];
		var name = p.product_name;
		var barcode = p.barcode + " ";
		var qty = p.qty;
		var subtotal = p.subtotal_point
		
		var nameByteLength = getStringLength(name);
		if(nameByteLength > length){
			if(cust_prop != ""){//有颜色尺码的截断前方
				name = cropPreString(name,nameByteLength - length );
			}else{//否则截断后方
				name = cropString(name,length );
			}
		}
		printData.push(name);
		if(nameByteLength < length){
			genWhiteSpace(printData,length - nameByteLength);
		}
		printData.push("\n");
		
		var barcodeLen = barcode.length;
		var bacodePrintLen = lenArray[0];
		
		if(barcodeLen > bacodePrintLen){
			barcodeLen = printBarcode(printData,barcode,barcodeLen,length,bacodePrintLen,true);
		}else{
			printData.push(barcode);
		}
		
		genWhiteSpace(printData,bacodePrintLen - barcodeLen);
		
		printData.push(qty);
		genWhiteSpace(printData,lenArray[1] - (qty + "").length);
		
		genWhiteSpace(printData,lenArray[2] - (subtotal + "").length);
		printData.push(subtotal+"\n");
	}
	
	printData.push(seperator + '\n');
	printData.push("\n合计");
	genWhiteSpace(printData,lenArray[0] - 4);
	
	var totalQty = json.totalQty + "";
	var point = json.point + "";
	
	printData.push(totalQty);
	genWhiteSpace(printData,lenArray[1] - totalQty.length);
	genWhiteSpace(printData,lenArray[2] - point.length);
	printData.push(point);
	
	printData.push("\n");
	
	var spaces = "\x1b\x40\n\n";
    switch (width) {
        case 76 : //小票（详细）
        case 80 : //小票（详细）
        	spaces += "\n\n";
            break;
    }
    printData.push(spaces);
    
	if(58 == width) {
		printData.push(" \n \n \n \n");
	}
	
	return printData;
}

//积分兑换礼品 START
//搜索会员
function searchGiftCustomer(q) {
	if(!online){
		message("网络连接断开！请检查网络连接！")
		return;
	}
	if(!q){
		message("请输入会员卡号或手机号!");
		return;
	}
	
	// 搜索web sql
	db.transaction(function(tx) {
		tx.executeSql("SELECT * FROM CUSTOMERS WHERE company_id=? AND (outlet_id=? OR shared=1) AND  del_flag=0 AND (customer_code = ? OR phone_number = ?) AND enabled = 1", [companyId, outletId,q,q], function(tx, results) {
			var len = results.rows.length;
			if(len==0){
				message("没有找到会员！");
				return;
			}			
			
			if (len > 0) {
				var item = results.rows.item(0);
				$("#giftex_main_div").find(".c_info").each(function(){
					var field = $(this).data("field");
					var value = item[field];
					if(field == "point"){
						value = doDecimal(value);
					}
					$(this).text(value);
				});
				//无有效期的为永久
				if(!item.expired_date){
					$("#giftex_main_div span[data-field='expired_date']").text('永久');
				}
				//是否共享
				$("#giftex_main_div .shared_span").text(item.shared == 1 ? "共享":"私有");
				//店铺
				$("#giftex_main_div .customer_outlet_span").text(getSetting("oName"));
				
				var current_gift_customer = {
						customerId:item.customer_id,
						customerNo:item.customer_code,
						phone_number:item.phone_number,
						customerName:item.customer_name,
						point:item.point,
						tc_balance:item.tc_balance
				}
				//启用密码 ADD BY CPQ
				$("#giftex_c_password_enabled").val(item.password_enabled);
				sessionStorage.setItem("CURRENT_GIFTEX_CUSTOMER",JSON.stringify(current_gift_customer));
				
				resizeGiftexWindow();
				
				$("#giftex_btn_div").removeClass("hidden");
				$("#giftex_main_div").removeClass("hidden");
				$("#giftex_products tbody").empty();
				$("#giftex_product_barcode").select();
				
				goToPage4GiftEx("first");
			}

		}, null);
	});
}

//屏幕自适应
function resizeGiftexWindow(){
	var window_height = $(window).height();//屏幕高度
	var height = window_height - 169;
	$("#giftex_products_div .panel-body").outerHeight(height - 67 - 54);
	$("#giftex_main_div .panel-card").parent().outerHeight(height);
	$("#giftex_products_div .panel-body").scroll(function(){
		$(this).find("thead th").css("top",$(this).scrollTop());
	})
}

function goToPage4GiftEx(addPage){
	var page = 1;
	var pageCount = $("#giftex_product_list_pageCard").find(".page_count").text();
	var currentPage = $("#giftex_product_list_pageCard .currentPage").val();
	if(addPage == 'last'){
		page = pageCount;
	}else if(addPage == 'current'){
		page = currentPage;
	}else if(addPage != 'first'){
		page = currentPage*1 + addPage;
	}
	
	$("#giftex_product_list_pageCard .currentPage").val(page);
	searchGiftProducts($("#giftex_product_barcode").val());
}

function searchGiftProducts(q){
	// var productJsonStr = "";
	$("#giftex_products tbody").empty();
	 
	var pageSize = parseInt($("#giftex_product_list_pageCard .pageSize").val() || 50);
	var currentPage = parseInt($("#giftex_product_list_pageCard .currentPage").val() || 1);
	var pageCount = 1;
	
	var customer = JSON.parse(sessionStorage.getItem("CURRENT_GIFTEX_CUSTOMER"))
	
	$("#giftex_product_list_pageCard").find(".first_arrow,.pre_arrow").removeClass("btn-primary").addClass("btn-default disabled");
	$("#giftex_product_list_pageCard").find(".last_arrow,.next_arrow").removeClass("btn-primary").addClass("btn-default disabled");
	var qPart = "";
	if(q){
		qPart = " AND (p.barcode LIKE '%" + q.toUpperCase() + "%'" +
		" OR p.item_no LIKE '%" + q + "%'" +
		" OR p.product_name LIKE '%" + q + "%'" +
		" OR p.pinyin_code LIKE '%" + q + "%')"
	}
	db.transaction(function(tx) {
		var sql = " FROM PRODUCTS p "+
				" WHERE p.company_id=? AND p.outlet_id=? AND p.active='ON' AND p.del_flag=0"+
				" AND p.point_exchange_enabled == 1 AND p.exchange_point <= ?" +
				qPart;
		
		tx.executeSql(
				"SELECT COUNT(p.product_id) AS item_count "+ sql
				, [companyId, outletId,customer.point], function(count_tx, count_results) {
			
			if (count_results.rows.length > 0) {
				var count = count_results.rows.item(0).item_count;
				if(count > 0){
					pageCount = Math.ceil(count*1.0 / pageSize)
				}
				
				if(currentPage > pageCount){
					currentPage = pageCount;
					$("#giftex_product_list_pageCard .currentPage").val(currentPage);
				}
				
				if(currentPage > 1){
					$("#giftex_product_list_pageCard").find(".first_arrow,.pre_arrow").addClass("btn-primary").removeClass("btn-default disabled");
				}
				if(currentPage < pageCount){
					$("#giftex_product_list_pageCard").find(".last_arrow,.next_arrow").addClass("btn-primary").removeClass("btn-default disabled");
				}
				
				$("#giftex_product_list_pageCard").find("._count").text(count);
				$("#giftex_product_list_pageCard").find(".page_count").text(pageCount);
			}
			
			var start = (currentPage - 1)*pageSize;
			
			tx.executeSql(
					" SELECT p.* "+ sql +" limit ?,?"
					, [companyId, outletId,customer.point,start,pageSize], function(item_tx, item_result) {
				
				if (item_result.rows.length > 0) {
					for ( var i = 0; i < item_result.rows.length; i++) {
						var item = item_result.rows.item(i);
						var productName = item.product_name+(item.have_cust_prop == 1 && item.cust_props ? ("("+item.cust_props+")") : "");
						var _tr = "<tr><td>" +
							"<input type='hidden' class='product_id' value='"+item.product_id+"'>"+
							"<input type='hidden' class='product_name' value='"+productName+"'>"+
							"<input type='hidden' class='barcode' value='"+item.product_id+"'>"+
							"<input type='hidden' class='exchange_point' value='"+item.exchange_point+"'>"+
							(i+1)+"</td>" +
							"<td>"+productName
							+"<br />"+item.barcode+"</td>" +
							"<td>"+doDecimal(item.exchange_point)+"</td>" +
							"<td><input type='number' min='0' class='form-control md-input qty' value='0' onkeyup='calcTotalExPoint(this);' onchange='calcTotalExPoint(this);'></td>" +
							"<td class='subtotal_ex_point'>0.00</td></tr>";
					
						$("#giftex_products tbody").append(_tr);
					}
				}else{
					message("没有可以兑换的礼品.");
				}

			});
		});
	});
}

function calcTotalExPoint(_this){
	var _tr = $(_this).parents("tr");
	var qty = $(_this).val();
	var exPoint = _tr.find(".exchange_point").val();
	_tr.find(".subtotal_ex_point").text(doDecimal(qty * exPoint));
	
	var totalExPoint = 0;
	$("#giftex_products tbody .subtotal_ex_point").each(function(){
		totalExPoint += $(this).text()*1;
	})
	
	$("#total_giftex_point").text(doDecimal(totalExPoint));
	$("#btn_save_giftex").prop("disabled",totalExPoint <= 0);
}

function saveGiftexPre(){
	var totalExPoint = parseFloat($("#total_giftex_point").text());
	var customer = JSON.parse(sessionStorage.getItem("CURRENT_GIFTEX_CUSTOMER"))
	
	if(totalExPoint <= 0){
		return;
	}
	
	if(totalExPoint > customer.point){
		message("积分不足，无法兑换.");
		return;
	}
	
	var passwordEnabled = $("#gift_c_password_enabled").val();
	if(passwordEnabled == 1){
		$("#giftExPasswordModal").modal("show");
	}else{
		saveGiftex();
	}
}

function saveGiftex(){
	if(!online){
		message("网络连接断开！请检查网络连接！")
		return;
	}
	var customer = JSON.parse(sessionStorage.getItem("CURRENT_GIFTEX_CUSTOMER"));
	
	var password = $("#giftex_password").val();
	var passwordEnabled = $("#gift_c_password_enabled").val();
	var totalExPoint = parseFloat($("#total_giftex_point").text());
	var productQtyJsons = [];
	var productIds = [];
	$("#giftex_products tbody tr").each(function(){
		var productId = $(this).find(".product_id").val();
		var barcode = $(this).find(".barcode").val();
		var qty = $(this).find(".qty").val();
		
		if(!qty || qty == 0) return;
		
		var productQtyJson = {
			"product_id":productId,
			"barcode":barcode,
			"qty":qty
		};
		productQtyJsons.push(productQtyJson);
		productIds.push(productId);
	})
	
	$("#btn_save_giftex").prop("disabled",true);
	const $point = $("#pointExchangeGiftModal .c_info[data-field='point']");
	let customerPoint = parseFloat($point.text());
	$point.text(doDecimal(customerPoint - totalExPoint));
	$.ajax({
		url:apiurl + "pointExchangeProduct",
		type:"post",
		dataType:"json",
		data:{
			"customerId":customer.customerId,
			"password":password,
			"passwordEnabled":passwordEnabled,
			"totalPoint":totalExPoint,
			"productIds":productIds.join(","),
			"productQtyJsons":JSON.stringify(productQtyJsons)
		},
		success:function(result){
			if(!result){
				$point.text(customerPoint);
				message("发生未知错误.");
				$("#btn_save_giftex").prop("disabled",false);
				return;
			}
			
			message(result.msg);
			if(result.code != "SUCCESS") return;
			
			customer.point = result.newPoint;
			sessionStorage.setItem("CURRENT_GIFTEX_CUSTOMER",JSON.stringify(customer));

			// 优先画出扣减积分
			$("#pointExchangeGiftModal .c_info[data-field='point']").text(doDecimal(result.newPoint));

			if($("#geftex_print").prop("checked")){
				$("input:hidden[name='exchange_date']").val(result.updateDate);
				printExchangeGiftReceipt();
			}
			
			$("#giftex_products tbody tr .qty").val(0).each(function(){
				calcTotalExPoint(this);
			});
			
			db.transaction(function(tx){
				//更新本地会员数据
				tx.executeSql('UPDATE CUSTOMERS SET point = ? , update_date = ? WHERE company_id = ? AND  customer_id = ? ', 
					[result.newPoint,  result.updateDate, companyId, customer.customerId], 
				null,function(tx,error){
					console.log(error.message)
				});
			})
		},
		error:function(){
			$point.text(customerPoint);
			message("网络连接错误，请检查网络连接.");
			$("#btn_save_giftex").prop("disabled",false);
		}
	});
}
//积分兑换礼品 END