//###################################################################################
//############################# 同步与初始化的JAVASCRIPT ##############################
//###################################################################################

//注意:本JS需要较早载入
console.log("*** 定义全局变量:db,localStorage,cid,oid,apiurl ***");
var db = openDatabase('QUICK_POS', '1.0', 'QuickPOS DB', 5 * 1024 * 1024);
var localStorage = window.localStorage;//简单持久化存储
var sessionStorage = window.sessionStorage;//会话期内有效,用于代替V1中的cookie

var apiurl = browser.versions.nw && global.window.apiurl || localStorage.getItem('apiurl') || "";//API路径,用于客户端
console.log("*** apiurl->"+apiurl);

var companyId = (JSON.parse(localStorage.getItem("LOGINED_OUTLET"))).company_id;
var outletId = (JSON.parse(localStorage.getItem("LOGINED_OUTLET"))).outlet_id;
console.log(" company ID,outlet ID->",companyId,outletId);
var parseQKCount=0;//橱窗解析次数,临时
var firstSyncQk = false;
//*****************************************************
//****************** sync *******************
//*****************************************************

function sync4download(callback) {
	console.log('*******执行sync4download()*******');
	if (!online){
		console.log('*******sync exit of offline.');
		return;
	}
	
	var oCookie = getCookie("_pos_console_syncing");
	//console.log('***** error :'+eventSource.readyState + ':'+oCookie);
//	if (oCookie && oCookie.length>0){
//		console.log('***** warning : other sync is in action. exiting...');
//		return;
//	}
	setCookieExpireOnSeconds('_pos_console_syncing','SYNC',10);//30>10,by fandy

	//add by JIM: add mask while syncing 加入遮罩防止同步未完成时候操作
	//maskWait();
	//$("#icon_sync").attr("src","images/icon_sync.gif");
	$('#net_icon').addClass('rotate');
	
	// 同步数据,
	TABLES_TO_SYNC = [ {
		tableName : 'products',
		idName : 'product_id',
		direction : 'download'
	},	
	{
		tableName : 'stocks',//v2.1:库存独立同步
		idName : 'stock_id',
		direction : 'download'
	},{
		tableName : 'promotions',
		idName : 'promotion_id',
		direction : 'download'
	},{
		tableName : 'promotionproducts',
		idName : 'promotion_product_id',
		direction : 'download'
	}, {
		tableName : 'users',
		idName : 'user_id',
		direction : 'download'
	}, {
		tableName : 'employees',
		idName : 'employee_id',
		direction : 'download'
	},{//V2:次卡商品下行 ADD BY CPQ
		tableName : 'timecardproducts',
		idName : 'id',
		direction : 'download'
	},{//V2:口味下行 ADD BY CPQ
		tableName : 'tastes',
		idName : 'id',
		direction : 'download'
	}, {
		tableName : 'saleorders'
	}, {
		tableName : 'saleorderitems'
	}, {
		tableName : 'payrecords'
	} , {
		tableName : 'customerchanges'
	} , {
		tableName : 'customers',
		idName : 'customer_id',
		direction : 'download'
	},{//V2:交班记录上行
		tableName : 'shiftrecords'
	}];
	
	DBSYNC.initSync(TABLES_TO_SYNC, db, sync_info, apiurl+'syncOfflineResouces', function() {
		// database synced
	});
	
	// DBSYNC.firstSync=true;
	DBSYNC.syncNow(callBackSyncProgress, function(result) {
		if (result.syncOK === true) {
			console.log('*******data sync completed.');

			let day = result.serverAnswer && result.serverAnswer.expiredDays;
			if(day && day < 8) {
				alert(`温馨提醒您，您的账号距离到期仅剩${day}天，为了不影响后期使用，可在软件右上角联系客服续费`);
			}

			if (typeof(callback) == 'function'){
				callback();
			}
			updateCustomerInfo( getCustomerProperty("customer_id") )//V2:会员变更后,会触发同步,同步后重设当前会员的LS,否则当前会员的信息将不准
			saveLastSync();	
			
			//还原PRODUCTS表库存 > 设计有误,不起作用
			//restoreProductStock();
			
		}else{
			if(result.message){
				alert(result.message);
			}else{
				alert("在获取数据时发生了错误。");
			}
		}
		//closeAllBootbox();
		//$("#icon_sync").attr("src","images/icon_online.png");
		$('#net_icon').removeClass('rotate');
		$("#initModal").modal("hide");

		//会员生日提醒 ADD BY CPQ 20161117
		reminderCustomerBirthday();
		
		delCookie("_pos_console_syncing");
	});
	
}

//收银后立即同步上行:saleorders,saleorderitems,payrecords,customerchanges,下行:customers,3-19,by fandy
function syncAfterPay(mask){
	console.log('*******执行syncAfterPay()*******');
	
	if (!online){
		console.log('*******sync exit of offline.');
		return;
	}
	
	var oCookie=getCookie("_pos_console_syncing");
	//console.log('***** error :'+eventSource.readyState + ':'+oCookie);
//	if (oCookie && oCookie.length>0){
//		console.log('***** warning : other sync is in action. exiting...');
//		return;
//	}
	setCookieExpireOnSeconds('_pos_console_syncing','SYNC',10);//30>10,by fandy
	
	//if (mask) maskWait();
	//maskWait();
	$('#net_icon').addClass('rotate'); 
	//$("#icon_sync").attr("src","images/icon_sync.gif");
	
	var sync_info = {
		info : {}
	};
	// 同步数据,
	TABLES_TO_SYNC = [ {
		tableName : 'saleorders'
	}, {
		tableName : 'saleorderitems'
	}, {
		tableName : 'payrecords'
	} , {
		tableName : 'customerchanges'
	}
	];
	DBSYNC.initSync(TABLES_TO_SYNC, db, sync_info, apiurl+'uploadSellInfo', function() {
		// database synced
	});
	// DBSYNC.firstSync=true;
	DBSYNC.syncNow(callBackSyncProgress, function(result) {
		if (result.syncOK != true) {
			alert("数据同步错误！");
		}
		else{
			console.log('*******data sync completed after pay.');
			saveLastSync();
		}
		
		//closeAllBootbox();
		//$("#icon_sync").attr("src","images/icon_online.png");
		$('#net_icon').removeClass('rotate'); 
		$("#initModal").modal("hide");
		
		delCookie("_pos_console_syncing");
	});
}


function callBackSyncProgress(message, percent, msgKey) {
	console.log('firstSync:' + DBSYNC.firstSync);
	console.log('sync progress:' + percent +'%');
	if(DBSYNC.firstSync){
		//数据同步中关闭后需要重新自适应计算
		$("#initModal").one("hidden.bs.modal", function(){
			resizeMainDiv();
		});
		$("#initModal").modal({
			backdrop:'static',
			keyboard:false,
			show:true
		});
		//$('#progressMessage').html(message + ' (' + percent + '%)');
		$('#progressMessage').html(percent + '%');
		$('#progress').css('width', percent + '%');
		
		firstSyncQk = true;
	}
	
	if(percent>=100){
		$('#net_icon').removeClass('rotate'); 
		$("#initModal").modal("hide");
		
		checkQuickKey(function(showDialog){
			//设置默认橱窗时，会开启事务，在那里面弹出dialog，这边就不在弹出
			if(showDialog && firstSyncQk){
				bootbox.dialog({
					  message: "正在加载橱窗...",
					  buttons: {},
					  closeButton: false,
					  className:"qk_dialog"
				});
			}

			loadCart();
			verifyQK(parseQuickKeys);
		});
	}
}


function syncCashierSetting(){
	if (!online){
		console.log('*******sync setting exit of offline.');
		return;
	}
	
	$.ajax({
		async : false,		
		url : apiurl+"getSettingJson",
		dataType : "json",
		success : function(result) {
			//console.log("##############################"+jQuery.isEmptyObject(result));
			//返回JSON不空,则更新
			if(!jQuery.isEmptyObject(result)){
				localStorage.setItem("settings", JSON.stringify(result));
				console.log("*** sync setting completed ***");
				
				sessionStorage.setItem("_server_setting_version",new Date().getTime());//更新本地setting version
				
				setPriceType(getSetting("cPriceType"));//收银设置变更后,需要重置价格模式
				
				var industryFlag = getSetting("Industry") == "1002";
				getSetting("timeCardEnabled")==1 && industryFlag ?$("#btnTimeCard").show():$("#btnTimeCard").hide();//次卡开启状态
				industryFlag ? $("#btnStorage").show() : $("#btnStorage").hide();//寄存
				
				//初始化桌号 ADD BY CPQ
				if(getSetting("Industry") == '1003'){
					if(getSetting("desk_no_enabled") == 1){
						getDeskNoJson(true);
					}else{
						initDeskNo();
					}
				}

				var servicePhone = getSetting("service_phone");
				if(servicePhone){
					$("#service_phone").text(servicePhone.replace(/(\d{3})(\d{4})(\d{4})/,'$1 $2 $3'));
				}

				var serviceWangwang = getSetting("service_wangwang");
				if(serviceWangwang){
					$("#service_wangwang").text(serviceWangwang);
				}

				var serviceTaobao = getSetting("service_taobao");
				if(serviceTaobao){
					$("#service_taobao").text(serviceTaobao.replace(/http(s{0,1}):\/\//, ""));
				}
			}
			else{
				console.log("*** setting is no change ***");
			}
		}
	});
}



//*****************************************************
//********************* page init *********************
//*****************************************************

//小票、桌号数据
function checkOutletSettings() {
	console.log("--------------- 检查小票设置,QK设置 ---------------");	
	//本地不存在:在线时,去服务器端取,离线时,生成默认小票设置.QK不用生成	
	var rcpJson = localStorage.getItem("PRINTER_RCP");
	//存在，需转为JSON对象，好取得outlet_id ADD BY CPQ
	if(rcpJson && rcpJson != "{}"){
		rcpJson = JSON.parse(rcpJson);
	}
	if(!rcpJson || rcpJson.outlet_id != outletId){//如果为空，//或者不属于当前店铺的 ADD BY CPQ
		$.ajax({
			url:apiurl+"getOutletSettingJson",
			data:{"key":"PRINTER_RCP"},
			type:"POST",
			success:function(result){
				if(!result.outlet_id){
					
				}
				localStorage.setItem("PRINTER_RCP",JSON.stringify(result));
			},
			error:function(){//离线或出错时,设为默认的
				setDefaultRCP();
			}
		});		
	}
	
	if(getSetting("Industry") == "1003"){
		var deskNo = localStorage.getItem("DESK_NO");
		if(deskNo){
			deskNo = JSON.parse(deskNo);
		}
		
		if(!deskNo || deskNo.outlet_id != outletId){
			getDeskNoJson(false);
		}
	}
	
	//检查标签设置
	var GP_NAME = "GOODS_PRINTER";
	var lblJson = localStorage.getItem(GP_NAME);
	if(lblJson && lblJson != "{}"){
		lblJson = JSON.parse(lblJson);
	}
	if(!lblJson || (lblJson.length > 0 && lblJson[0].outlet_id != outletId)){
		$.ajax({
			url:apiurl+"getOutletSettingJson",
			data:{"key":GP_NAME},
			type:"POST",
			success:function(result){
				if(result && !$.isEmptyObject(result)){
					localStorage.setItem(GP_NAME,JSON.stringify(result));
				}else{
					setDefaultLbl();
				}
			},
			error:function(){//离线或出错时,设为默认的
				setDefaultLbl();
			}
		});
	}
}

function checkQuickKey(callback){
	//v2.1:改为本地没有QKLS时,不从服务器端取,而是提醒用户去设置
	var qkJson = localStorage.getItem("QUICKKEY");
	//存在，需转为JSON对象，好取得outlet_id ADD BY CPQ
	if(qkJson && qkJson != "{}"){
		qkJson = JSON.parse(qkJson);
	}
	//如果为空,或是第一次同同步时，橱窗数组长度为0时，取得备份橱窗设置，没有备份则设置默认QK
	if(!qkJson || qkJson.outlet_id != outletId || (qkJson.quickkeys.length == 0 && firstSyncQk)){
//		setDefaultQk();
		$.ajax({
			url:apiurl+"getOutletSettingJson",
			data:{"key":"QUICKKEY"},
			type:"POST",
			success:function(result){
				if(result && !$.isEmptyObject(result)){
					localStorage.setItem("QUICKKEY",JSON.stringify(result));
					
					if(typeof callback === 'function') callback(true);
				}else{
					setDefaultQk(callback);
				}
			},
			error:function(){
				setDefaultQk(callback);
			}
		});
	}
}

//取得桌号设置
//flag true : 初始化桌号，false 不初始化桌号
function getDeskNoJson(flag){
	$.ajax({
		url:apiurl+"getOutletSettingJson",
		data:{"key":"DESK_NO"},
		type:"POST",
		success:function(result){
			if(result && !$.isEmptyObject(result)){
				localStorage.setItem("DESK_NO",JSON.stringify(result));
			}else{
				localStorage.removeItem("DESK_NO");
			}
			if(flag) initDeskNo();
		},
		error:function(){
			localStorage.removeItem("DESK_NO");
			if(flag) initDeskNo();
		}
	});
}

//默认橱窗
function setDefaultQk(callback){
	var defaultLayout = getSetting("industry")=='1004'?'FULL':'QK';
	var quickKey = {
		"outlet_id":outletId,
		"layout":defaultLayout,
	    "textOrImage":"0",
	    "promotionQKEnabled":0
	}
	
	if(firstSyncQk){
		bootbox.dialog({
			  message: "正在加载橱窗...",
			  buttons: {},
			  closeButton: false,
			  className:"qk_dialog"
		});
	}
	db.transaction(function (tx) {
//		var companyId = getSetting("cId");
//		var outletId = getSetting("oId");
		tx.executeSql(
				"SELECT * FROM PRODUCTS WHERE del_flag=0  AND active = 'ON' AND company_id = ? AND outlet_id = ?  GROUP BY barcode LIMIT 0,20", 
				[companyId,outletId], 
		function (tx, results) {
			var _qks = [];//橱窗列表
			var products = [];
			//var temp = {};//过滤同码商品用
			for (var i=0;i<results.rows.length;i++){
				if(products.length > 20) break;
				var line=results.rows.item(i);
				//同码商品只取一个
				//if(!temp[line.barcode]){
					//temp[line.barcode] = true;
					var product = {//用于更新QK LS的商品,不需要详细属性
						"product_id" : line.product_id,
						"bg_color" : "#e8eaf6",
					};
					
					products.push(product);
				//}
			}
			var qk = {"临时橱窗":products};
			_qks.push(qk);
			quickKey.quickkeys = _qks;
			
			localStorage.setItem("QUICKKEY",JSON.stringify(quickKey));
			
			if(typeof callback === 'function') callback(false);
		},
		function (tx, error) {
			console.log('查询失败: ' + error.message);
		});
	});
}

//设置默认小票
function setDefaultRCP(){
	var defaultRcpJson = {
		    "printer":{
		        "default_printer":"",
		        "default_printer_android":"",
		        "default_printer_mac":"",
		        "default_printer_ios":"",
		        "ip":"",
		        "port":"",
		        "paper_cut":false,
		        "print_copy":1
		    },
		    "receipt_template":{
		        "width":58,
		        "template":"58-1"
		    },
		    "header_logo":"",
		    "outlet_name":getSetting("oName"),
		    "header_text":"",
		    "footer_text":"欢迎再次光临",
		    "QR_code":"",
		    "cPrintEnabled":0,
		    "showCurrencySymbol":false,
		    "currencySymbol":"￥",
		    "customSettings":{
		        "customed":false
		    },
		    outlet_id:outletId
		}
	
	localStorage.setItem("PRINTER_RCP",JSON.stringify(defaultRcpJson));
}

function setDefaultLbl(){
	var industry = getSetting("Industry");
	var fieldMap = languageSetting.labelSetting;
	
	var defaultLblJson = [{
    	"outlet_id":outletId,
        "label_margin_top":0,
        "label_width":"40",
        "label_height":"30",
        "h_offset":0,
        "v_offset":0,
        "bar_height":30,
        "name_len":null,
        "printer":{
	        "default_printer":"",
	        "default_printer_android":"",
	        "default_printer_mac":"",
	        "default_printer_ios":"",
	        "ip":"",
	        "port":"",
	        "mac":"",
	        "vendorId":"",
	        "productId":""
	    },
        "type":"code128",
        "lines":[
            {
                "field":"barcode-img",
                "special_line":true,
            },
            {
                "field":"barcode",
                "special_line":true,
            },
            {
                "field":"product_name",
                "title":fieldMap["product_name"]
            },
            {
                "field":"price",
                "title":fieldMap["price"]
            }
        ],
        "temp_name":"初始模板40*30",
        "is_systemp":1,
        "id":"SYS-1",
        "default":1,
        "print_width":"",
        "print_barcode_text":true
    }];
	
	if(industry == 1001 || industry == 1002){
		
		defaultLblJson[0].lines.push({
            "field":"color",
            "title":fieldMap["color"]
        });
		
		defaultLblJson[0].lines.push({
            "field":"size",
            "title":fieldMap["size"]
        });
	}
	
	localStorage.setItem("GOODS_PRINTER",JSON.stringify(defaultLblJson));
}

//设置临时桌号 ADD BY CPQ
function setDefaultDeskNo(){
	var json = {
		    "outlet_id":outletId,
		    "desk_nos":{
		        "临时区域":[
		            {"name":"临时桌1"},
		            {"name":"临时桌2"},
		            {"name":"临时桌3"},
		            {"name":"临时桌4"},
		            {"name":"临时桌5"},
		            {"name":"临时桌6"},
		            {"name":"临时桌7"},
		            {"name":"临时桌8"},
		            {"name":"临时桌9"},
		            {"name":"临时桌10"},
		        ]
		    }
		}
	localStorage.setItem("DESK_NO",JSON.stringify(json));
}

//初始化价格模式
function initPriceType(){
	var val = localStorage.getItem("PRICE_TYPE")!=null&&localStorage.getItem("PRICE_TYPE")!=''?localStorage.getItem("PRICE_TYPE"):getSetting("cPriceType");//无从LS取(可能临时变更)
	console.log("--------------- 初始化价格模式 , pt-> "+val);
	localStorage.setItem("PRICE_TYPE", val);
	$("#price_type").val(val);
	$(".price-type").text(val==0?"零售":"批发");
	$(".price-type")
	.removeClass("bg-info")
	.removeClass("bg-danger")
	.addClass(val==0?"bg-info":"bg-danger");
}

//设置价格模式
function setPriceType(val){
	console.log("---------------  设置价格模式 , pt ->",val);
	$("#price_type").val(val);
	//setCookie("cPriceType", val);
	localStorage.setItem("PRICE_TYPE", val);
	$(".price-type").text(val==0?"零售":"批发");
	$(".price-type")
	.removeClass("bg-info")
	.removeClass("bg-danger")
	.addClass(val==0?"bg-info":"bg-danger");
}

//初始化登录用户信息
function initLoginedUser(){
	
	var loginFlag = sessionStorage.getItem("_LOGIN_FLAG");
	var loginedUser = JSON.parse(sessionStorage.getItem("LOGINED_USER"));
	var loginedOutlet = JSON.parse(localStorage.getItem("LOGINED_OUTLET"));
	
	if(loginFlag=='1'){
		console.log("--------------- 初始化登录用户 --------------- ");
		var username = loginedUser.username;
		var rolename = loginedUser.role_name;
		var roledesc = "";
		//first_name ADD BY CPQ
		var name = loginedUser.first_name;
		//jtoekn ADD BY CPQ
		var jtoken = loginedUser.jtoken;
		$("#auth_id").val(loginedUser.id);
		$("#auth_username").val(username);
		$("#auth_role").val(rolename);
		//first_name ADD BY CPQ
		$("#auth_name").val(name);
		//jtoekn ADD BY CPQ
		$("#modfiyUserPassword_jtoken").val(jtoken);
		
		if(rolename=='ROLE_ADMIN') roledesc = "管理员";
		if(rolename=='ROLE_MANAGER') roledesc = "经理";
		if(rolename=='ROLE_SHOP') roledesc = "店长";
		if(rolename=='ROLE_CASHIER') roledesc = "收银员";		
		
		var uname = username.length>10?username.substring(0,10)+"...":username;
		$('#_logined_user').text(uname+"["+roledesc+"]");
		$('#_logined_outlet_name').text(loginedOutlet.outlet_name);
	}
	
}

//库存独立同步后,恢复商品表中的库存(过渡用)
function restoreProductStock(){
	console.log("--------------- 恢复PRODUCTS表库存 ---------------"+outletId)
	db.transaction(function(tx) {
		tx.executeSql('SELECT * FROM PRODUCTS WHERE del_flag = 0 AND outlet_id = ? ORDER BY product_id DESC', [outletId], 
				function(tx, results) {
			var len = results.rows.length, i;
			console.log("--------------- 商品数 @ restoreProductStock() ->"+len);
			if(len>0){
				for(i=0; i<len; i++){
					var product = results.rows[i];
					getProductStock(tx,product.product_id,function(stockQty){
						//console.log("--------------- 库存 ->"+stockQty);
						tx.executeSql('UPDATE PRODUCTS SET stock = ? WHERE product_id = ?', [stockQty,product.product_id]);
					});
				}
			}
		},function(tx, error) {
			console.log('error: ' + error.message);
		});
	});
}


var inittime=0;

//收银页面初始化:在线状态,logined_outlet/logined_user,QK,购物车,会员,导购等动态区域	
function pageinit(){
	//console.log('************ page init from ' + msg + (++inittime));
	console.log('************ page init ************');	
	
	//初始化Layout(有可能需要解析QK)
	//setLayout();改用callsize
	callsize();
	
	initLoginedUser();//初始化登录用户信息(无论离线与在线)
	
	initPriceType();//设置销售模式
	
	//V2:以下二个都是为了初始化未完成的收银,v2中已不充许有未完成的收银
	//initCustomerInfo(getCustomerProperty("cCustomerCode"));//初始化会员信息> 可升级为在方法体内取得会员号	
	//initEmployees();//初始化导购员信息	
	
	clearCustomerInfo();
	clearCart();
	
	loadCart();//初始化购物车
	
	initParkCount();// 初始化挂单数量
	
	if(!online) verifyQK(parseQuickKeys);
};

// *****************************************************
// EventSource事件处理:handle with ONLINE/OFFLINE/SESSION-TIMEOUT event
//*****************************************************

var online = false;
//var sid = getCookie('JSESSIONID');//非常重要 V2:file://无法使用cookie
var sid = sessionStorage.getItem('JSESSIONID');
var winid= "win"+(new Date()).valueOf();
var server_db_version=0;

var eventSource; 
function startEventSrc() {
	var errCnt=0;
	console.log("***执行startEventSrc()***");
	if (eventSource==null || eventSource.readyState==2) //closed
		eventSource = new EventSource(apiurl+"heartbeat?sid=" + sid + "&st_" + (new Date()).valueOf());
	// when session expired on server: ask for re-login
	// 系统在线并且session过期时，服务器推送：session过期消息，重登陆
	$(eventSource).on('session_expired', function(event) {
		eventSource.close();			
		alert("看起来网络恢复正常了。现在将重新登录。\n您的收银数据不会丢失。", function() {
			//window.location.href = 'login.html'
			logout();
		});
	});
	// any message from server means online, switch to online:网络重新连接,触发同步
	$(eventSource).on('message', function(e) {
		errCnt = 0;
		if (e.originalEvent.data == 'timeout')
			return;
		if (!online) {// 转为在线
			online = true;
			switch2Online();
			
			syncCashierSetting();//收银设置下行
			//syncOutletSettings();//小票设置、QK设置上行:将离线时的设置上行同步
			initNetshopTrade();
			sync4download(function(){verifyQK(parseQuickKeys)});
						
		}
	});

	// error occurs every 3 seconds on reconnecting, if no server messages
	// within 3 errors, switch to offline
	$(eventSource).on('error', function(event) {
		errCnt++;
		if (online && errCnt >= 2) { // AT LEAST 2 times:网络断开,转为离线
			online = false;
			switch2Offline();
		}
		//try to reconnect on error
		if (!online && errCnt>=3) {
			console.log('Restart ES.......');
			event.target.close();
			setTimeout(startEventSrc,5000);
		}		
		//多窗口运行检测(仅用于网页端收银)
		if(browser.versions.webKit){
			var oCookie=getCookie('_pos_console_oprating');
			//var oCookie = localStorage.getItem('_pos_console_oprating');
			if (oCookie && oCookie.length > 0 && oCookie != winid) {
				window.location.href = 'sellerror.html';
				return;
			}
			setCookieExpireOnSeconds('_pos_console_oprating', winid, 10);
		}
	});
	
	
	//服务器端推送触发更新收银设置
	$(eventSource).on('setting_version',function(e) {		
		var server_setting_version = sessionStorage.getItem("_server_setting_version");//取得本地setting version
		if (online 
				//server_setting_version < e.originalEvent.data 表示服务器端有更新
				&& (server_setting_version !=null && server_setting_version < e.originalEvent.data)) {
			console.log("服务器端推送触发更新收银设置",server_setting_version,e.originalEvent.data);
			syncCashierSetting();
			initNetshopTrade();
			server_setting_version = e.originalEvent.data;
			sessionStorage.setItem("_server_setting_version",e.originalEvent.data);//更新本地setting version
		}
	});
	

	// sync request from server:服务器端推送触发下行同步
	$(eventSource).on('db_version',function(e) {
		// if (!ready2init) return;
		if (online 
				//server_db_version < e.originalEvent.data 表示服务器端的DB有更新
				&& (!server_db_version || server_db_version == 'undefined' || server_db_version < e.originalEvent.data)) {
			sync4download(function(){
				verifyQK(parseQuickKeys)}
			);			
			server_db_version = e.originalEvent.data;
			localStorage.setItem("_server_db_version",e.originalEvent.data);//更新本地DB version
		}
	});
	
	//服务器端推送触发清除数据
	$(eventSource).on('clear_cache',function(e) {
		//console.log("服务器端推送触发清除数据",e.originalEvent.data);
		var data = JSON.parse(e.originalEvent.data);
		var table_names = data.table_names;
		var clear_timestamp = data.clear_time;
		var server_db_clear_timestamp = localStorage.getItem("_server_db_clear_timestamp");
		var server_clear_timestamp = 0;
		if(server_db_clear_timestamp){
			if(server_db_clear_timestamp.indexOf("{") != -1){
				server_db_clear_timestamp = JSON.parse(server_db_clear_timestamp);
				server_clear_timestamp = server_db_clear_timestamp[outletId];
			}else{
				server_clear_timestamp = server_db_clear_timestamp || 0;
			}
		}
		//console.log("### server_db_clear_timestamp/clear_timestamp : ",server_db_clear_timestamp,clear_timestamp);
		
		if (online && server_clear_timestamp < clear_timestamp) {//表示服务器端有清空数据操作
			console.log("### tableNames",table_names);
			console.log("您后台有清除过数据,为保证前后台数据一致,请在设置中清空本地缓存数据.");
			
			/*// 清除本地数据(下行数据),清除后重新抓取数据并解析QK
			clearCacheData(
				sync4download(function(){
					verifyQK(parseQuickKeys)}
				)
			);*/
			
			//本地删除处理 start
			db.transaction(function(tx) {
				//SALE_ORDER,SHIFT_RECORD,ALL_PAY_RECORD,CUSTOMER,DEPOSIT,TIME_CARD_DC,PRODUCT,STOCK,STOCK_CHANGE,TIME_CARD_PRODUCT,TIME_CARD_SETTING,PROMOTION,EMPLOYEE,USER
				var tableNameArr = table_names.split(",");
				
				for(var i=0; i<tableNameArr.length; i++){
					var tableName = tableNameArr[i];
					
					//下行表全部删除
					var sql = "DELETE FROM "+tableName+" "
					
					//上行表按店铺删除
					if(tableName == 'SALEORDERS' || tableName == 'SALEORDERITEMS' || tableName == 'PAYRECORDS'  || tableName == 'SHIFTRECORDS' )
						sql += " WHERE outlet_id = "+ outletId;
					console.log("### sql : "+sql);
					tx.executeSql(sql,[],
						function(tx,result){
							console.log("### 成功清除 "+ result.rows.length +" 条数据 ");
						},
						function(tx,error){
							console.log("### 清除失败 , error :"+error.message);
						}
					);
				}
				
				//重置最后更新时间，以便下行重新抓取
				tx.executeSql('UPDATE sync_info SET last_sync = 1',[],null,function(tx,error){});
				tx.executeSql('UPDATE outlet_ts SET last_sync = 1',[],null,function(tx,error){});
				
			},null,
			function(){
				//事务结束
				console.log("### 成功同步清除本地缓存数据 ###");
				//更新删除时间戳
				var clear_timestamp_obj = {};
				clear_timestamp_obj[outletId] = clear_timestamp;
				localStorage.setItem("_server_db_clear_timestamp",JSON.stringify(clear_timestamp_obj));
				
				//重载收银页 > 重新下行同步，并刷新橱窗
				//window.location.reload();
				sync4download(function(){
					verifyQK(parseQuickKeys)}
				)
			}
			);
			//本地删除处理 end
		}
	});
	
	
	//服务器端推送触发货流数量更新通知
	$(eventSource).on('stock_version',function(e) {
		console.log("服务器端货流更新时间戳",e.originalEvent.data);
		var server_stock_version_timestamp = localStorage.getItem("_server_stock_version_timestamp") || 0;
		if (online && server_stock_version_timestamp < e.originalEvent.data) {
			//更新货流单据数量
			setStockChangeCount();
			localStorage.setItem("_server_stock_version_timestamp",e.originalEvent.data);
		}
	});
}


function switch2Online() {
	//$("#net_icon").removeClass().addClass('fa fa-wifi i-16').css('color','#33ff00').attr("title","在线");
	//$("#icon_sync").attr("src","images/icon_online.png");
	$("#net_icon").css('color','#66ff33')
	.tooltip({'data-original-title':'在线'});
	$("#net_icon").attr("title","在线");
	//$('#offlineModal').modal('hide');
	$(".needonline").show();
}

function switch2Offline() {
	switch2OfflineNoDialog();
	//$('#offlineModal').modal('show');
	$(".needonline").hide();
}

function switch2OfflineNoDialog() {
	//$("#net_icon").removeClass().addClass('fa fa-wifi i-16').css('color','#ddd').attr("title","离线");
	//$("#icon_sync").attr("src","images/icon_offline.png");
	$("#net_icon").css('color','lightgray')
	.tooltip({'data-original-title':'离线'});
	$("#net_icon").attr("title","离线");
	closeAllBootbox();
}


//窗口关闭事件处理
$(window).on('beforeunload', function() {	
	var oCookie = getCookie("_pos_console_syncing");
	if (oCookie && oCookie.length > 0) {// 201411:禁止在同步过程时切换或关闭收银页（概率很低，同步一般持续数十毫秒）
		return '正在保存数据，请留在此页，稍候数秒再操作。';
	}
	delCookie('_pos_console_syncing')
	delCookie('_pos_console_oprating');	
	console.log('***** syncing & oprating MARK deleted.')
});


var EventUtil = {
	addHandler : function(element, type, handler) {
		if (element.addEventListener) {
			element.addEventListener(type, handler, false);
		} else if (element.attachEvent) {
			element.attachEvent("on" + type, handler);
		} else {
			element["on" + type] = handler;
		}
	}
};

EventUtil.addHandler(window, "online", function() {
	console.log("Online");
	if (online) return;
	online = true;
	switch2Online();
	syncCashierSetting();//收银设置下行
	initNetshopTrade();
	sync4download(function(){verifyQK(parseQuickKeys)});
});
EventUtil.addHandler(window, "offline", function() {
	if (online) {
		switch2Offline();
		online = false;
	}
});
	
	
//*****************************************************
//业务逻辑预载入
//*****************************************************	

$(function(e) {
	//判断前台是否禁止销售(总店时)
	var posDisabled = false;
	$.ajax({
		async : false,		
		url : apiurl+"getSettingJson",
		dataType : "json",
		success : function(result) {
			//console.log("##############################"+jQuery.isEmptyObject(result));
			//返回JSON不空,则更新
			if(!jQuery.isEmptyObject(result)){
				localStorage.setItem("settings", JSON.stringify(result));
				console.log("*** sync setting completed first ***");

				//如果前台禁止销售(总店时),提醒并跳转回后台
				console.log("--------------- 前台禁止销售->"+result.posDisabled)
				if(result.posDisabled==1){					
					posDisabled = true;
				}
			}
		}
	});
	
	if(posDisabled){
		maskWait("总店前台已禁止销售!");
		return;
	}
	
	
	//0.多窗口运行检测(仅用于网页端收银)
	if(browser.versions.webKit){
		//var oCookie=getCookie('_pos_console_oprating');改回cookie MODIFY BY CPQ
		var oCookie=localStorage.getItem('_pos_console_oprating');
		//console.log('detect multi-instance in onload.')
		console.log("多窗口运行检测",oCookie , winid);
		if (oCookie && oCookie.length>0 && oCookie!=winid){
			console.log("############## 多窗口收银!!!");
			window.location.href='sellerror.html';
			return false;
		}
	}
	
	//1.检测登录状态(无论在线离线都必须有登录)
	if(!sessionStorage.getItem("_LOGIN_FLAG")){
		window.location.href = 'login.html';
	}	
	
	//2.本地存储(web sql)准备
	//createLocalDB();//CREATE or alter LOCAL DB>移到登录页
	loadLastSync();//取得并更新当前店的最后同步时间
	
	
	//3.小票、桌号设置
	checkOutletSettings();
	
	server_db_version = localStorage.getItem("_server_db_version");	
	console.log("************* server_db_version初始化->"+server_db_version);
	
	server_db_clear_timestamp = localStorage.getItem("_server_db_clear_timestamp");	
	console.log("************* server_db_version初始化->"+server_db_clear_timestamp);
	
	//4.同步数据,解析QK
	//4.1.延迟1秒,等DB创建或变更完成后再同步,
	//4.2.同步前会判断是否登录超时(通过比对sessionid,以保证身份正常,如超时需重要登录)
	//4.3.离线时,不会执行同步	
	//setTimeout(function(){
  	  startEventSrc();  	  
	//},1000);
	
	//5.页面初始化
	//延迟1秒,为了能取得online值
	setTimeout(function(){
		pageinit();
	},1000);
	
	
	//***************** 预载入结束 分割线  *****************
	
	
	//Check if a new cache is available on page load.
	//V2:以下相关appcatch状态的将不再起作用
	//检测到新版本时准备重载页面（这在每次登录后都会发生 但刷新本页面不会发生）
	$(applicationCache).on('updateready',function() {
		if (window.applicationCache.status == window.applicationCache.UPDATEREADY) {
			// Browser downloaded a new app cache.
			// Swap it in and reload the page to get the new
			// hotness.
			try {
				window.applicationCache.swapCache();
			} catch (e) {
				console.log('!###############:' + e.message);
			}
			window.location.reload();
		}
	});

	// noupdate 未发现新版本时 ==> 第二次加载页面时发生
	// cached 首次建立缓存时 =》用户第一次访问或缓存被意外删除时
	$(applicationCache).on('noupdate cached error', function() {
		pageinit();
		// startEventSrc();
		setTimeout(function() {
			startEventSrc();
		}, 2000);
	});
	//V2:以上相关appcatch状态的将不再起作用
	
	//手动同步
	$("#net_icon").click(function(){
		if (online) {
			sync4download(function(){
				verifyQK(parseQuickKeys)}
			);
		}
	});
	
	//setInterval(checkAlive,5000);
	
});

function checkAlive(){
$.ajax({
    type: "GET",
    url: apiurl+"alive",
    timeout: 1000,
    success: function(result) {
    	if (online) return;
    	if (result=="OK"){
	    	console.log("################### EV服务器畅通 ###################");	            	
	    	online = true;
	    	switch2Online();
	    	syncCashierSetting();//收银设置下行
	    	initNetshopTrade();
	    	sync4download(function(){verifyQK(parseQuickKeys)});
    	}else{
    		console.log("################### EV服务器没有正确返回 ###################");	            	
        	switch2Offline();
    		online = false;
    	}
    },
    error: function(request, status, error) {
    	console.log("################### EV服务器超时 ###################");	            	
    	switch2Offline();
		online = false;
    }
});
}
